var data=`England-FA_Cup_Qualification,City of Liverpool,Nantwich Town,1,2
England-FA_Cup_Qualification,Kingstonian,Shoreham FC,3,2
England-FA_Cup_Qualification,Cambridge City,St Neots Town,3,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,Tunisia,DR Congo,2,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Nigeria,Cameroon,4,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Morocco,Mali,6,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,Cape Verde,South Africa,2,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Ghana,Congo,1,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Peru,Bolivia,2,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Chile,Paraguay,0,3
International-World_Cup_Qualification_CONMEBOL_1st_round,Brazil,Ecuador,2,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Uruguay,Argentina,0,0
International-World_Cup_Qualification_OFC_Final_Stage,New Zealand,Solomon Islands,6,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Norway,Azerbaijan,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,San Marino,N.Ireland,0,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Czech Republic,Germany,1,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Denmark,Poland,4,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Kazakhstan,Montenegro,0,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Romania,Armenia,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Malta,England,0,4
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Slovakia,Slovenia,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Lithuania,Scotland,0,3
International-EURO_U21_Qualification_Grp__1,Belarus U21,Greece U21,0,2
International-EURO_U21_Qualification_Grp__2,Estonia U21,Slovakia U21,1,2
International-EURO_U21_Qualification_Grp__3,Georgia U21,Poland U21,0,3
International-EURO_U21_Qualification_Grp__4,Latvia U21,Ukraine U21,1,1
International-EURO_U21_Qualification_Grp__4,Netherlands U21,England U21,1,1
International-EURO_U21_Qualification_Grp__5,Kosovo U21,Norway U21,3,2
International-EURO_U21_Qualification_Grp__6,Cyprus U21,Malta U21,2,1
International-EURO_U21_Qualification_Grp__7,Serbia U21,Gibraltar U21,4,0
International-EURO_U21_Qualification_Grp__8,Bosnia and Herzegovina U21,Romania U21,1,3
International-EURO_U21_Qualification_Grp__8,Switzerland U21,Wales U21,0,3
International-EURO_U21_Qualification_Grp__9,Slovenia U21,Luxembourg U21,3,1
International-EURO_U21_Qualification_Grp__9,Kazakhstan U21,Montenegro U21,1,1
Ireland-Premier_Division,Limerick,Finn Harps,0,2
Ireland-Premier_Division,Dundalk,St. Patrick's Athletic,6,0
Ireland-Premier_Division,Shamrock Rovers,Cork City,3,1
Ireland-Premier_Division,Bohemian FC,Galway United FC,1,1
Netherlands-Eerste_Divisie,Helmond Sport,Go Ahead Eagles,1,1
Netherlands-Eerste_Divisie,FC Dordrecht,FC Emmen,2,2
Brazil-Serie_A,Gremio,Sport Recife,5,0
England-FA_Cup_Qualification,Stratford Town,Newcastle Town,4,0
England-FA_Cup_Qualification,Mossley AFC,1874 Northwich,2,2
England-FA_Cup_Qualification,Tuffley Rovers,Swindon Supermarine,0,5
England-FA_Cup_Qualification,Peterborough Sports,Stafford Rangers,3,4
England-FA_Cup_Qualification,Ossett Town,Consett AFC,2,1
England-FA_Cup_Qualification,Andover Town,Cadbury Heath,1,2
England-FA_Cup_Qualification,Banbury United,Tiverton,4,2
England-FA_Cup_Qualification,Ashton Athletic,Bamber Bridge,2,1
England-FA_Cup_Qualification,Rushall Olympic,Potton United,1,0
England-FA_Cup_Qualification,Thamesmead Town,Lewes,3,0
England-FA_Cup_Qualification,Thurrock,Harlow Town,1,1
England-FA_Cup_Qualification,Banstead Athletic,Glebe,0,4
England-FA_Cup_Qualification,Haverhill Borough,Kings Langley FC,0,8
England-FA_Cup_Qualification,Maldon &amp; Tiptree,Hayes &amp; Yeading United,3,3
England-FA_Cup_Qualification,Tividale,AFC Rushden &amp; Diamonds,2,3
England-FA_Cup_Qualification,Buxton,Frickley Athletic,3,2
England-FA_Cup_Qualification,Farnborough,Salisbury City,2,3
England-FA_Cup_Qualification,Market Drayton Town,Alvechurch,1,5
England-FA_Cup_Qualification,Scarborough Athletic,Workington,1,0
England-FA_Cup_Qualification,Bideford AFC,Bishop's Cleeve,5,1
England-FA_Cup_Qualification,Horsham,Ashford United,6,0
England-FA_Cup_Qualification,Arlesey Town,Heybridge Swifts,0,7
England-FA_Cup_Qualification,Mickleover Sports,Hinckley AFC,2,1
England-FA_Cup_Qualification,Tilbury,Aylesbury United,0,1
England-FA_Cup_Qualification,Gorleston,Barking,0,4
England-FA_Cup_Qualification,Faversham Town,Tonbridge Angels,3,1
England-FA_Cup_Qualification,Royston Town,Dunstable Town FC,2,0
England-FA_Cup_Qualification,Albion Sports AFC,Barnoldswick Town,3,2
England-FA_Cup_Qualification,Halesowen,Basford United,0,3
England-FA_Cup_Qualification,Paulton Rovers,Winchester City,1,0
England-FA_Cup_Qualification,St. Ives Town FC,Coalville Town,1,0
England-FA_Cup_Qualification,Droylsden,Colwyn Bay,4,3
England-FA_Cup_Qualification,Gosport Borough,Bridgwater Town,1,0
England-FA_Cup_Qualification,Stalybridge,Farsley Celtic AFC,2,1
England-FA_Cup_Qualification,Clapton,Needham Market,0,3
England-FA_Cup_Qualification,Metropolitan Police FC,Staines Town,3,2
England-FA_Cup_Qualification,Hertford Town,Grays Athletic,1,1
England-FA_Cup_Qualification,Erith Town,Burgess Hill Town,0,3
England-FA_Cup_Qualification,Warrington Town,Grimsby Borough,1,0
England-FA_Cup_Qualification,Baldock Town,Thame United,4,3
England-FA_Cup_Qualification,Romulus,Kettering Town FC,0,3
England-FA_Cup_Qualification,Littlehampton Town,Chipstead,2,2
England-FA_Cup_Qualification,Romford,Hornchurch,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Belarus,Sweden,0,4
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,France,Luxembourg,0,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Netherlands,Bulgaria,3,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Faroe Islands,Andorra,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Latvia,Switzerland,0,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Hungary,Portugal,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Estonia,Cyprus,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Greece,Belgium,1,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Gibraltar,Bosnia and Herzegovina,0,4
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Croatia,Kosovo,1,0
International-Friendlies,Equatorial Guinea,Benin,1,2
International-Friendlies,Canada,Jamaica,2,0
Italy-Serie_B,Ascoli Picchio FC 1898,Pro Vercelli,1,0
Italy-Serie_B,Foggia,Entella,1,1
Italy-Serie_B,Perugia,Pescara,4,2
Italy-Serie_B,Cesena,Venezia,0,0
Italy-Serie_B,Frosinone,Cittadella,2,1
Italy-Serie_B,Spezia,Carpi,0,1
Italy-Serie_B,Cremonese,Avellino,3,1
Italy-Serie_B,Novara,Parma Calcio 1913,0,1
Italy-Serie_B,Empoli,Bari,3,2
Netherlands-Eerste_Divisie,FC Volendam,Cambuur,0,1
Spain-Segunda_Division,Real Oviedo,Reus,3,0
Spain-Segunda_Division,Valladolid,Tenerife,2,0
Spain-Segunda_Division,Cordoba,Zaragoza,1,2
Spain-Segunda_Division,Sevilla Atletico,Leonesa,1,2
USA-Major_League_Soccer,New England Rev.,Orlando City,4,0
USA-Major_League_Soccer,LA Galaxy,Colorado Rapids,3,0
USA-Major_League_Soccer,Montreal Impact,Chicago Fire,0,1
USA-Major_League_Soccer,FC Dallas,New York Red Bulls,2,2
USA-USL,Phoenix Rising FC,Seattle Sounders FC II,2,0
USA-USL,Toronto FC II,Rochester Rhinos,0,1
USA-USL,Orange County SC,Reno 1868 FC,1,3
USA-USL,Charlotte Independence,Richmond Kickers,3,0
USA-USL,Swope Park Rangers,OKC Energy FC,2,0
USA-USL,Ottawa Fury,Saint Louis FC,2,2
England-FA_Cup_Qualification,Hitchin Town,Haringey Borough,2,3
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,Libya,Guinea,1,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Cameroon,Nigeria,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Azerbaijan,San Marino,5,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Germany,Norway,6,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,N.Ireland,Czech Republic,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Montenegro,Romania,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Armenia,Denmark,1,4
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Poland,Kazakhstan,3,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,England,Slovakia,2,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Scotland,Malta,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Slovenia,Lithuania,4,0
International-EURO_U21_Qualification_Grp__1,Greece U21,Moldova U21,5,1
International-EURO_U21_Qualification_Grp__2,Iceland U21,Albania U21,2,3
International-Friendlies,Kenya,Togo,
International-Friendlies,Togo,Malawi,0,1
Italy-Serie_B,Salernitana,Ternana,3,3
Spain-Segunda_Division,Alcorcon,Albacete,1,0
USA-USL,LA Galaxy II,Rio Grande Valley FC,1,0
International-Club_Friendlies,CSKA Moscow,Tosno,4,2
International-Club_Friendlies,CF Ripoll,Girona,0,8
International-Friendlies_U21,Austria U21,Croatia U21,1,1
International-Friendlies_U21,Italy U21,Slovenia U21,4,1
Italy-Serie_C_Grp__B,Modena,Vicenza,
Norway-1__Divisjon,Levanger,Arendal Fotball,3,2
Sweden-Superettan,GAIS,Oergryte FF,1,1
Sweden-Superettan,Aatvidaberg,IFK Vaernamo,1,3
Sweden-Superettan,Norrby,Varbergs BoIS FC,1,1
Argentina-Cup,Aldosivi,Velez Sarsfield,0,1
Brazil-Serie_C_Grp__A,Confianca,Fortaleza,2,0
Chile-Cup,Santiago Wanderers,O'Higgins,2,0
Colombia-Primera_A_Clausura,Independiente Medellin,Santa Fe,0,1
Colombia-Primera_A_Clausura,Cortulua,Atletico Junior,1,0
Costa_Rica-Primera_Division_Apertura,Deportivo Saprissa,Grecia,6,1
Costa_Rica-Primera_Division_Apertura,C.S. Cartagines,AD Municipal Liberia,1,0
Croatia-2__Division,Dinamo Zagreb B,NK Kustosija,2,1
England-Northern_Premier_Division,Stourbridge,Hednesford,2,0
England-Northern_Premier_Division,Shaw Lane AFC,Rushall Olympic,2,0
Honduras-Liga_Nacional___Apertura,Real Espana,CD Olimpia,2,0
Indonesia-Liga_1,Persipura Jayapura,Semen Padang,3,0
England-FA_Cup_Qualification,Tunbridge Wells,Haywards Heath Town,3,0
England-FA_Cup_Qualification,1874 Northwich,Mossley AFC,2,0
England-FA_Cup_Qualification,Hartley Wintney,Basingstoke,1,0
England-FA_Cup_Qualification,Wingate &amp; Finchley,Hendon,4,2
England-FA_Cup_Qualification,Altrincham,Abbey Hey,2,1
England-FA_Cup_Qualification,Chipstead,Littlehampton Town,4,0
England-FA_Cup_Qualification,Taunton Town,Tavistock AFC,1,2
England-FA_Cup_Qualification,Hayes &amp; Yeading United,Maldon &amp; Tiptree,4,3
England-FA_Cup_Qualification,Harlow Town,Thurrock,2,1
England-FA_Cup_Qualification,Egham Town FC,Ramsgate,2,4
England-FA_Cup_Qualification,Liversedge,Sunderland RCA,0,4
England-FA_Cup_Qualification,Biggleswade Town,North Leigh,3,2
England-FA_Cup_Qualification,Mildenhall Town,AFC Sudbury,2,4
International-World_Cup_Qualification_AFC_3rd_Round_Grp__A,Uzbekistan,South Korea,0,0
International-World_Cup_Qualification_AFC_3rd_Round_Grp__A,Qatar,China,1,2
International-World_Cup_Qualification_AFC_3rd_Round_Grp__A,Iran,Syria,2,2
International-World_Cup_Qualification_AFC_3rd_Round_Grp__B,Saudi Arabia,Japan,1,0
International-World_Cup_Qualification_AFC_3rd_Round_Grp__B,Australia,Thailand,2,1
International-World_Cup_Qualification_AFC_3rd_Round_Grp__B,Iraq,U.A.E.,1,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,DR Congo,Tunisia,2,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Algeria,Zambia,0,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Ivory Coast,Gabon,1,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Mali,Morocco,0,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,South Africa,Cape Verde,1,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,Burkina Faso,Senegal,2,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Congo,Ghana,1,5
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Egypt,Uganda,1,0
International-World_Cup_Qualification_CONCACAF_Final_Stage,Honduras,USA,1,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Ecuador,Peru,1,2
International-World_Cup_Qualification_CONMEBOL_1st_round,Bolivia,Chile,1,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Colombia,Brazil,1,1
International-World_Cup_Qualification_OFC_Final_Stage,Solomon Islands,New Zealand,2,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Ireland,Serbia,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Austria,Georgia,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Moldova,Wales,0,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Liechtenstein,Spain,0,8
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Macedonia,Albania,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Italy,Israel,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Turkey,Croatia,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Kosovo,Finland,0,1
England-FA_Cup_Qualification,Westfields,Soham Town Rangers,1,0
England-FA_Cup_Qualification,Grays Athletic,Hertford Town,2,3
International-World_Cup_Qualification_CONCACAF_Final_Stage,Panama,Trinidad and Tobago,3,0
International-World_Cup_Qualification_CONCACAF_Final_Stage,Costa Rica,Mexico,1,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Paraguay,Uruguay,1,2
International-World_Cup_Qualification_CONMEBOL_1st_round,Argentina,Venezuela,1,1
Bulgaria-First_Professional_League,Levski Sofia,Ludogorets Razgrad,0,0
Hungary-NB_I,Paksi SE,Videoton FC,1,4
Spain-Copa_del_Rey,Logrones,AD Union Adarve,8,7
Spain-Copa_del_Rey,Real Oviedo,Numancia,0,1
Spain-Copa_del_Rey,Zaragoza,Granada,3,0
Spain-Copa_del_Rey,Ponferradina,Atletico Baleares,1,0
Spain-Copa_del_Rey,Huesca,Valladolid,0,2
Spain-Copa_del_Rey,Reus,Sporting Gijon,0,1
Spain-Copa_del_Rey,Elche,Cultural De Durango,3,2
Spain-Copa_del_Rey,Real Murcia,Racing de Ferrol,4,1
Spain-Copa_del_Rey,Mallorca,Lleida Esportiu,3,4
Spain-Copa_del_Rey,Cartagena,Mirandes,2,1
Spain-Copa_del_Rey,Rayo Vallecano,Tenerife,0,3
Spain-Copa_del_Rey,SD Formentera,SD Tarazona,6,5
Spain-Copa_del_Rey,CD Calahorra,SD Leioa,2,0
Spain-Copa_del_Rey,UE Olot,Alcoyano,1,0
Spain-Copa_del_Rey,Lorca FC,Cordoba,2,4
Spain-Copa_del_Rey,CF Talavera de la Reina,Antequera,3,1
Spain-Copa_del_Rey,Hercules,Lorca Deportiva,2,1
Spain-Copa_del_Rey,Fuenlabrada,Merida,2,0
Spain-Copa_del_Rey,Marbella FC,Gimnastica Segoviana,1,2
Denmark-DBU_Pokalen,Vendsyssel FF,Brabrand,1,0
Norway-1__Divisjon,Bodoe/Glimt,Sandnes,0,0
Russia-National_Football_League,Tom Tomsk,FC Orenburg,0,0
Russia-National_Football_League,Khimki,Sibir Novosibirsk,0,1
Russia-National_Football_League,Kuban Krasnodar,FC Yenisey Krasnoyarsk,1,1
Russia-National_Football_League,Olimpiec Nizhny,Spartak Moscow II,1,3
Russia-National_Football_League,Shinnik Yaroslavl,Dinamo St Petersburg,1,2
Russia-National_Football_League,Avangard Kursk,Fakel,2,0
Russia-National_Football_League,FC Rotor Volgograd,Zenit St. Petersburg II,4,1
Russia-National_Football_League,Baltika,Luch Energiya Vladivostok,2,1
Russia-National_Football_League,Krylya Sovetov Samara,FC Tambov,1,0
Russia-National_Football_League,FC Volgar,Tyumen,1,0
Argentina-Primera_C,Sportivo Barracas,CA Ferrocarril Midland,0,2
Finland-Veikkausliiga,JJK,FC Lahti,2,4
Finland-Veikkausliiga,RoPS,PS Kemi,0,1
Finland-Veikkausliiga,FC Inter,Ilves,2,2
Spain-Copa_del_Rey,Alcorcon,Leonesa,2,4
Spain-Copa_del_Rey,Osasuna,Albacete,3,2
USA-Major_League_Soccer,New York City FC,Sporting Kansas City,1,0
USA-USL,LA Galaxy II,Reno 1868 FC,1,2
USA-USL,Vancouver Whitecaps II,Tulsa Roughnecks FC,1,3
USA-USL,Phoenix Rising FC,Orange County SC,0,0
USA-USL,Penn FC,Tampa Bay Rowdies,2,3
USA-USL,Orlando City B,Richmond Kickers,0,2
Brazil-Serie_B,Goias,Parana Clube,0,1
Brazil-Serie_B,Nautico,Brasil de Pelotas,1,0
Denmark-DBU_Pokalen,Viborg,AaB,1,5
Wales-Premier_League,Llandudno FC,Prestatyn Town FC,2,2
Algeria-Ligue_1,Paradou AC,MC Oran,1,0
Algeria-Ligue_1,NA Hussein Dey,USM Alger,1,1
Argentina-Cup,Sarmiento,Sacachispas FC,3,1
Cameroon-Elite_One,Bamboutos,Young Sports Academy,1,0
Cameroon-Elite_One,Stade Renard,Les Astres,2,1
Cameroon-Elite_One,Lion Blesse,Dragon,0,1
Cameroon-Elite_One,Canon Sportif,Unisport,0,1
Cameroon-Elite_One,Feutcheu,Aigle Royal,0,1
Cameroon-Elite_One,UMS de Loum,Coton Sport,0,0
Cameroon-Elite_One,RC Bafoussam,Colombe,0,3
Cameroon-Elite_One,Union Douala,New Stars,0,1
Cameroon-Elite_One,Eding Sport FC,APEJES FC,0,0
Chile-Cup,Huachipato,Universidad Catolica,3,2
Chile-Cup,Antofagasta,San Marcos,4,2
El_Salvador-Primera_Division___Apertura,CD Chalatenango,Alianza FC,0,2
Estonia-Esiliiga,Tartu JK Welco,FC Elva,1,3
Finland-Ykkonen,OPS,AC Oulu,3,1
Finland-Kakkonen___Lohko_C,Kajha,SC KuFu-98,2,2
Guatemala-Liga_Nacional_Apertura,CSD Comunicaciones,Sanarate,0,1
Guatemala-Liga_Nacional_Apertura,Deportivo Petapa,CD Suchitepequez,3,0
Iceland-1__Deild,Fram Reykjavik,Selfoss,0,0
Iceland-1__Deild,Fylkir,Throttur Reykjavik,3,1
Iceland-1__Deild,Keflavik,Grotta,3,0
Iceland-1__Deild,Leiknir Reykjavik,IR Reykjavik,4,0
Iran-Persian_Gulf_Pro_League,Gostaresh Foolad FC,Persepolis,0,3
France-Ligue_1,Metz,Paris Saint Germain,1,5
France-Ligue_1,Lille,Bordeaux,0,0
Germany-1__Bundesliga,Hamburger SV,RasenBallsport Leipzig,0,2
Portugal-Primeira_Liga,Feirense,Sporting CP,2,3
Portugal-Primeira_Liga,Benfica,Portimonense,2,1
Russia-Premier_League,Amkar,CSKA Moscow,0,1
Spain-Primera_Division,Leganes,Getafe,1,2
Belgium-First_Division_A,Anderlecht,Lokeren,3,2
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Vereya,3,0
Bulgaria-First_Professional_League,Beroe,Cherno More Varna,2,0
Croatia-1__Division,NK Istra 1961,Slaven,1,0
Denmark-Superligaen,Hobro,SoenderjyskE,3,2
Denmark-Superligaen,AC Horsens,FC Nordsjaelland,2,2
England-Championship,Derby County,Hull City,5,0
Finland-Veikkausliiga,HIFK,IFK Mariehamn,0,0
Finland-Veikkausliiga,KuPS,SJK,2,1
Finland-Veikkausliiga,VPS,HJK,0,3
Germany-2__Bundesliga,FC Heidenheim,Jahn Regensburg,1,3
Germany-2__Bundesliga,Dynamo Dresden,Greuther Fuerth,1,1
Italy-Serie_B,Pescara,Frosinone,3,3
Netherlands-Eerste_Divisie,Cambuur,Jong FC Utrecht,2,2
Netherlands-Eerste_Divisie,FC Emmen,Fortuna Sittard,0,0
Netherlands-Eerste_Divisie,Go Ahead Eagles,FC Volendam,1,1
Netherlands-Eerste_Divisie,FC Oss,FC Dordrecht,3,1
Netherlands-Eerste_Divisie,FC Den Bosch,NEC Nijmegen,3,0
Netherlands-Eerste_Divisie,Almere City FC,Helmond Sport,3,1
Netherlands-Eerste_Divisie,FC Eindhoven,Jong PSV,1,2
Netherlands-Eerste_Divisie,De Graafschap,MVV Maastricht,1,2
N__Ireland-Premiership,Glenavon,Carrick Rangers,2,0
Poland-Ekstraklasa,Zaglebie Lubin,Wisla Plock,2,2
Poland-Ekstraklasa,Arka Gdynia,Wisla Krakow,3,1
Romania-Liga_I,Botosani,Astra Giurgiu,1,3
Scotland-Premiership,Hamilton Academical,Celtic,1,4
Slovenia-Prva_Liga,Rudar Velenje,Aluminij,0,0
Slovenia-Prva_Liga,Maribor,NK Celje,0,0
Spain-Segunda_Division,Cadiz,Gimnastic,2,0
Belgium-First_Division_B_1st_Stage,Oud-Heverlee,Tubize,2,0
Egypt-Premier_League,Al Mokawloon Al Arab,El Raja Marsa Matruh,3,0
Egypt-Premier_League,El Dakhleya,Petrojet,1,1
Estonia-Meistriliiga,Paernu Linnameeskond,Tulevik Viljandi,
Brazil-Serie_A,Vasco da Gama,Gremio,1,0
Brazil-Serie_A,Atletico MG,Palmeiras,1,1
England-Premier_League,Southampton,Watford,0,2
England-Premier_League,Manchester City,Liverpool,5,0
England-Premier_League,Stoke City,Manchester United,2,2
England-Premier_League,Everton,Tottenham Hotspur,0,3
England-Premier_League,Arsenal,AFC Bournemouth,3,0
England-Premier_League,Leicester City,Chelsea,1,2
England-Premier_League,Brighton &amp; Hove Albion,West Bromwich Albion,3,1
France-Ligue_1,Strasbourg,Amiens,0,1
France-Ligue_1,Caen,Dijon,2,1
France-Ligue_1,Troyes,Toulouse,0,0
France-Ligue_1,Nice,Monaco,4,0
France-Ligue_1,Montpellier,Nantes,0,1
Germany-1__Bundesliga,Hoffenheim,Bayern Munich,2,0
Germany-1__Bundesliga,Freiburg,Borussia Dortmund,0,0
Germany-1__Bundesliga,Mainz 05,Bayer Leverkusen,3,1
Germany-1__Bundesliga,Borussia Moenchengladbach,Eintracht Frankfurt,0,1
Germany-1__Bundesliga,Wolfsburg,Hannover 96,1,1
Germany-1__Bundesliga,Augsburg,FC Cologne,3,0
Italy-Serie_A,Juventus,ChievoVerona,3,0
Netherlands-Eredivisie,Excelsior,Vitesse,0,3
Netherlands-Eredivisie,Willem II,ADO Den Haag,1,2
Netherlands-Eredivisie,Ajax,PEC Zwolle,3,0
Netherlands-Eredivisie,Heracles,Feyenoord,2,4
Portugal-Primeira_Liga,Maritimo,Rio Ave,1,0
Portugal-Primeira_Liga,FC Porto,Chaves,3,0
Portugal-Primeira_Liga,Tondela,Pacos de Ferreira,2,2
Russia-Premier_League,Spartak Moscow,Rubin Kazan,1,0
Russia-Premier_League,Tosno,Anzhi Makhachkala,2,2
Russia-Premier_League,FC Rostov,Arsenal Tula,2,2
Spain-Primera_Division,Valencia,Atletico Madrid,0,0
Spain-Primera_Division,Sevilla,Eibar,3,0
Spain-Primera_Division,Real Madrid,Levante,1,1
Spain-Primera_Division,Barcelona,Espanyol,5,0
Argentina-Superliga,Velez Sarsfield,Atletico Tucuman,2,0
Argentina-Superliga,Patronato de Parana,Argentinos Juniors,2,1
Argentina-Superliga,Belgrano,San Martin San Juan,1,0
Argentina-Superliga,Estudiantes,Defensa y Justicia,0,1
Argentina-Superliga,Arsenal Sarandi,Colon,0,1
Brazil-Serie_A,Vitoria,Fluminense,2,2
Brazil-Serie_A,Atletico PR,Coritiba,1,1
Brazil-Serie_A,Sao Paulo,Ponte Preta,2,2
Brazil-Serie_A,Santos FC,Corinthians,2,0
Brazil-Serie_A,Sport Recife,Avai FC,0,1
England-Premier_League,Burnley,Crystal Palace,1,0
England-Premier_League,Swansea City,Newcastle United,0,1
France-Ligue_1,Saint-Etienne,Angers,1,1
France-Ligue_1,Marseille,Rennes,1,3
France-Ligue_1,Lyon,Guingamp,2,1
Germany-1__Bundesliga,Schalke 04,VfB Stuttgart,3,1
Germany-1__Bundesliga,Hertha Berlin,Werder Bremen,1,1
Italy-Serie_A,Hellas Verona,Fiorentina,0,5
Italy-Serie_A,Atalanta,Sassuolo,2,1
Italy-Serie_A,Udinese,Genoa,1,0
Italy-Serie_A,Benevento,Torino,0,1
Italy-Serie_A,Lazio,AC Milan,4,1
Italy-Serie_A,Cagliari,Crotone,1,0
Italy-Serie_A,Inter,SPAL 2013,2,0
Italy-Serie_A,Bologna,SSC Napoli,0,3
Netherlands-Eredivisie,FC Utrecht,Roda JC Kerkrade,2,0
Netherlands-Eredivisie,FC Groningen,VVV-Venlo,1,1
Netherlands-Eredivisie,SC Heerenveen,PSV Eindhoven,2,0
Netherlands-Eredivisie,Sparta Rotterdam,FC Twente,1,0
Netherlands-Eredivisie,AZ Alkmaar,NAC Breda,2,1
Portugal-Primeira_Liga,Estoril,Moreirense,0,2
Portugal-Primeira_Liga,Vitoria de Guimaraes,Boavista,1,0
Portugal-Primeira_Liga,Vitoria de Setubal,Braga,2,0
Russia-Premier_League,FC Ufa,FC Krasnodar,0,1
Russia-Premier_League,Dinamo Moscow,Zenit St. Petersburg,0,0
Russia-Premier_League,FK Akhmat,Lokomotiv Moscow,1,1
Spain-Primera_Division,Deportivo La Coruna,Real Sociedad,2,4
Spain-Primera_Division,Villarreal,Real Betis,3,1
Spain-Primera_Division,Celta Vigo,Alaves,1,0
Spain-Primera_Division,Athletic Bilbao,Girona,2,0
Argentina-Superliga,Racing Club,Temperley,4,1
Argentina-Superliga,River Plate,Banfield,3,1
Argentina-Superliga,Rosario Central,San Lorenzo,0,0
Argentina-Superliga,Chacarita Juniors,Tigre,1,1
Argentina-Superliga,Godoy Cruz,Talleres,2,1
Brazil-Serie_A,Botafogo RJ,Flamengo,2,0
Brazil-Serie_A,Chapecoense AF,Cruzeiro,1,2
England-Premier_League,West Ham United,Huddersfield Town,2,0
Portugal-Primeira_Liga,Aves,Belenenses,2,1
Russia-Premier_League,Ural,SKA-Khabarovsk,1,1
Spain-Primera_Division,Malaga,Las Palmas,1,3
International-AFC_Champions_League_Final_Stage,Al Hilal,Al-Ain,3,0
Argentina-Superliga,Lanus,Boca Juniors,0,1
Bulgaria-First_Professional_League,Septemvri Sofia,Etar,1,1
Denmark-Superligaen,AaB,Silkeborg,2,1
Finland-Veikkausliiga,FC Lahti,KuPS,1,1
Finland-Veikkausliiga,SJK,VPS,2,1
Germany-2__Bundesliga,Nuernberg,St. Pauli,0,1
Greece-Super_League,Apollon Smirnis,PAOK Thessaloniki FC,0,0
Israel-Ligat_HaAl,Maccabi Petach Tikva,Beitar Jerusalem,1,2
Italy-Serie_B,Cittadella,Perugia,1,1
Mexico-Liga_MX_Apertura,Santos,Toluca,0,0
Netherlands-Eerste_Divisie,Jong Ajax,RKC Waalwijk,1,1
Norway-Eliteserien,Molde,Odds Ballklubb,2,1
Poland-Ekstraklasa,Piast Gliwice,Lechia Gdansk,1,2
Romania-Liga_I,Dinamo Bucuresti,ACS Poli Timisoara,1,2
Romania-Liga_I,Gaz Metan Medias,Concordia Chiajna,1,2
Spain-Segunda_Division,Reus,Numancia,1,0
Sweden-Allsvenskan,IFK Gothenburg,Djurgaarden,1,3
Turkey-Super_Lig,Kasimpasa,Yeni Malatyaspor,3,2
USA-Major_League_Soccer,Seattle Sounders FC,LA Galaxy,1,1
USA-USL,OKC Energy FC,Vancouver Whitecaps II,0,0
Egypt-Premier_League,ENPPI,Smouha SC,1,1
Estonia-Meistriliiga,Tammeka,Tulevik Viljandi,1,1
France-Ligue_2,Reims,Brest,0,1
Italy-Serie_C_Grp__B,Reggiana,Modena,
Russia-National_Football_League,Spartak Moscow II,Krylya Sovetov Samara,0,3
Sweden-Superettan,Trelleborgs FF,GAIS,2,0
Turkey-1__Lig,Adana Demirspor,Gaziantepspor,3,1
Algeria-Ligue_1,USM Alger,DRB Tadjenanet,1,1
Argentina-Primera_C,Deportivo Merlo,Sportivo Barracas,1,1
Argentina-Primera_C,Ituzaingo,Argentino de Quilmes,1,0
Argentina-Primera_C,El Porvenir,Laferrere,0,0
Armenia-1__Division,Banants II,Shirak II,3,0
Armenia-1__Division,Pyunik II,Gandzasar II,3,2
International-Champions_League_Grp__A,Manchester United,Basel,3,0
International-Champions_League_Grp__A,Benfica,CSKA Moscow,1,2
International-Champions_League_Grp__B,Bayern Munich,Anderlecht,3,0
International-Champions_League_Grp__B,Celtic,Paris Saint Germain,0,5
International-Champions_League_Grp__C,Chelsea,Qarabag FK,6,0
International-Champions_League_Grp__C,Roma,Atletico Madrid,0,0
International-Champions_League_Grp__D,Barcelona,Juventus,3,0
International-Champions_League_Grp__D,Olympiacos,Sporting CP,2,3
Brazil-Serie_A,Atletico GO,Bahia,1,1
International-AFC_Champions_League_Final_Stage,Guangzhou Evergrande,Shanghai SIPG FC,9,6
International-AFC_Champions_League_Final_Stage,Al Ahli,Persepolis,1,3
Argentina-Superliga,Union,Gimnasia LP,1,0
Argentina-Superliga,Huracan,Newells Old Boys,1,0
England-Championship,Preston North End,Cardiff City,3,0
England-Championship,Sunderland,Nottingham Forest,0,1
England-Championship,Leeds United,Birmingham City,2,0
England-Championship,Queens Park Rangers,Millwall,2,2
England-Championship,Wolverhampton Wanderers,Bristol City,3,3
England-Championship,Norwich City,Burton Albion,0,0
England-Championship,Sheffield Wednesday,Brentford,2,1
England-Championship,Bolton Wanderers,Sheffield United,0,1
England-Championship,Aston Villa,Middlesbrough,0,0
England-EFL_Cup,Barnsley,Derby County,3,2
Finland-Veikkausliiga,IFK Mariehamn,FC Inter,2,1
Finland-Veikkausliiga,HJK,HIFK,2,1
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Telstar,2,2
N__Ireland-Premiership,Crusaders,Linfield,2,1
International-AFC_Cup_Final_Stage,Al-Wahda,Al Quwa Al Jawiya,2,1
International-AFC_Cup_Final_Stage,Ceres-Negros FC,FC Istiklol,1,1
England-League_1,Shrewsbury Town,Southend United,1,0
England-League_1,Fleetwood Town,Bury,3,2
England-League_1,Peterborough United,Milton Keynes Dons,2,0
England-League_1,Rotherham United,Walsall,5,1
England-League_1,Bristol Rovers,Oldham Athletic,2,3
England-League_1,Northampton Town,Portsmouth,3,1
England-League_1,Plymouth Argyle,Blackpool,1,3
England-League_1,Scunthorpe United,Blackburn Rovers,0,1
England-League_1,Charlton Athletic,Wigan Athletic,0,3
England-League_1,Oxford United,Bradford City,2,2
England-League_1,Rochdale,Doncaster Rovers,2,1
International-Champions_League_Grp__E,Liverpool,Sevilla,2,2
International-Champions_League_Grp__E,Maribor,Spartak Moscow,1,1
International-Champions_League_Grp__F,Feyenoord,Manchester City,0,4
International-Champions_League_Grp__F,Shakhtar Donetsk,SSC Napoli,2,1
International-Champions_League_Grp__G,RasenBallsport Leipzig,Monaco,1,1
International-Champions_League_Grp__G,FC Porto,Besiktas,1,3
International-Champions_League_Grp__H,Tottenham Hotspur,Borussia Dortmund,3,1
International-Champions_League_Grp__H,Real Madrid,APOEL Nicosia,3,0
International-AFC_Champions_League_Final_Stage,Urawa Red Diamonds,Kawasaki Frontale,4,1
England-Championship,Fulham,Hull City,2,1
USA-USL,Penn FC,FC Cincinnati,1,1
International-AFC_Cup_Final_Stage,April 25 SC,Bengaluru FC,0,0
Brazil-Serie_B,Boa Esporte Clube,Guarani,2,2
Brazil-Serie_B,Criciuma,Juventude,1,2
International-Copa_Sudamericana,Cerro Porteno,Atletico Junior,0,0
International-Copa_Sudamericana,Independiente,Atletico Tucuman,2,0
Kosovo-Superliga,Liria,Drita,2,0
Kosovo-Superliga,Drenica,FC Prishtina,1,1
Kosovo-Superliga,Besa Peje,KF Flamurtari,2,0
Kosovo-Superliga,KF Vllaznia Pozheran,Trepca 89,2,1
Philippines-Philippines_Football_League,Global FC,Davao Aguilas,3,1
Serbia-Super_Liga,Radnicki Nis,Borac Cacak,1,0
Serbia-Super_Liga,Mladost Lucani,Javor,3,0
Serbia-Super_Liga,Cukaricki,FK Radnik Surdulica,1,2
Serbia-Super_Liga,Napredak,Vozdovac,1,2
Serbia-Super_Liga,Rad Beograd,Backa Backa Palanka,0,0
Serbia-Super_Liga,Vojvodina,Macva Sabac,1,0
Argentina-Primera_B_Metropolitana,Almirante Brown,Colegiales,0,1
Argentina-Primera_B_Metropolitana,CA Talleres Remedios de Escalada,CA Fenix,0,2
Argentina-Primera_B_Metropolitana,Tristan Suarez,Villa San Carlos,2,0
Argentina-Primera_B_Metropolitana,CA San Miguel,San Telmo,1,1
Argentina-Primera_B_Metropolitana,Deportivo Espanol,Atlanta,0,2
Armenia-Cup,Shirak,Ararat,1,1
Australia-FFA_Cup,Sydney FC,Melbourne City FC,2,0
Australia-FFA_Cup,Heidelberg United,Adelaide United,0,3
Austria-Regionalliga_West,FC Kitzbuehel,Woergl,1,2
Bolivia-Primera_Division___Clausura_Adecuacion,Sport Boys Warnes,Nacional Potosi,3,2
Cameroon-Elite_One,Aigle Royal,APEJES FC,1,1
Cameroon-Elite_One,Bamboutos,Union Douala,2,2
Cameroon-Elite_One,Stade Renard,UMS de Loum,1,1
International-Copa_Libertadores_Final_Stage,San Lorenzo,Lanus,2,0
International-Copa_Libertadores_Final_Stage,Barcelona SC,Santos FC,1,1
International-Copa_Libertadores_Final_Stage,Botafogo RJ,Gremio,0,0
International-Europa_League_Grp__A,Villarreal,FC Astana,3,1
International-Europa_League_Grp__A,Slavia Prague,Maccabi Tel Aviv,1,0
International-Europa_League_Grp__B,Dynamo Kyiv,Skenderbeu,3,1
International-Europa_League_Grp__B,Young Boys,Partizan Beograd,1,1
International-Europa_League_Grp__C,Hoffenheim,Braga,1,2
International-Europa_League_Grp__C,Istanbul Basaksehir,Ludogorets Razgrad,0,0
International-Europa_League_Grp__D,Rijeka,AEK Athens,1,2
International-Europa_League_Grp__D,Austria Wien,AC Milan,1,5
International-Europa_League_Grp__E,Atalanta,Everton,3,0
International-Europa_League_Grp__E,Apollon Limassol,Lyon,1,1
International-Europa_League_Grp__F,Zlin,FC Sheriff,0,0
International-Europa_League_Grp__F,FC Koebenhavn,Lokomotiv Moscow,0,0
International-Europa_League_Grp__G,Hapoel Beer Sheva,Lugano,2,1
International-Europa_League_Grp__G,FC FCSB,Viktoria Plzen,3,0
International-Europa_League_Grp__H,Arsenal,FC Cologne,3,1
International-Europa_League_Grp__H,FK Crvena Zvezda,BATE Borisov,1,1
International-Europa_League_Grp__I,Vitoria de Guimaraes,Salzburg,1,1
International-Europa_League_Grp__I,Marseille,Konyaspor,1,0
International-Europa_League_Grp__J,Zorya,Oestersunds FK,0,2
International-Europa_League_Grp__J,Hertha Berlin,Athletic Bilbao,0,0
International-Europa_League_Grp__K,Zulte-Waregem,Nice,1,5
International-Europa_League_Grp__K,Vitesse,Lazio,2,3
International-Europa_League_Grp__L,Real Sociedad,Rosenborg,4,0
International-Europa_League_Grp__L,FK Vardar Skopje,Zenit St. Petersburg,0,5
USA-Major_League_Soccer,Atlanta United,New England Rev.,7,0
USA-Major_League_Soccer,Vancouver Whitecaps,Minnesota United,3,0
USA-USL,Orange County SC,San Antonio FC,0,1
International-CONCACAF_League,CD Arabe Unido,Santos de Guapiles,0,0
International-Copa_Sudamericana,Sport Recife,Ponte Preta,3,1
International-Copa_Sudamericana,Chapecoense AF,Flamengo,0,0
International-Copa_Sudamericana,Corinthians,Racing Club,1,1
Egypt-Premier_League,El Geish,El Entag El Harby,2,2
Egypt-Premier_League,Petrojet,Al Masry,0,1
Iceland-Urvalsdeild,Vikingur Reykjavik,FH Hafnarfjordur,2,4
Iceland-Urvalsdeild,IBV Vestmannaeyjar,Grindavik,2,1
Iceland-Urvalsdeild,KA Akureyri,Valur,1,1
Iceland-Urvalsdeild,Fjoelnir,IA Akranes,2,2
International-Copa_Libertadores_Final_Stage,Jorge Wilstermann,River Plate,3,0
England-Premier_League,AFC Bournemouth,Brighton &amp; Hove Albion,2,1
France-Ligue_1,Toulouse,Bordeaux,0,1
Germany-1__Bundesliga,Hannover 96,Hamburger SV,2,0
Netherlands-Eredivisie,Sparta Rotterdam,AZ Alkmaar,0,2
Portugal-Primeira_Liga,Pacos de Ferreira,Vitoria de Setubal,1,0
Russia-Premier_League,Arsenal Tula,Dinamo Moscow,1,0
Spain-Primera_Division,Eibar,Leganes,1,0
Belgium-First_Division_A,Club Brugge,KV Mechelen,2,0
Bulgaria-First_Professional_League,Etar,Beroe,1,2
Bulgaria-First_Professional_League,Levski Sofia,Septemvri Sofia,2,0
Croatia-1__Division,Cibalia,NK Lokomotiva,0,1
Czech_Republic-1__Division,Teplice,Bohemians 1905,0,0
Czech_Republic-1__Division,Dukla Praha,Banik Ostrava,2,0
Denmark-Superligaen,Silkeborg,OB,1,0
Denmark-Superligaen,Randers FC,Lyngby,0,0
Finland-Veikkausliiga,HIFK,JJK,1,1
Germany-2__Bundesliga,Erzgebirge Aue,Holstein Kiel,0,3
Germany-2__Bundesliga,Union Berlin,Eintracht Braunschweig,1,1
Ireland-Premier_Division,Bray Wanderers,Limerick,1,1
Ireland-Premier_Division,Drogheda United,Bohemian FC,1,4
Ireland-Premier_Division,Galway United FC,Derry City,2,1
Italy-Serie_B,Cesena,Avellino,3,1
Italy-Serie_B,Venezia,Spezia,0,0
Netherlands-Eerste_Divisie,MVV Maastricht,Jong PSV,0,0
Netherlands-Eerste_Divisie,NEC Nijmegen,FC Emmen,1,1
Netherlands-Eerste_Divisie,FC Dordrecht,Almere City FC,1,1
Netherlands-Eerste_Divisie,Helmond Sport,Jong Ajax,1,4
Netherlands-Eerste_Divisie,Go Ahead Eagles,Cambuur,1,3
Netherlands-Eerste_Divisie,FC Oss,Jong AZ Alkmaar,1
Netherlands-Eerste_Divisie,RKC Waalwijk,FC Eindhoven,0,1
Netherlands-Eerste_Divisie,Fortuna Sittard,FC Volendam,1,0
Netherlands-Eerste_Divisie,Jong FC Utrecht,De Graafschap,1,4
Netherlands-Eerste_Divisie,Telstar,FC Den Bosch,3,2
Poland-Ekstraklasa,Arka Gdynia,Zaglebie Lubin,1,1
Poland-Ekstraklasa,Lech Poznan,Korona Kielce,1,0
Romania-Liga_I,Juventus Bucuresti,Botosani,0,2
Romania-Liga_I,CSMS Iasi,FC Voluntari,2,1
Scotland-Premiership,Partick Thistle,Rangers,2,2
Slovenia-Prva_Liga,NK Celje,NK Krsko,0,0
England-Premier_League,West Bromwich Albion,West Ham United,0,0
England-Premier_League,Newcastle United,Stoke City,2,1
England-Premier_League,Huddersfield Town,Leicester City,1,1
England-Premier_League,Watford,Manchester City,0,6
England-Premier_League,Tottenham Hotspur,Swansea City,0,0
England-Premier_League,Liverpool,Burnley,1,1
England-Premier_League,Crystal Palace,Southampton,0,1
England-FA_Cup_Qualification,Salisbury City,Poole Town FC,0,2
England-FA_Cup_Qualification,Hertford Town,Hornchurch,1,2
England-FA_Cup_Qualification,Blyth Spartans,Shaw Lane AFC,1,2
England-FA_Cup_Qualification,Havant and Waterlooville,Merthyr Town,2,1
England-FA_Cup_Qualification,Hemel Hempstead,Wingate &amp; Finchley,0,0
England-FA_Cup_Qualification,Darlington,South Shields,0,3
England-FA_Cup_Qualification,Dereham Town,Boston Town,1,2
England-FA_Cup_Qualification,Whitehawk,Oxford City,1,3
England-FA_Cup_Qualification,Stratford Town,Redditch United,4,1
England-FA_Cup_Qualification,Kingstonian,Brackley Town,0,3
England-FA_Cup_Qualification,Welling United,Haringey Borough,1,2
England-FA_Cup_Qualification,Boston United,Haughmond,1,1
England-FA_Cup_Qualification,Lancaster City,Droylsden,4,0
England-FA_Cup_Qualification,Bognor Regis Town,Weston Super Mare,2,1
England-FA_Cup_Qualification,Shildon AFC,Altrincham,1,0
England-FA_Cup_Qualification,Newcastle Benfield,Ashton United,2,1
England-FA_Cup_Qualification,Horsham,Herne Bay,2,5
England-FA_Cup_Qualification,Slough Town,Dulwich Hamlet,3,2
England-FA_Cup_Qualification,Kettering Town FC,Kidsgrove Athletic,2,0
England-FA_Cup_Qualification,Cheshunt,Dorking Wanderers,1,3
England-FA_Cup_Qualification,Chelmsford,Ramsgate,7,0
England-FA_Cup_Qualification,Spennymoor Town FC,Gainsborough,1,2
England-FA_Cup_Qualification,Cinderford Town,Hartley Wintney,1,0
England-FA_Cup_Qualification,Bath City,Knaphill,6,0
England-FA_Cup_Qualification,Grantham Town,Alvechurch,3,4
England-FA_Cup_Qualification,Dartford,Barking,3,1
England-FA_Cup_Qualification,Shepshed Dynamo,Nantwich Town,0,1
England-FA_Cup_Qualification,Kings Langley FC,Margate,0,1
England-FA_Cup_Qualification,Paulton Rovers,Kidlington,3,2
England-FA_Cup_Qualification,Westfields,Leamington,0,2
England-FA_Cup_Qualification,Stockport,Curzon,1,0
England-FA_Cup_Qualification,Bridport,Cadbury Heath,2,2
England-FA_Cup_Qualification,Scarborough Athletic,Sunderland RCA,2,0
Brazil-Serie_A,Gremio,Chapecoense AF,0,1
Brazil-Serie_A,Botafogo RJ,Santos FC,2,0
Brazil-Serie_A,Corinthians,Vasco da Gama,1,0
Brazil-Serie_A,Avai FC,Atletico MG,1,1
Brazil-Serie_A,Vitoria,Sao Paulo,1,2
Brazil-Serie_A,Atletico PR,Fluminense,3,1
Brazil-Serie_A,Ponte Preta,Atletico GO,1,3
Brazil-Serie_A,Flamengo,Sport Recife,2,0
England-Premier_League,Manchester United,Everton,4,0
England-Premier_League,Chelsea,Arsenal,0,0
England-FA_Cup_Qualification,Albion Sports AFC,Ashton Athletic,0,4
England-FA_Cup_Qualification,Thamesmead Town,Billericay,1,1
England-FA_Cup_Qualification,Stourbridge,St. Ives Town FC,2,0
England-FA_Cup_Qualification,FC Romania,Hayes &amp; Yeading United,2,2
England-FA_Cup_Qualification,1874 Northwich,North Ferriby United,1,0
France-Ligue_1,Amiens,Marseille,0,2
France-Ligue_1,Angers,Metz,0,1
France-Ligue_1,Paris Saint Germain,Lyon,2,0
France-Ligue_1,Rennes,Nice,0,1
Germany-1__Bundesliga,Borussia Dortmund,FC Cologne,5,0
Germany-1__Bundesliga,Bayer Leverkusen,Freiburg,4,0
Germany-1__Bundesliga,Hoffenheim,Hertha Berlin,1,1
Italy-Serie_A,SSC Napoli,Benevento,6,0
Italy-Serie_A,ChievoVerona,Atalanta,1,1
Italy-Serie_A,SPAL 2013,Cagliari,0,2
Italy-Serie_A,Genoa,Lazio,2,3
Italy-Serie_A,Sassuolo,Juventus,1,3
Italy-Serie_A,Torino,Sampdoria,2,2
Italy-Serie_A,AC Milan,Udinese,2,1
Netherlands-Eredivisie,ADO Den Haag,Ajax,1,1
Netherlands-Eredivisie,PSV Eindhoven,Feyenoord,1,0
Netherlands-Eredivisie,FC Twente,FC Utrecht,4,0
Netherlands-Eredivisie,Vitesse,VVV-Venlo,1,1
Portugal-Primeira_Liga,Belenenses,Estoril,2,1
Portugal-Primeira_Liga,Rio Ave,FC Porto,1,2
Portugal-Primeira_Liga,Braga,Vitoria de Guimaraes,2,1
Russia-Premier_League,SKA-Khabarovsk,FK Akhmat,2,2
Russia-Premier_League,Rubin Kazan,Ural,0,1
Russia-Premier_League,Tosno,Spartak Moscow,2,2
Spain-Primera_Division,Las Palmas,Athletic Bilbao,1,0
Brazil-Serie_A,Cruzeiro,Bahia,1,0
England-FA_Cup_Qualification,Cambridge City,St.Albans,0,2
Portugal-Primeira_Liga,Portimonense,Feirense,2,1
Portugal-Primeira_Liga,Chaves,Moreirense,3,0
Russia-Premier_League,Lokomotiv Moscow,Amkar,0,1
Russia-Premier_League,Zenit St. Petersburg,FC Ufa,3,0
Spain-Primera_Division,Espanyol,Celta Vigo,2,1
Argentina-Superliga,San Martin San Juan,River Plate,1,3
Bulgaria-First_Professional_League,Ludogorets Razgrad,Botev Plovdiv,2,1
Czech_Republic-1__Division,Viktoria Plzen,Zlin,2,1
Denmark-Superligaen,FC Nordsjaelland,AGF,1,2
Finland-Veikkausliiga,FC Inter,FC Lahti,1,6
Greece-Super_League,PAS Giannina,Panionios,1,1
Israel-Ligat_HaAl,Maccabi Netanya,Maccabi Tel Aviv,2,3
Italy-Serie_B,Avellino,Venezia,1,1
Mexico-Liga_MX_Apertura,Veracruz,Lobos de la BUAP,0,1
Norway-Eliteserien,Odds Ballklubb,Aalesund,3,2
Poland-Ekstraklasa,Lechia Gdansk,Jagiellonia Bialystok,3,3
Romania-Liga_I,Astra Giurgiu,FC Viitorul Constanta,3,1
Sweden-Allsvenskan,AFC Eskilstuna,GIF Sundsvall,1,2
Turkey-Super_Lig,Besiktas,Konyaspor,2,0
USA-USL,OKC Energy FC,Tulsa Roughnecks FC,2,0
USA-USL,Vancouver Whitecaps II,Orange County SC,1,2
France-Ligue_2,Lens,Quevilly,2,0
Iceland-Urvalsdeild,Vikingur Olafsvik,Vikingur Reykjavik,1,3
Italy-Serie_C_Grp__B,Calcio Padova,Vicenza,0,0
Sweden-Superettan,Helsingborg,Varbergs BoIS FC,2,0
Sweden-Superettan,Oesters IF,Trelleborgs FF,0,1
Turkey-1__Lig,Eskisehirspor,Umraniyespor,1,1
Albania-Kategoria_Superiore,Partizani,Kukesi,0,0
Albania-Kategoria_Superiore,KF Kamza,Skenderbeu,1,1
Argentina-Primera_B_Metropolitana,San Telmo,Club Atletico Estudiantes,2,1
Armenia-1__Division,Avan Academy,Pyunik II,2,0
Armenia-1__Division,Alashkert FC II,Banants II,0,1
Armenia-1__Division,Artsakh,Lori,0,1
Armenia-1__Division,Gandzasar II,Erebuni,4,1
Armenia-1__Division,Shirak II,Ararat II,0,0
Austria-Cup,SV Wimpassing,BW Linz,6,5
Belarus-Premier_League,Isloch,BATE Borisov,0,2
Bolivia-Primera_Division___Clausura_Adecuacion,Oriente Petrolero,Club Petrolero,2,2
Brazil-Serie_A,Palmeiras,Coritiba,1,0
England-FA_Cup_Qualification,Hyde United,Warrington Town,2,0
England-FA_Cup_Qualification,Enfield Town,Hanwell Town,5,0
England-FA_Cup_Qualification,Haughmond,Boston United,0,5
England-FA_Cup_Qualification,AFC Rushden &amp; Diamonds,Alfreton Town,1,3
England-FA_Cup_Qualification,Burgess Hill Town,Colney Heath,3,0
England-FA_Cup_Qualification,Phoenix Sports,Glebe,6,5
England-FA_Cup_Qualification,FC United of Manchester,Handsworth Parramore,6,2
England-FA_Cup_Qualification,Hayes &amp; Yeading United,FC Romania,2,0
England-FA_Cup_Qualification,Royston Town,Braintree Town,1,2
England-FA_Cup_Qualification,Potters Bar Town,Hampton &amp; Richmond,0,3
England-FA_Cup_Qualification,Billericay,Thamesmead Town,5,0
England-FA_Cup_Qualification,Rushall Olympic,AFC Mansfield,1,2
England-FA_Cup_Qualification,Wingate &amp; Finchley,Hemel Hempstead,1,2
Germany-1__Bundesliga,Wolfsburg,Werder Bremen,1,1
Germany-1__Bundesliga,Borussia Moenchengladbach,VfB Stuttgart,2,0
Germany-1__Bundesliga,Schalke 04,Bayern Munich,0,3
Germany-1__Bundesliga,Augsburg,RasenBallsport Leipzig,1,0
Italy-Serie_A,Bologna,Inter,1,1
Spain-Primera_Division,Valencia,Malaga,5,0
Spain-Primera_Division,Barcelona,Eibar,6,1
Argentina-Superliga,Gimnasia LP,Huracan,1,3
Argentina-Superliga,Temperley,Rosario Central,1,1
England-EFL_Cup,Brentford,Norwich City,1,3
England-EFL_Cup,Crystal Palace,Huddersfield Town,1,0
England-EFL_Cup,AFC Bournemouth,Brighton &amp; Hove Albion,1,0
England-EFL_Cup,Wolverhampton Wanderers,Bristol Rovers,1,0
England-EFL_Cup,Reading,Swansea City,0,2
England-EFL_Cup,Bristol City,Stoke City,2,0
England-EFL_Cup,Leicester City,Liverpool,2,0
England-EFL_Cup,Aston Villa,Middlesbrough,0,2
England-EFL_Cup,Tottenham Hotspur,Barnsley,1,0
England-EFL_Cup,Burnley,Leeds United,5,7
England-EFL_Cup,West Ham United,Bolton Wanderers,3,0
Germany-2__Bundesliga,Holstein Kiel,St. Pauli,0,1
Germany-2__Bundesliga,Kaiserslautern,Erzgebirge Aue,0,2
Germany-2__Bundesliga,Ingolstadt,Duisburg,2,2
Germany-2__Bundesliga,Sandhausen,Union Berlin,1,0
Italy-Serie_B,Cittadella,Cesena,4,0
Italy-Serie_B,Pescara,Entella,2,2
England-FA_Cup_Qualification,Bodmin Town,Bideford AFC,1,1
England-FA_Cup_Qualification,Cadbury Heath,Bridport,2,3
Germany-1__Bundesliga,Hamburger SV,Borussia Dortmund,0,3
Germany-1__Bundesliga,FC Cologne,Eintracht Frankfurt,0,1
Germany-1__Bundesliga,Hertha Berlin,Bayer Leverkusen,2,1
Germany-1__Bundesliga,Mainz 05,Hoffenheim,2,3
Germany-1__Bundesliga,Freiburg,Hannover 96,1,1
Italy-Serie_A,Genoa,ChievoVerona,1,1
Italy-Serie_A,Atalanta,Crotone,5,1
Italy-Serie_A,Lazio,SSC Napoli,1,4
Italy-Serie_A,Hellas Verona,Sampdoria,0,0
Italy-Serie_A,Benevento,Roma,0,4
Italy-Serie_A,AC Milan,SPAL 2013,2,0
Italy-Serie_A,Cagliari,Sassuolo,0,1
Italy-Serie_A,Juventus,Fiorentina,1,0
Italy-Serie_A,Udinese,Torino,2,3
Spain-Primera_Division,Deportivo La Coruna,Alaves,1,0
Spain-Primera_Division,Real Madrid,Real Betis,0,1
Spain-Primera_Division,Leganes,Girona,0,0
Spain-Primera_Division,Sevilla,Las Palmas,1,0
Spain-Primera_Division,Athletic Bilbao,Atletico Madrid,1,2
England-EFL_Cup,West Bromwich Albion,Manchester City,1,2
England-EFL_Cup,Arsenal,Doncaster Rovers,1,0
England-EFL_Cup,Chelsea,Nottingham Forest,5,1
England-EFL_Cup,Manchester United,Burton Albion,4,1
England-EFL_Cup,Everton,Sunderland,3,0
Germany-2__Bundesliga,FC Heidenheim,Darmstadt,2,2
Germany-2__Bundesliga,Eintracht Braunschweig,Greuther Fuerth,3,0
Germany-2__Bundesliga,Fortuna Duesseldorf,Jahn Regensburg,1,0
Germany-2__Bundesliga,Dynamo Dresden,Arminia Bielefeld,0,2
Netherlands-KNVB_Cup,Ajax (A),FC Utrecht,0,6
Netherlands-KNVB_Cup,CSV Apeldoorn,Willem II,2,4
Netherlands-KNVB_Cup,Capelle,Roda JC Kerkrade,0,5
Netherlands-KNVB_Cup,Feyenoord,ADO Den Haag,2,0
Netherlands-KNVB_Cup,Staphorst,Koninklijke HFC,2,3
Netherlands-KNVB_Cup,ASV de Dijk,HHC,2,1
Netherlands-KNVB_Cup,Excelsior,SC Heerenveen,1,2
Netherlands-KNVB_Cup,Katwijk,Ter Leede,4,0
Netherlands-KNVB_Cup,SVV Scheveningen,Ajax,1,5
Netherlands-KNVB_Cup,AVV Swift,Vitesse,5,3
International-Copa_Libertadores_Final_Stage,Gremio,Botafogo RJ,1,0
International-Copa_Libertadores_Final_Stage,Santos FC,Barcelona SC,0,1
Spain-Primera_Division,Levante,Real Sociedad,3,0
Spain-Primera_Division,Villarreal,Espanyol,0,0
Spain-Primera_Division,Celta Vigo,Getafe,1,1
Germany-2__Bundesliga,Nuernberg,Bochum,3,1
Netherlands-KNVB_Cup,USV Hercules,FC Groningen,2,4
Netherlands-KNVB_Cup,De Meern,PEC Zwolle,0,5
Netherlands-KNVB_Cup,Blauw Geel,VVV-Venlo,0,3
Netherlands-KNVB_Cup,SDC Putten,PSV Eindhoven,0,4
Norway-Eliteserien,Tromsoe,Odds Ballklubb,2,2
Romania-Liga_I,Gaz Metan Medias,Astra Giurgiu,0,0
Romania-Liga_I,CFR Cluj,FC FCSB,1,1
Romania-Liga_I,FC Viitorul Constanta,Juventus Bucuresti,3,0
Russia-Cup,Olimpiec Nizhny,FC Ufa,5,2
Russia-Cup,Ararat Moscow,SKA-Khabarovsk,1,2
Russia-Cup,Dinamo St Petersburg,Zenit St. Petersburg,3,2
Russia-Cup,Fakel,Amkar,0,4
Russia-Cup,FC Yenisey Krasnoyarsk,FK Akhmat,3,0
Russia-Cup,Krylya Sovetov Samara,Lokomotiv Moscow,3,2
Spain-Copa_del_Rey,Leonesa,Valladolid,0,4
Spain-Copa_del_Rey,Zaragoza,Lugo,1,0
Sweden-Allsvenskan,GIF Sundsvall,AIK,0,0
Sweden-Allsvenskan,Oerebro,AFC Eskilstuna,2,3
Switzerland-Super_League,Lugano,Sion,1,2
Switzerland-Super_League,Thun,Grasshopper,2,2
Turkey-Cup,Rizespor,Nevsehirspor Genclik,3,0
Turkey-Cup,Sivasspor,Bugsasspor,3,0
Turkey-Cup,Eyupspor,Sakaryaspor,2,1
Turkey-Cup,Afjet Afyonspor,Ankaragucu,2,0
Turkey-Cup,Afjet Afyonspor,Ankaragucu,2,0
Turkey-Cup,Kizilcabolukspor,Umraniyespor,2,1
Turkey-Cup,24 Erzincanspor,Eskisehirspor,4,2
USA-Major_League_Soccer,Atlanta United,LA Galaxy,4,0
USA-Major_League_Soccer,Toronto FC,Montreal Impact,3,5
USA-USL,Seattle Sounders FC II,Phoenix Rising FC,0,1
USA-USL,Reno 1868 FC,OKC Energy FC,3,0
USA-USL,Louisville City FC,Rochester Rhinos,2,1
USA-USL,Charleston Battery,Charlotte Independence,3,0
Belgium-Cup,Sporting Charleroi,UR La Louviere Centre,4,0
International-Copa_Libertadores_Final_Stage,Lanus,San Lorenzo,6,3
International-Copa_Libertadores_Final_Stage,River Plate,Jorge Wilstermann,8,0
France-Ligue_1,Nice,Angers,2,2
France-Ligue_1,Lille,Monaco,0,4
Germany-1__Bundesliga,Bayern Munich,Wolfsburg,2,2
Portugal-Primeira_Liga,FC Porto,Portimonense,5,2
Belgium-First_Division_A,Royal Antwerp,Kortrijk,3,0
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Dunav Ruse,3,0
Denmark-Superligaen,FC Nordsjaelland,SoenderjyskE,2,2
Germany-2__Bundesliga,Erzgebirge Aue,Sandhausen,1,0
Germany-2__Bundesliga,Duisburg,Holstein Kiel,1,3
Ireland-Premier_Division,Bohemian FC,St. Patrick's Athletic,3,2
Ireland-Premier_Division,Limerick,Cork City,2,1
Ireland-Premier_Division,Dundalk,Drogheda United,3,0
Ireland-Premier_Division,Shamrock Rovers,Finn Harps,4,1
Ireland-Premier_Division,Derry City,Bray Wanderers,0,5
Ireland-Premier_Division,Galway United FC,Sligo Rovers,3,1
Netherlands-Eerste_Divisie,Fortuna Sittard,Jong AZ Alkmaar,5,1
Netherlands-Eerste_Divisie,FC Emmen,Go Ahead Eagles,0,0
Netherlands-Eerste_Divisie,MVV Maastricht,Cambuur,1,1
Netherlands-Eerste_Divisie,Almere City FC,FC Oss,2,2
Netherlands-Eerste_Divisie,FC Volendam,De Graafschap,0,0
Netherlands-Eerste_Divisie,FC Eindhoven,FC Den Bosch,0,1
Netherlands-Eerste_Divisie,Helmond Sport,FC Dordrecht,1,2
Netherlands-Eerste_Divisie,RKC Waalwijk,Jong FC Utrecht,2,2
N__Ireland-Premiership,Warrenpoint Town,Linfield,1,4
Poland-Ekstraklasa,Slask Wroclaw,Lech Poznan,2,0
Poland-Ekstraklasa,Piast Gliwice,Arka Gdynia,0,1
Romania-Liga_I,CS Universitatea Craiova,FC Voluntari,1,1
Scotland-FA_Cup,Spartans FC,Vale of Leithen,3,0
Slovenia-Prva_Liga,Aluminij,Maribor,2,3
Spain-Segunda_Division,Almeria,Sevilla Atletico,3,0
Turkey-Super_Lig,Trabzonspor,Alanyaspor,3,4
International-CONCACAF_League,Santos de Guapiles,CD Arabe Unido,1,0
International-CONCACAF_League,CD Olimpia,CD Plaza Amador,1,1
International-Copa_Sudamericana,LDU de Quito,Fluminense,2,1
Egypt-Premier_League,Al Mokawloon Al Arab,Al-Ittihad Al-Sakandary,3,2
Egypt-Premier_League,Tanta,Wadi Degla FC,3,1
Egypt-Premier_League,Al Masry,El Zamalek,1,2
England-League_1,AFC Wimbledon,Milton Keynes Dons,0,2
England-Premier_League,Stoke City,Chelsea,0,4
England-Premier_League,Manchester City,Crystal Palace,5,0
England-Premier_League,Swansea City,Watford,1,2
England-Premier_League,Burnley,Huddersfield Town,0,0
England-Premier_League,West Ham United,Tottenham Hotspur,2,3
England-Premier_League,Leicester City,Liverpool,2,3
England-Premier_League,Southampton,Manchester United,0,1
England-Premier_League,Everton,AFC Bournemouth,2,1
France-Ligue_1,Metz,Troyes,0,1
France-Ligue_1,Caen,Amiens,1,0
France-Ligue_1,Lyon,Dijon,3,3
France-Ligue_1,Bordeaux,Guingamp,3,1
France-Ligue_1,Montpellier,Paris Saint Germain,0,0
Germany-1__Bundesliga,Borussia Dortmund,Borussia Moenchengladbach,6,1
Germany-1__Bundesliga,Werder Bremen,Freiburg,0,0
Germany-1__Bundesliga,RasenBallsport Leipzig,Eintracht Frankfurt,2,1
Germany-1__Bundesliga,Mainz 05,Hertha Berlin,1,0
Germany-1__Bundesliga,Hoffenheim,Schalke 04,2,0
Germany-1__Bundesliga,VfB Stuttgart,Augsburg,0,0
Italy-Serie_A,Juventus,Torino,4,0
Italy-Serie_A,SPAL 2013,SSC Napoli,2,3
Italy-Serie_A,Roma,Udinese,3,1
Netherlands-Eredivisie,ADO Den Haag,Sparta Rotterdam,1,0
Netherlands-Eredivisie,Willem II,SC Heerenveen,1,2
Netherlands-Eredivisie,Feyenoord,NAC Breda,0,2
Netherlands-Eredivisie,Heracles,Roda JC Kerkrade,2,1
Portugal-Primeira_Liga,Moreirense,Sporting CP,1,1
Portugal-Primeira_Liga,Benfica,Pacos de Ferreira,2,0
Portugal-Primeira_Liga,Estoril,Chaves,0,2
Russia-Premier_League,Dinamo Moscow,CSKA Moscow,0,0
Russia-Premier_League,Spartak Moscow,Anzhi Makhachkala,2,2
Spain-Primera_Division,Malaga,Athletic Bilbao,3,3
Spain-Primera_Division,Girona,Barcelona,0,3
Spain-Primera_Division,Alaves,Real Madrid,1,2
Spain-Primera_Division,Atletico Madrid,Sevilla,2,0
Argentina-Superliga,Belgrano,Tigre,0,0
Argentina-Superliga,Velez Sarsfield,Boca Juniors,0,4
Argentina-Superliga,Chacarita Juniors,Talleres,0,1
Argentina-Superliga,Arsenal Sarandi,Temperley,0,1
Argentina-Superliga,Patronato de Parana,Atletico Tucuman,2,1
Brazil-Serie_A,Atletico GO,Cruzeiro,1,2
Brazil-Serie_A,Fluminense,Palmeiras,0,1
Brazil-Serie_A,Flamengo,Avai FC,1,1
Brazil-Serie_A,Chapecoense AF,Ponte Preta,1,0
Brazil-Serie_A,Sao Paulo,Corinthians,1,1
Brazil-Serie_A,Coritiba,Botafogo RJ,2,3
Brazil-Serie_A,Santos FC,Atletico PR,1,0
England-Premier_League,Brighton &amp; Hove Albion,Newcastle United,1,0
France-Ligue_1,Strasbourg,Nantes,1,2
France-Ligue_1,Saint-Etienne,Rennes,2,2
France-Ligue_1,Marseille,Toulouse,2,0
Germany-1__Bundesliga,Bayer Leverkusen,Hamburger SV,3,0
Germany-1__Bundesliga,Hannover 96,FC Cologne,0,0
Italy-Serie_A,Sampdoria,AC Milan,2,0
Italy-Serie_A,Crotone,Benevento,2,0
Italy-Serie_A,Sassuolo,Bologna,0,1
Italy-Serie_A,Hellas Verona,Lazio,0,3
Italy-Serie_A,Fiorentina,Atalanta,1,1
Italy-Serie_A,Cagliari,ChievoVerona,0,2
Italy-Serie_A,Inter,Genoa,1,0
Netherlands-Eredivisie,AZ Alkmaar,Excelsior,0,2
Netherlands-Eredivisie,VVV-Venlo,PEC Zwolle,1,1
Netherlands-Eredivisie,FC Groningen,FC Twente,1,0
Netherlands-Eredivisie,FC Utrecht,PSV Eindhoven,1,7
Netherlands-Eredivisie,Ajax,Vitesse,1,2
Portugal-Primeira_Liga,Vitoria de Guimaraes,Maritimo,2,1
Portugal-Primeira_Liga,Aves,Rio Ave,0,0
Portugal-Primeira_Liga,Feirense,Belenenses,1,4
Portugal-Primeira_Liga,Tondela,Braga,1,2
Russia-Premier_League,FC Ufa,Arsenal Tula,1,0
Russia-Premier_League,FC Krasnodar,Zenit St. Petersburg,0,2
Russia-Premier_League,Ural,Tosno,3,1
Russia-Premier_League,FC Rostov,Lokomotiv Moscow,0,1
Spain-Primera_Division,Real Sociedad,Valencia,2,3
Spain-Primera_Division,Las Palmas,Leganes,0,2
Spain-Primera_Division,Espanyol,Deportivo La Coruna,4,1
Spain-Primera_Division,Getafe,Villarreal,4,0
Spain-Primera_Division,Eibar,Celta Vigo,0,4
Argentina-Superliga,Colon,Defensa y Justicia,3,1
Argentina-Superliga,Godoy Cruz,Independiente,1,0
Brazil-Serie_A,Atletico MG,Vitoria,1,3
Brazil-Serie_A,Bahia,Gremio,1,0
England-Premier_League,Arsenal,West Bromwich Albion,2,0
Portugal-Primeira_Liga,Vitoria de Setubal,Boavista,1,1
Russia-Premier_League,Amkar,SKA-Khabarovsk,3,0
Russia-Premier_League,FK Akhmat,Rubin Kazan,1,0
Spain-Primera_Division,Real Betis,Levante,4,0
Argentina-Superliga,Racing Club,San Martin San Juan,0,0
Bulgaria-First_Professional_League,Beroe,Levski Sofia,0,0
Croatia-1__Division,Rudes,Osijek,1,1
Czech_Republic-1__Division,Slovan Liberec,Slovacko,1,1
Denmark-Superligaen,AGF,FC Midtjylland,0,3
Finland-Veikkausliiga,JJK,FC Inter,1,3
Germany-2__Bundesliga,Union Berlin,Kaiserslautern,5,0
Greece-Super_League,Xanthi,Asteras Tripolis,0,0
Ireland-Premier_Division,St. Patrick's Athletic,Shamrock Rovers,2,0
Ireland-Premier_Division,Cork City,Dundalk,1,1
Israel-Ligat_HaAl,Beitar Jerusalem,Hapoel Ironi Kiryat Shmona,1,1
Italy-Serie_B,Palermo,Pro Vercelli,2,1
Netherlands-Eerste_Divisie,Jong PSV,NEC Nijmegen,3,3
Netherlands-Eerste_Divisie,Jong Ajax,Telstar,1,1
Norway-Eliteserien,Sarpsborg 08,Odds Ballklubb,2,1
Poland-Ekstraklasa,Cracovia,Wisla Plock,1,3
Romania-Liga_I,Botosani,FC Viitorul Constanta,1,0
Romania-Liga_I,Astra Giurgiu,CFR Cluj,2,3
Spain-Segunda_Division,Barcelona B,Lugo,1,2
Sweden-Allsvenskan,Malmoe FF,Elfsborg,6,0
Sweden-Allsvenskan,AFC Eskilstuna,IFK Gothenburg,1,0
Sweden-Allsvenskan,Sirius,Oerebro,3,4
Turkey-Super_Lig,Antalyaspor,Osmanlispor FK,3,0
USA-Major_League_Soccer,Portland Timbers,Orlando City,3,0
USA-USL,Vancouver Whitecaps II,Phoenix Rising FC,0,4
France-Ligue_2,Clermont Foot,Lens,1,0
Gibraltar-Premier_Division,Gibraltar United FC,Lynx,2,0
Gibraltar-Premier_Division,Manchester 62 FC,St Joseph's,1,2
Italy-Serie_C_Grp__A,Arezzo,Lucchese,0,1
Sweden-Superettan,IFK Vaernamo,GAIS,2,0
Turkey-1__Lig,Adana Demirspor,Adanaspor,1,0
Turkey-1__Lig,Umraniyespor,Denizlispor,4,2
Turkey-1__Lig,Balikesirspor,Rizespor,1,1
International-Champions_League_Grp__E,Sevilla,Maribor,3,0
International-Champions_League_Grp__E,Spartak Moscow,Liverpool,1,1
International-Champions_League_Grp__F,SSC Napoli,Feyenoord,3,1
International-Champions_League_Grp__F,Manchester City,Shakhtar Donetsk,2,0
International-Champions_League_Grp__G,Monaco,FC Porto,0,3
International-Champions_League_Grp__G,Besiktas,RasenBallsport Leipzig,2,0
International-Champions_League_Grp__H,APOEL Nicosia,Tottenham Hotspur,0,3
International-Champions_League_Grp__H,Borussia Dortmund,Real Madrid,1,3
Brazil-Serie_A,Sport Recife,Vasco da Gama,1,1
England-FA_Cup_Qualification,Bideford AFC,Bodmin Town,1,0
England-FA_Cup_Qualification,Heybridge Swifts,Metropolitan Police FC,5,4
International-AFC_Champions_League_Final_Stage,Al Hilal,Persepolis,4,0
Argentina-Superliga,Estudiantes,San Lorenzo,1,3
Argentina-Superliga,Lanus,Newells Old Boys,1,0
England-Championship,Nottingham Forest,Fulham,1,3
England-Championship,Cardiff City,Leeds United,3,1
England-Championship,Middlesbrough,Norwich City,0,1
England-Championship,Bristol City,Bolton Wanderers,2,0
England-Championship,Hull City,Preston North End,1,2
England-Championship,Barnsley,Queens Park Rangers,1,1
England-Championship,Millwall,Reading,2,1
England-Championship,Burton Albion,Aston Villa,0,4
England-Championship,Ipswich Town,Sunderland,5,2
England-Championship,Brentford,Derby County,1,1
International-AFC_Cup_Final_Stage,Al Quwa Al Jawiya,Al-Wahda,1,0
England-League_1,Oldham Athletic,Peterborough United,3,2
England-League_1,Walsall,Charlton Athletic,2,2
England-League_1,Bradford City,Fleetwood Town,0,3
England-League_1,Gillingham,Scunthorpe United,0,0
England-League_1,Portsmouth,Bristol Rovers,3,0
England-League_1,Blackburn Rovers,Rotherham United,2,0
England-League_1,Wigan Athletic,Plymouth Argyle,1,0
England-League_1,Bury,Oxford United,3,0
England-League_1,Milton Keynes Dons,Northampton Town,0,0
England-League_1,Southend United,AFC Wimbledon,1,0
England-League_1,Blackpool,Rochdale,0,0
England-League_1,Doncaster Rovers,Shrewsbury Town,1,2
England-League_2,Wycombe Wanderers,Crewe Alexandra,3,2
England-League_2,Chesterfield,Yeovil Town,2,3
England-League_2,Grimsby Town,Colchester United,2,2
International-Champions_League_Grp__A,Basel,Benfica,5,0
International-Champions_League_Grp__A,CSKA Moscow,Manchester United,1,4
International-Champions_League_Grp__B,Paris Saint Germain,Bayern Munich,3,0
International-Champions_League_Grp__B,Anderlecht,Celtic,0,3
International-Champions_League_Grp__C,Qarabag FK,Roma,1,2
International-Champions_League_Grp__C,Atletico Madrid,Chelsea,1,2
International-Champions_League_Grp__D,Sporting CP,Barcelona,0,1
International-Champions_League_Grp__D,Juventus,Olympiacos,2,0
International-AFC_Champions_League_Final_Stage,Shanghai SIPG FC,Urawa Red Diamonds,1,1
England-Championship,Birmingham City,Sheffield Wednesday,1,0
England-Championship,Sheffield United,Wolverhampton Wanderers,2,0
Finland-Veikkausliiga,HJK,IFK Mariehamn,1,0
Finland-Veikkausliiga,SJK,Ilves,0,0
Mexico-Liga_MX_Apertura,Veracruz,Monarcas Morelia,2,1
Mexico-Liga_MX_Apertura,CD Guadalajara,Lobos de la BUAP,1,2
Mexico-Liga_MX_Apertura,Puebla,Atlas,1,2
Mexico-Liga_MX_Apertura,Tijuana,Tigres,0,1
Romania-Liga_I,Dinamo Bucuresti,Concordia Chiajna,2,3
Switzerland-Super_League,Sion,Lausanne,1,1
USA-USL,Bethlehem Steel FC,Tampa Bay Rowdies,2,2
International-AFC_Cup_Final_Stage,FC Istiklol,Bengaluru FC,1,0
Brazil-Serie_B,Oeste FC,Londrina EC,4,1
Brazil-Serie_B,Brasil de Pelotas,Luverdense,0,1
Brazil-Serie_B,Paysandu,Guarani,2,1
Brazil-Serie_B,Parana Clube,Nautico,3,0
Brazil-Serie_B,Santa Cruz,Ceara,0,0
Brazil-Serie_B,Vila Nova,CRB,3,0
Brazil-Serie_B,Boa Esporte Clube,Goias,2,0
Brazil-Serie_B,Criciuma,Figueirense,1,1
Brazil-Serie_B,ABC,Juventude,1,1
Czech_Republic-Cup,Valasske Mezirici,Banik Ostrava,0,6
Denmark-DBU_Pokalen,Vendsyssel FF,SoenderjyskE,1,2
Denmark-DBU_Pokalen,Vejgaard,FC Nordsjaelland,0,4
Egypt-Premier_League,El Raja Marsa Matruh,El Entag El Harby,0,2
International-EURO_U17_Qualification_Grp__4,Finland U17,Iceland U17,0,0
International-EURO_U17_Qualification_Grp__4,Russia U17,Faroe Islands U17,3,1
Gibraltar-Premier_Division,Lions Gibraltar,Europa FC,2,1
Gibraltar-Premier_Division,Lincoln Red Imps FC,Glacis United,4,0
Kosovo-Superliga,Liria,Drenica,1,0
Kosovo-Superliga,Trepca 89,Llapi,3,1
International-Europa_League_Grp__A,Maccabi Tel Aviv,Villarreal,0,0
International-Europa_League_Grp__A,FC Astana,Slavia Prague,1,1
International-Europa_League_Grp__B,Skenderbeu,Young Boys,1,1
International-Europa_League_Grp__B,Partizan Beograd,Dynamo Kyiv,2,3
International-Europa_League_Grp__C,Ludogorets Razgrad,Hoffenheim,2,1
International-Europa_League_Grp__C,Braga,Istanbul Basaksehir,2,1
International-Europa_League_Grp__D,AEK Athens,Austria Wien,2,2
International-Europa_League_Grp__D,AC Milan,Rijeka,3,2
International-Europa_League_Grp__E,Everton,Apollon Limassol,2,2
International-Europa_League_Grp__E,Lyon,Atalanta,1,1
International-Europa_League_Grp__F,FC Sheriff,FC Koebenhavn,0,0
International-Europa_League_Grp__F,Lokomotiv Moscow,Zlin,3,0
International-Europa_League_Grp__G,Viktoria Plzen,Hapoel Beer Sheva,3,1
International-Europa_League_Grp__G,Lugano,FC FCSB,1,2
International-Europa_League_Grp__H,BATE Borisov,Arsenal,2,4
International-Europa_League_Grp__H,FC Cologne,FK Crvena Zvezda,0,1
International-Europa_League_Grp__I,Konyaspor,Vitoria de Guimaraes,2,1
International-Europa_League_Grp__I,Salzburg,Marseille,1,0
International-Europa_League_Grp__J,Athletic Bilbao,Zorya,0,1
International-Europa_League_Grp__J,Oestersunds FK,Hertha Berlin,1,0
International-Europa_League_Grp__K,Nice,Vitesse,3,0
International-Europa_League_Grp__K,Lazio,Zulte-Waregem,2,0
International-Europa_League_Grp__L,Rosenborg,FK Vardar Skopje,3,1
International-Europa_League_Grp__L,Zenit St. Petersburg,Real Sociedad,3,1
Mexico-Liga_MX_Apertura,Necaxa,Queretaro FC,1,0
Mexico-Liga_MX_Apertura,Toluca,Pumas,2,1
Mexico-Liga_MX_Apertura,Leon,CF America,2,1
Mexico-Liga_MX_Apertura,Pachuca,Cruz Azul,4,0
Mexico-Liga_MX_Apertura,Monterrey,Santos,1
USA-Major_League_Soccer,San Jose Earthquakes,Chicago Fire,1,4
USA-Major_League_Soccer,Atlanta United,Philadelphia Union,3,0
USA-Major_League_Soccer,Orlando City,New England Rev.,6,1
USA-Major_League_Soccer,Houston Dynamo,LA Galaxy,3,3
USA-Major_League_Soccer,Seattle Sounders FC,Vancouver Whitecaps,3,0
USA-Major_League_Soccer,New York Red Bulls,DC United,3,3
USA-Major_League_Soccer,Montreal Impact,New York City FC,0,1
USA-Major_League_Soccer,FC Dallas,Colorado Rapids,2,0
USA-USL,Penn FC,Ottawa Fury,1,0
USA-USL,Sacramento Republic FC,Real Monarchs SLC,0,2
USA-USL,Swope Park Rangers,LA Galaxy II,3,0
France-Ligue_1,Monaco,Montpellier,1,1
Germany-1__Bundesliga,Schalke 04,Bayer Leverkusen,1,1
Netherlands-Eredivisie,FC Twente,Heracles,2,1
Portugal-Primeira_Liga,Chaves,Tondela,1,1
Russia-Premier_League,Arsenal Tula,FC Krasnodar,1,0
Spain-Primera_Division,Celta Vigo,Girona,3,3
Belgium-First_Division_A,St.Truiden,Sporting Charleroi,0,1
Bulgaria-First_Professional_League,Vereya,Slavia Sofia,1,1
Bulgaria-First_Professional_League,Lokomotiv Plovdiv,Septemvri Sofia,1,0
International-CAF_Champions_League_Final_Stage,USM Alger,Wydad Casablanca,0,0
Croatia-1__Division,NK Lokomotiva,Slaven,0,0
Czech_Republic-1__Division,Teplice,Slovan Liberec,2,1
Denmark-Superligaen,FC Helsingoer,AGF,1,5
Denmark-Superligaen,Randers FC,AC Horsens,0,1
England-Championship,Queens Park Rangers,Fulham,1,2
Finland-Veikkausliiga,FC Inter,KuPS,1,2
Finland-Veikkausliiga,VPS,HIFK,1,2
Germany-2__Bundesliga,Ingolstadt,Darmstadt,3,0
Germany-2__Bundesliga,Kaiserslautern,Greuther Fuerth,3,0
Ireland-Premier_Division,Derry City,Drogheda United,2,1
Italy-Serie_B,Parma Calcio 1913,Salernitana,2,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,FC Eindhoven,1,2
Netherlands-Eerste_Divisie,Jong FC Utrecht,Helmond Sport,0,0
Netherlands-Eerste_Divisie,FC Den Bosch,Jong PSV,5,0
Netherlands-Eerste_Divisie,FC Oss,Jong Ajax,0,3
Netherlands-Eerste_Divisie,FC Dordrecht,FC Volendam,2,2
Netherlands-Eerste_Divisie,De Graafschap,FC Emmen,2,2
Netherlands-Eerste_Divisie,Telstar,Fortuna Sittard,0,6
Netherlands-Eerste_Divisie,Cambuur,RKC Waalwijk,1,1
Netherlands-Eerste_Divisie,Go Ahead Eagles,Almere City FC,2,1
Netherlands-Eerste_Divisie,NEC Nijmegen,MVV Maastricht,4,1
N__Ireland-Premiership,Glenavon,Dungannon Swifts,1,1
Norway-Eliteserien,Brann,Kristiansund BK,0,4
Poland-Ekstraklasa,Arka Gdynia,Cracovia,1,1
Poland-Ekstraklasa,Sandecja Nowy Sacz,Slask Wroclaw,1,1
Romania-Liga_I,ACS Poli Timisoara,CS Universitatea Craiova,0,2
Romania-Liga_I,Gaz Metan Medias,Botosani,1,0
Scotland-Premiership,Hamilton Academical,Rangers,1,4
Slovenia-Prva_Liga,NK Celje,Domzale,1,1
Spain-Segunda_Division,Leonesa,Almeria,0,0
Brazil-Serie_A,Vasco da Gama,Chapecoense AF,1,1
Brazil-Serie_A,Bahia,Coritiba,1,1
England-Premier_League,Stoke City,Southampton,2,1
England-Premier_League,Chelsea,Manchester City,0,1
England-Premier_League,Huddersfield Town,Tottenham Hotspur,0,4
England-Premier_League,AFC Bournemouth,Leicester City,0,0
England-Premier_League,West Bromwich Albion,Watford,2,2
England-Premier_League,Manchester United,Crystal Palace,4,0
England-Premier_League,West Ham United,Swansea City,1,0
England-FA_Cup_Qualification,South Shields,York City,3,2
England-FA_Cup_Qualification,Boston Town,Hyde United,2,3
England-FA_Cup_Qualification,Newcastle Benfield,Kidderminster Harriers,0,1
England-FA_Cup_Qualification,Oxford City,Leiston,4,2
England-FA_Cup_Qualification,St.Albans,Bridport,2,1
England-FA_Cup_Qualification,Hereford,Hornchurch,2,0
England-FA_Cup_Qualification,Enfield Town,Phoenix Sports,3,0
England-FA_Cup_Qualification,Scarborough Athletic,Stratford Town,2,2
England-FA_Cup_Qualification,Eastbourne Borough,Bognor Regis Town,0,2
England-FA_Cup_Qualification,Buxton,Alvechurch,2,1
England-FA_Cup_Qualification,Ashford Town,Leatherhead,1,2
England-FA_Cup_Qualification,1874 Northwich,Ossett Town,2,2
England-FA_Cup_Qualification,East Thurrock United,Harlow Town,2,2
England-FA_Cup_Qualification,Heybridge Swifts,Frome Town,2,1
England-FA_Cup_Qualification,Hungerford Town,Billericay,1,1
England-FA_Cup_Qualification,Harrogate,Bradford PA,0,0
England-FA_Cup_Qualification,Stockport,FC United of Manchester,3,3
England-FA_Cup_Qualification,Ashton Athletic,Chorley,0,1
England-FA_Cup_Qualification,Nantwich Town,Nuneaton Town,3,1
England-FA_Cup_Qualification,Margate,Herne Bay,2,0
England-FA_Cup_Qualification,Brackley Town,Braintree Town,4,1
England-FA_Cup_Qualification,Slough Town,Poole Town FC,2,1
England-FA_Cup_Qualification,Basford United,Kettering Town FC,2,3
England-FA_Cup_Qualification,Needham Market,Dartford,1,6
England-FA_Cup_Qualification,Hayes &amp; Yeading United,Havant and Waterlooville,0,4
England-FA_Cup_Qualification,Leamington,Gainsborough,0,0
England-FA_Cup_Qualification,AFC Mansfield,Boston United,0,2
England-FA_Cup_Qualification,Stafford Rangers,Telford,1,1
England-FA_Cup_Qualification,Chelmsford,Weymouth,2,1
England-FA_Cup_Qualification,Burgess Hill Town,Wealdstone,1,0
England-FA_Cup_Qualification,Swindon Supermarine,Paulton Rovers,2,3
Brazil-Serie_A,Botafogo RJ,Vitoria,2,3
Brazil-Serie_A,Gremio,Fluminense,1,0
Brazil-Serie_A,Avai FC,Atletico GO,0,2
Brazil-Serie_A,Palmeiras,Santos FC,0,1
Brazil-Serie_A,Sao Paulo,Sport Recife,1,0
Brazil-Serie_A,Cruzeiro,Corinthians,1,1
England-Premier_League,Newcastle United,Liverpool,1,1
England-Premier_League,Arsenal,Brighton &amp; Hove Albion,2,0
England-Premier_League,Everton,Burnley,0,1
France-Ligue_1,Troyes,Saint-Etienne,2,1
France-Ligue_1,Angers,Lyon,3,3
France-Ligue_1,Nice,Marseille,2,4
Germany-1__Bundesliga,Hertha Berlin,Bayern Munich,2,2
Germany-1__Bundesliga,FC Cologne,RasenBallsport Leipzig,1,2
Germany-1__Bundesliga,Freiburg,Hoffenheim,3,2
Italy-Serie_A,Benevento,Inter,1,2
Italy-Serie_A,SPAL 2013,Crotone,1,1
Italy-Serie_A,AC Milan,Roma,0,2
Italy-Serie_A,ChievoVerona,Fiorentina,2,1
Italy-Serie_A,SSC Napoli,Cagliari,3,0
Italy-Serie_A,Torino,Hellas Verona,2,2
Italy-Serie_A,Atalanta,Juventus,2,2
Italy-Serie_A,Lazio,Sassuolo,6,1
Netherlands-Eredivisie,Vitesse,FC Utrecht,1,1
Netherlands-Eredivisie,Sparta Rotterdam,Roda JC Kerkrade,1,2
Netherlands-Eredivisie,AZ Alkmaar,Feyenoord,0,4
Netherlands-Eredivisie,SC Heerenveen,Ajax,0,4
Portugal-Primeira_Liga,Sporting CP,FC Porto,0,0
Portugal-Primeira_Liga,Belenenses,Vitoria de Guimaraes,1,0
Portugal-Primeira_Liga,Braga,Estoril,6,0
Portugal-Primeira_Liga,Maritimo,Benfica,1,1
Russia-Premier_League,Lokomotiv Moscow,Dinamo Moscow,3,0
Russia-Premier_League,Anzhi Makhachkala,Zenit St. Petersburg,2,2
Russia-Premier_League,CSKA Moscow,FC Ufa,0,0
Spain-Primera_Division,Real Sociedad,Real Betis,4,4
Spain-Primera_Division,Valencia,Athletic Bilbao,3,2
Spain-Primera_Division,Real Madrid,Espanyol,2,0
Spain-Primera_Division,Barcelona,Las Palmas,3,0
Spain-Primera_Division,Villarreal,Eibar,3,0
Argentina-Superliga,Boca Juniors,Chacarita Juniors,1,0
Brazil-Serie_A,Atletico PR,Atletico MG,0,2
England-FA_Cup_Qualification,Bradford PA,Harrogate,0,2
Argentina-Superliga,Tigre,River Plate,1,1
International-EURO_U21_Qualification_Grp__7,Armenia U21,Gibraltar U21,1,0
International-Friendlies,Laos,Macau,1,3
International-Friendlies,India,Palestine,
Germany-2__Bundesliga,Fortuna Duesseldorf,Duisburg,3,1
Greece-Super_League,Lamia,Panionios,1,0
Israel-Ligat_HaAl,Bnei Sakhnin,Beitar Jerusalem,3,2
Israel-Ligat_HaAl,Maccabi Netanya,Maccabi Petach Tikva,4,0
Italy-Serie_B,Frosinone,Cremonese,0,0
Mexico-Liga_MX_Apertura,Santos,Puebla,0,0
N__Ireland-Premiership,Glentoran,Crusaders,0,3
Romania-Liga_I,FC Voluntari,Concordia Chiajna,0,1
Spain-Segunda_Division,Real Oviedo,Zaragoza,2,2
USA-USL,OKC Energy FC,LA Galaxy II,3,0
International-EURO_U17_Qualification_grp__8,Bosnia and Herzegovina U17,Macedonia U17,0,0
International-EURO_U17_Qualification_grp__8,Moldova U17,Slovakia U17,0,2
France-Ligue_2,Le Havre,Lorient,3,2
Italy-Serie_C_Grp__B,FeralpiSalo,Pordenone Calcio,0,0
Kosovo-Superliga,Gjilani,KF Flamurtari,1,0
Kosovo-Superliga,Feronikeli,Drita,1,1
Sweden-Superettan,Trelleborgs FF,Varbergs BoIS FC,1,1
Sweden-Superettan,Gefle,Helsingborg,2,1
Albania-Kategoria_Superiore,Kukesi,Skenderbeu,1,2
Albania-Kategoria_Superiore,Partizani,Lushnja,0,0
Argentina-Primera_B_Nacional,Nueva Chicago,All Boys,2,0
Argentina-Primera_B_Metropolitana,Villa San Carlos,CA Defensores de Belgrano,0,2
Argentina-Primera_B_Metropolitana,San Telmo,Barracas Central,1,1
Argentina-Primera_C,Deportivo Merlo,Laferrere,3,1
Argentina-Primera_C,Club Lujan,CA Ferrocarril Midland,0,1
Argentina-Primera_C,Ituzaingo,Central Cordoba de Rosario,0,2
Bosnia_Herzegovina-Premier_League,FK Mladost Doboj Kakanj,Celik Zenica,4,0
Brazil-Serie_C_Final_Stage,Sao Bento,CS Alagoano,0,1
Bulgaria-Second_Professional_League,Pomorie,PFC Lokomotiv Sofia 1929,2,3
Chile-Primera_B_Torneo_de_Transicion,Rangers,Cobresal,2,0
Colombia-Primera_A_Clausura,America de Cali,Cortulua,2,1
Colombia-Primera_A_Clausura,Deportivo Pasto,Bucaramanga,0,0
Colombia-Primera_A_Clausura,CD Jaguares,Tigres FC,1,0
Colombia-Primera_A_Clausura,La Equidad,Patriotas,4,1
Brazil-Serie_A,Ponte Preta,Flamengo,1,0
England-FA_Cup_Qualification,Billericay,Hungerford Town,6,1
England-FA_Cup_Qualification,Telford,Stafford Rangers,4,1
England-FA_Cup_Qualification,Gainsborough,Leamington,2,0
England-FA_Cup_Qualification,Stratford Town,Scarborough Athletic,1,4
England-FA_Cup_Qualification,Harlow Town,East Thurrock United,1,2
England-FA_Cup_Qualification,Ossett Town,1874 Northwich,6,5
England-FA_Cup_Qualification,FC United of Manchester,Stockport,1,0
Argentina-Superliga,Banfield,Arsenal Sarandi,1,2
Argentina-Superliga,Newells Old Boys,Godoy Cruz,0,0
Italy-Serie_B,Ternana,Brescia,1,1
Belgium-First_Division_B_1st_Stage,Cercle Brugge,Oud-Heverlee,0,3
England-EFL_Trophy_Northern_Grp__A,Fleetwood Town,Morecambe,2,1
England-EFL_Trophy_Northern_Grp__A,Carlisle United,Leicester City Academy,0,1
England-EFL_Trophy_Northern_Grp__B,Accrington Stanley,Blackpool,1,2
England-EFL_Trophy_Northern_Grp__C,Blackburn Rovers,Bury,0,1
England-EFL_Trophy_Northern_Grp__C,Rochdale,Stoke City Academy,4,5
England-EFL_Trophy_Northern_Grp__D,Crewe Alexandra,Oldham Athletic,0,1
England-EFL_Trophy_Northern_Grp__D,Port Vale,Newcastle Academy,1,0
England-EFL_Trophy_Northern_Grp__E,Walsall,Coventry City,5,6
England-EFL_Trophy_Northern_Grp__E,Shrewsbury Town,West Bromwich Albion Academy,3,0
England-EFL_Trophy_Northern_Grp__F,Rotherham United,Chesterfield,1,2
England-EFL_Trophy_Northern_Grp__H,Doncaster Rovers,Sunderland Academy,1,0
England-EFL_Trophy_Northern_Grp__H,Scunthorpe United,Grimsby Town,2,1
England-EFL_Trophy_Southern_Grp__A,Portsmouth,Crawley Town,3,1
England-EFL_Trophy_Southern_Grp__B,Colchester United,Gillingham,0,1
England-EFL_Trophy_Southern_Grp__B,Southend United,Reading Academy,1,0
England-EFL_Trophy_Southern_Grp__D,Plymouth Argyle,Exeter City,7,5
England-EFL_Trophy_Southern_Grp__E,Cheltenham Town,Forest Green Rovers,1,2
England-EFL_Trophy_Southern_Grp__F,AFC Wimbledon,Tottenham Academy,4,3
England-EFL_Trophy_Southern_Grp__F,Luton Town,Barnet,5,4
England-EFL_Trophy_Southern_Grp__G,Oxford United,Brighton &amp; Hove Albion Academy,6,7
England-EFL_Trophy_Southern_Grp__G,Milton Keynes Dons,Stevenage,5,4
England-EFL_Trophy_Southern_Grp__H,Peterborough United,Northampton Town,3,5
England-EFL_Trophy_Southern_Grp__H,Cambridge United,Southampton Academy,0,1
International-EURO_U17_Qualification_Grp__4,Iceland U17,Russia U17,2,0
International-EURO_U17_Qualification_Grp__4,Faroe Islands U17,Finland U17,0,4
International-EURO_U19_Qualification_Grp__6,Austria U19,Kosovo U19,1,0
International-EURO_U19_Qualification_Grp__6,Lithuania U19,Israel U19,0,1
Italy-Serie_C_Grp__C,Siracusa Calcio,Matera,1,2
International-Friendlies,Oman,Jordan,1,1
International-Friendlies,Afghanistan,Tajikistan,
USA-Major_League_Soccer,Atlanta United,Minnesota United,2,3
Belgium-First_Division_B_1st_Stage,Westerlo,Union St.-Gilloise,0,3
Belgium-First_Division_B_1st_Stage,Tubize,KFCO Beerschot-Wilrijk,0,1
Brazil-Serie_B,Brasil de Pelotas,Juventude,1,0
Brazil-Serie_B,Parana Clube,Internacional,1,0
Brazil-Serie_B,Ceara,Vila Nova,2,0
International-Club_Friendlies,VVV-Venlo,De Treffers,5,0
International-Club_Friendlies,Jong Vitesse,PEC Zwolle,1,0
International-Club_Friendlies,Admira Moedling,Wiener Neustadt,1,2
International-Club_Friendlies,CD Badajoz,Alaves,2,0
International-Club_Friendlies,Wolfsburg,FC Utrecht,2,0
International-Club_Friendlies,Gimnastica Segoviana,Getafe,1,2
Czech_Republic-Cup,Pisek,Zlin,0,2
Czech_Republic-Cup,Usti nad Labem,Slovacko,0,2
International-EURO_U19_Qualification_Grp__12,Ukraine U19,Albania U19,1,0
International-EURO_U19_Qualification_Grp__12,Norway U19,Montenegro U19,3,0
International-EURO_U19_Qualification_Grp__2,Germany U19,Belarus U19,5,1
International-EURO_U19_Qualification_Grp__2,N.Ireland U19,Poland U19,1,2
International-EURO_U19_Qualification_Grp__4,Netherlands U19,Malta U19,3,0
International-EURO_U19_Qualification_Grp__4,Hungary U19,Slovenia U19,2,1
International-EURO_U19_Qualification_Grp__7,Serbia U19,Cyprus U19,1,0
International-EURO_U19_Qualification_Grp__7,Azerbaijan U19,Ireland U19,0,0
International-EURO_U19_Qualification_Grp__9,Estonia U19,Sweden U19,0,4
International-EURO_U19_Qualification_Grp__9,Italy U19,Moldova U19,4,0
Italy-Serie_C_Grp__A,Monza,Alessandria,1,1
Italy-Serie_C_Grp__A,Olbia,Pistoiese,0,0
Italy-Serie_C_Grp__A,Prato,Carrarese,2,5
Italy-Serie_C_Grp__A,Robur Siena,Giana Erminio,0,0
Italy-Serie_C_Grp__A,Arezzo,Pontedera,2,1
Italy-Serie_C_Grp__A,Viterbese,Pro Piacenza,1,0
Italy-Serie_C_Grp__A,Piacenza,US Gavorrano,3,0
Italy-Serie_C_Grp__A,Pisa,Arzachena,1,0
Italy-Serie_C_Grp__A,Cuneo,Lucchese,0,3
Italy-Serie_C_Grp__B,AlbinoLeffe,Triestina,0,0
Italy-Serie_C_Grp__B,Fermana,Bassano Virtus,0,1
Italy-Serie_C_Grp__B,Ravenna,Calcio Padova,0,2
Italy-Serie_C_Grp__B,Mestre,Sambenedettese,1,2
Italy-Serie_C_Grp__B,Sudtirol,Modena,1
International-World_Cup_Qualification_AFC_4th_Round,Syria,Australia,1,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Bolivia,Brazil,0,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Venezuela,Uruguay,0,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Azerbaijan,Czech Republic,1,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,N.Ireland,Germany,1,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,San Marino,Norway,0,8
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Montenegro,Denmark,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Armenia,Poland,1,6
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Romania,Kazakhstan,3,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,England,Slovenia,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Malta,Lithuania,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Scotland,Slovakia,1,0
International-EURO_U21_Qualification_Grp__1,Moldova U21,Greece U21,0,2
International-EURO_U21_Qualification_Grp__1,Croatia U21,Belarus U21,2,1
International-EURO_U21_Qualification_Grp__2,Slovakia U21,Iceland U21,0,2
International-EURO_U21_Qualification_Grp__5,Ireland U21,Norway U21,0,0
International-EURO_U21_Qualification_Grp__6,Cyprus U21,Turkey U21,2,1
International-EURO_U21_Qualification_Grp__8,Liechtenstein U21,Wales U21,1,3
International-EURO_U21_Qualification_Grp__9,France U21,Montenegro U21,2,1
International-EURO_U21_Qualification_Grp__9,Luxembourg U21,Slovenia U21,1,1
International-Friendlies,Myanmar,Thailand,1,3
International-Friendlies,Iraq,Kenya,2,1
International-Friendlies,Hong Kong,Laos,4,0
International-Friendlies,Qatar,Singapore,3,1
International-Friendlies,Chinese Taipei,Mongolia,4,2
International-Friendlies,Iran,Togo,2,0
USA-USL,Phoenix Rising FC,Tulsa Roughnecks FC,4,3
USA-USL,Tampa Bay Rowdies,New York Red Bulls II,3,2
USA-USL,Orange County SC,Sacramento Republic FC,3,1
Belgium-First_Division_B_1st_Stage,Roeselare,Lierse,2,0
International-Club_Friendlies,Austria Wien,Hartberg,0,3
International-Club_Friendlies,Amstetten,Mattersburg,0,2
International-Club_Friendlies,Celta Vigo,Pachuca,4,3
International-Club_Friendlies,Heracles,Bochum,
International-Club_Friendlies,Bayer Leverkusen,Fortuna Koeln,4,0
International-Club_Friendlies,St.Truiden,Roda JC Kerkrade,2,0
International-Club_Friendlies,Luzern,Aarau,5,0
International-Club_Friendlies,Deportivo La Coruna,Corinthians,7,0
International-Club_Friendlies,Freiburg,Strasbourg,1,2
International-Club_Friendlies,Cagliari,Budoni,6,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Mali,Ivory Coast,0,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Argentina,Peru,0,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Colombia,Paraguay,1,2
International-World_Cup_Qualification_CONMEBOL_1st_round,Chile,Ecuador,2,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Austria,Serbia,3,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Ireland,Moldova,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Georgia,Wales,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Liechtenstein,Israel,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Spain,Albania,3,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Italy,Macedonia,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Croatia,Finland,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Turkey,Iceland,0,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Kosovo,Ukraine,0,2
Australia-A_League,Melbourne City FC,Brisbane Roar FC,2,0
International-EURO_U21_Qualification_Grp__3,Poland U21,Finland U21,3,3
International-EURO_U21_Qualification_Grp__3,Denmark U21,Georgia U21,5,2
International-EURO_U21_Qualification_Grp__4,England U21,Scotland U21,3,1
International-EURO_U21_Qualification_Grp__4,Netherlands U21,Latvia U21,3,0
International-EURO_U21_Qualification_Grp__5,Germany U21,Azerbaijan U21,6,1
International-EURO_U21_Qualification_Grp__6,Belgium U21,Sweden U21,1,1
International-EURO_U21_Qualification_Grp__7,Russia U21,Austria U21,1,0
International-EURO_U21_Qualification_Grp__7,Macedonia U21,Serbia U21,0,2
International-EURO_U21_Qualification_Grp__8,Switzerland U21,Romania U21,0,2
International-EURO_U21_Qualification_Grp__9,Bulgaria U21,Kazakhstan U21,2,2
International-Friendlies,Mauritania,Comoros,0,1
International-Friendlies,Japan,New Zealand,2,1
Netherlands-Eerste_Divisie,FC Volendam,Telstar,3,4
Netherlands-Eerste_Divisie,Jong Ajax,Jong FC Utrecht,2,1
Netherlands-Eerste_Divisie,FC Emmen,Cambuur,2,0
Netherlands-Eerste_Divisie,FC Dordrecht,FC Eindhoven,4,3
Netherlands-Eerste_Divisie,Jong PSV,Jong AZ Alkmaar,1,2
Netherlands-Eerste_Divisie,FC Oss,Go Ahead Eagles,1,6
Netherlands-Eerste_Divisie,Helmond Sport,De Graafschap,0,2
Netherlands-Eerste_Divisie,Fortuna Sittard,NEC Nijmegen,1,2
Netherlands-Eerste_Divisie,Almere City FC,MVV Maastricht,3,2
International-World_Cup_U17_Grp__A,India U17,USA U17,0,3
International-World_Cup_U17_Grp__A,Colombia U17,Ghana U17,0,1
International-World_Cup_U17_Grp__B,Paraguay U17,Mali U17,3,2
International-World_Cup_U17_Grp__B,New Zealand U17,Turkey U17,1,1
International-Club_Friendlies,Sochaux,Dijon,3,2
Brazil-Serie_A,Cruzeiro,Ponte Preta,2,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,Libya,DR Congo,1,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,Guinea,Tunisia,1,4
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Cameroon,Algeria,2,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Nigeria,Zambia,1,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Morocco,Gabon,3,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,Cape Verde,Senegal,0,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,South Africa,Burkina Faso,3,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Uganda,Ghana,0,0
International-World_Cup_Qualification_CONCACAF_Final_Stage,Mexico,Trinidad and Tobago,3,1
International-World_Cup_Qualification_CONCACAF_Final_Stage,USA,Panama,4,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Belarus,Netherlands,1,3
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Sweden,Luxembourg,8,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Bulgaria,France,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Switzerland,Hungary,5,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Faroe Islands,Latvia,0,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Andorra,Portugal,0,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Gibraltar,Estonia,0,6
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Cyprus,Greece,1,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Bosnia and Herzegovina,Belgium,3,4
Australia-A_League,Melbourne Victory,Sydney FC,0,1
Australia-A_League,Central Coast Mariners,Newcastle Jets,1,5
International-Friendlies,Russia,South Korea,4,2
International-Friendlies,Tanzania,Malawi,1,1
International-Friendlies,Grenada,Guyana,1,0
International-Friendlies,Saudi Arabia,Jamaica,5,2
Ireland-Premier_Division,Finn Harps,Dundalk,0,2
Ireland-Premier_Division,Bray Wanderers,Galway United FC,3,3
Ireland-Premier_Division,St. Patrick's Athletic,Limerick,2,2
Ireland-Premier_Division,Sligo Rovers,Bohemian FC,1,0
Ireland-Premier_Division,Drogheda United,Shamrock Rovers,0,2
Italy-Serie_B,Salernitana,Ascoli Picchio FC 1898,0,0
Italy-Serie_B,Cesena,Spezia,1,0
N__Ireland-Premiership,Dungannon Swifts,Ballymena United,2,1
N__Ireland-Premiership,Ards,Glentoran,0,1
N__Ireland-Premiership,Cliftonville,Warrenpoint Town,2,0
Spain-Segunda_Division,Sporting Gijon,Sevilla Atletico,3,0
Spain-Segunda_Division,Reus,Leonesa,1,1
Spain-Segunda_Division,Cadiz,Osasuna,0,2
Spain-Segunda_Division,Tenerife,Gimnastic,2,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Egypt,Congo,2,1
International-World_Cup_Qualification_CONCACAF_Final_Stage,Costa Rica,Honduras,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Czech Republic,San Marino,5,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Germany,Azerbaijan,5,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__C,Norway,N.Ireland,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Kazakhstan,Armenia,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Poland,Montenegro,4,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__E,Denmark,Romania,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Slovakia,Malta,3,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Slovenia,Scotland,2,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__F,Lithuania,England,0,1
Argentina-Superliga,Argentinos Juniors,Chacarita Juniors,1,0
Australia-A_League,Wellington Phoenix,Adelaide United,1,1
Australia-A_League,Western Sydney Wanderers FC,Perth Glory,2,1
International-Friendlies,Canada,El Salvador,0,1
International-Friendlies,Thailand,Kenya,1,0
Italy-Serie_B,Bari,Avellino,2,1
Italy-Serie_B,Palermo,Parma Calcio 1913,1,1
Italy-Serie_B,Venezia,Carpi,2,0
Italy-Serie_B,Cremonese,Ternana,3,3
Italy-Serie_B,Perugia,Pro Vercelli,1,5
Italy-Serie_B,Pescara,Cittadella,1,2
Italy-Serie_B,Empoli,Foggia,3,1
Italy-Serie_B,Novara,Frosinone,2,1
Italy-Serie_B,Entella,Brescia,3,0
Netherlands-Eerste_Divisie,RKC Waalwijk,FC Den Bosch,1,1
Spain-Segunda_Division,Albacete,Lorca FC,2,1
Spain-Segunda_Division,Barcelona B,Real Oviedo,1,1
Spain-Segunda_Division,Rayo Vallecano,Valladolid,4,1
Spain-Segunda_Division,Granada,Lugo,2,0
Spain-Segunda_Division,Zaragoza,Numancia,3,0
Spain-Segunda_Division,Cordoba,Alcorcon,3,0
USA-Major_League_Soccer,Colorado Rapids,FC Dallas,1,1
USA-Major_League_Soccer,Minnesota United,Sporting Kansas City,1,1
USA-USL,LA Galaxy II,Portland Timbers II,3,2
USA-USL,Colorado Springs Switchbacks FC,Sacramento Republic FC,1,0
USA-USL,Louisville City FC,Charlotte Independence,2,1
USA-USL,Orange County SC,Reno 1868 FC,1,4
USA-USL,Real Monarchs SLC,Vancouver Whitecaps II,1,1
USA-USL,Pittsburgh Riverhounds,Rochester Rhinos,0,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Serbia,Georgia,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Wales,Ireland,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__D,Moldova,Austria,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Albania,Italy,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Macedonia,Liechtenstein,4,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__G,Israel,Spain,0,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Finland,Turkey,2,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Ukraine,Croatia,0,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__I,Iceland,Kosovo,2,0
International-EURO_U21_Qualification_Grp__1,Croatia U21,Czech Republic U21,5,1
International-EURO_U21_Qualification_Grp__5,Ireland U21,Israel U21,4,0
International-EURO_U21_Qualification_Grp__9,Luxembourg U21,France U21,2,3
International-EURO_U21_Qualification_Grp__9,Montenegro U21,Slovenia U21,1,3
International-Friendlies,Equatorial Guinea,Mauritius,3,1
USA-USL,OKC Energy FC,Swope Park Rangers,4,1
International-World_Cup_U17_Grp__A,Ghana U17,USA U17,0,1
International-World_Cup_U17_Grp__A,India U17,Colombia U17,1,2
International-World_Cup_U17_Grp__B,Paraguay U17,New Zealand U17,4,2
International-World_Cup_U17_Grp__B,Turkey U17,Mali U17,0,3
International-Club_Friendlies,CSKA Moscow,FC Ufa,1,0
International-Club_Friendlies,PSV Eindhoven,Pachuca,0,0
International-EURO_U19_Qualification_Grp__6,Israel U19,Austria U19,0,2
International-EURO_U19_Qualification_Grp__6,Kosovo U19,Lithuania U19,3,0
Italy-Serie_C_Grp__B,Triestina,Fermana,3,0
Italy-Serie_C_Grp__B,Reggiana,Vicenza,1,0
Spain-Segunda_B_Grp__IV,Cordoba B,Real Murcia,4,3
Argentina-Primera_B_Nacional,Deportivo Moron,Santamarina,1,0
Argentina-Federal_A_Zona_2,Desamparados,Gimnasia Mendoza,0,0
Argentina-Federal_A_Zona_4,Guarani Antonio Franco,Juventud Antoniana,2,3
Argentina-Primera_B_Metropolitana,Sacachispas FC,Villa San Carlos,1,0
Argentina-Primera_C,Defensores de Cambaceres,Berazategui,1,1
Argentina-Primera_C,CA Defensores Unidos,Club Lujan,1,4
Argentina-Primera_C,Argentino de Quilmes,Canuelas,0,0
Argentina-Primera_C,CA Ferrocarril Midland,El Porvenir,2,1
Argentina-Cup,Belgrano,Atlanta,1,2
Chile-Cup,Universidad de Chile,San Luis,2,2
Colombia-Primera_B_Clausura,Real Santander,Deportes Quindio,2,3
Colombia-Cup,Patriotas,Atletico Junior,1,1
Costa_Rica-Primera_Division_Apertura,Universidad de Costa Rica,Deportiva Carmelita,1,0
Czech_Republic-FNL,Frydek-Mistek,Olympia Prague,1,2
International-World_Cup_Qualification_AFC_4th_Round,Australia,Syria,2,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Netherlands,Sweden,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,France,Belarus,2,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__A,Luxembourg,Bulgaria,1,1
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Portugal,Switzerland,2,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Hungary,Faroe Islands,1,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__B,Latvia,Andorra,4,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Estonia,Bosnia and Herzegovina,1,2
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Greece,Gibraltar,4,0
International-World_Cup_Qualification_UEFA_1st_Round_Grp__H,Belgium,Cyprus,4,0
International-Asian_Cup_Qualification_Round_3_Grp__A,Myanmar,Kyrgyzstan,2,2
International-Asian_Cup_Qualification_Round_3_Grp__B,Hong Kong,Malaysia,2,0
International-Asian_Cup_Qualification_Round_3_Grp__B,Lebanon,North Korea,5,0
International-Asian_Cup_Qualification_Round_3_Grp__C,Vietnam,Cambodia,5,0
International-Asian_Cup_Qualification_Round_3_Grp__C,Afghanistan,Jordan,3,3
International-Asian_Cup_Qualification_Round_3_Grp__D,Palestine,Bhutan,10,0
International-Asian_Cup_Qualification_Round_3_Grp__D,Maldives,Oman,1,3
International-Asian_Cup_Qualification_Round_3_Grp__E,Turkmenistan,Singapore,2,1
International-Asian_Cup_Qualification_Round_3_Grp__E,Chinese Taipei,Bahrain,2,1
International-Asian_Cup_Qualification_Round_3_Grp__F,Tajikistan,Nepal,3,0
International-Asian_Cup_Qualification_Round_3_Grp__F,Yemen,Philippines,1,1
International-EURO_U21_Qualification_Grp__1,Belarus U21,Moldova U21,3,1
International-EURO_U21_Qualification_Grp__1,San Marino U21,Greece U21,0,5
International-EURO_U21_Qualification_Grp__2,N.Ireland U21,Estonia U21,4,2
International-EURO_U21_Qualification_Grp__2,Albania U21,Iceland U21,0,0
International-EURO_U21_Qualification_Grp__2,Slovakia U21,Spain U21,1,4
International-EURO_U21_Qualification_Grp__3,Finland U21,Denmark U21,0,5
International-EURO_U21_Qualification_Grp__3,Faroe Islands U21,Georgia U21,3,1
International-EURO_U21_Qualification_Grp__3,Lithuania U21,Poland U21,0,2
International-EURO_U21_Qualification_Grp__4,Latvia U21,Scotland U21,0,2
International-EURO_U21_Qualification_Grp__4,Andorra U21,England U21,0,1
International-EURO_U21_Qualification_Grp__4,Ukraine U21,Netherlands U21,1,1
International-EURO_U21_Qualification_Grp__5,Norway U21,Germany U21,3,1
International-EURO_U21_Qualification_Grp__6,Turkey U21,Hungary U21,0,0
International-EURO_U21_Qualification_Grp__6,Cyprus U21,Belgium U21,0,2
International-EURO_U21_Qualification_Grp__6,Sweden U21,Malta U21,3,0
International-EURO_U21_Qualification_Grp__7,Gibraltar U21,Macedonia U21,1,0
International-EURO_U21_Qualification_Grp__7,Armenia U21,Austria U21,0,5
International-EURO_U21_Qualification_Grp__7,Serbia U21,Russia U21,3,2
International-EURO_U21_Qualification_Grp__8,Bosnia and Herzegovina U21,Portugal U21,3,1
International-World_Cup_Qualification_CONCACAF_Final_Stage,Panama,Costa Rica,2,1
International-World_Cup_Qualification_CONCACAF_Final_Stage,Honduras,Mexico,3,2
International-World_Cup_Qualification_CONCACAF_Final_Stage,Trinidad and Tobago,USA,2,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Brazil,Chile,3,0
International-World_Cup_Qualification_CONMEBOL_1st_round,Uruguay,Bolivia,4,2
International-World_Cup_Qualification_CONMEBOL_1st_round,Ecuador,Argentina,1,3
International-World_Cup_Qualification_CONMEBOL_1st_round,Paraguay,Venezuela,0,1
International-World_Cup_Qualification_CONMEBOL_1st_round,Peru,Colombia,1,1
International-Asian_Cup_Qualification_Round_3_Grp__A,India,Macau,4,1
Netherlands-KNVB_Cup,Lisse,Hoek,7,8
Spain-Segunda_Division,Real Oviedo,Tenerife,1,1
Spain-Segunda_Division,Sevilla Atletico,Cadiz,0,0
Spain-Segunda_Division,Gimnastic,Granada,2,0
Spain-Segunda_Division,Lorca FC,Zaragoza,0,2
Spain-Segunda_Division,Numancia,Barcelona B,1,0
USA-USL,Rochester Rhinos,Bethlehem Steel FC,1,0
International-World_Cup_U17_Grp__E,France U17,Japan U17,2,1
International-World_Cup_U17_Grp__E,Honduras U17,New Caledonia U17,5,0
International-World_Cup_U17_Grp__F,England U17,Mexico U17,3,2
International-World_Cup_U17_Grp__F,Iraq U17,Chile U17,3,0
International-Club_Friendlies,Barakaldo,Athletic Bilbao,2,2
Denmark-DBU_Pokalen,HIK,Silkeborg,
Egypt-Premier_League,Wadi Degla FC,Al Nasr,1,1
Egypt-Premier_League,El Dakhleya,El Raja Marsa Matruh,2,0
Egypt-Premier_League,Smouha SC,Petrojet,0,0
Kosovo-Superliga,Trepca 89,Besa Peje,3,0
Kosovo-Superliga,Drenica,KF Vllaznia Pozheran,1,0
Kosovo-Superliga,FC Prishtina,KF Vellaznimi,1,0
Argentina-Federal_A_Zona_1,Independiente de Neuquen,Club Cipolletti,0,1
Armenia-Cup,Avan Academy,Gandzasar,0,4
Australia-FFA_Cup,South Melbourne,Sydney FC,1,5
Austria-Regionalliga_Middle,ATSV Stadl Paura,SPG Pasching/LASK Juniors,2,0
Colombia-Primera_B_Clausura,Barranquilla FC,Deportes Quindio,3,0
Costa_Rica-Primera_Division_Apertura,Grecia,Guadalupe FC,1,1
Costa_Rica-Primera_Division_Apertura,Limon,C.S. Cartagines,3,1
Croatia-2__Division,NK Kustosija,Solin,1,1
Croatia-2__Division,NK Sesvete,HNK Gorica,0,0
Croatia-2__Division,NK Dugopolje,Novigrad,2,0
Croatia-2__Division,Sibenik,NK Hrvatski Dragovoljac,3,1
Croatia-2__Division,Dinamo Zagreb B,Lucko,3,0
Brazil-Serie_A,Atletico PR,Atletico GO,2,2
Brazil-Serie_A,Ponte Preta,Santos FC,1,1
Brazil-Serie_A,Atletico MG,Sao Paulo,1,0
Brazil-Serie_A,Flamengo,Fluminense,1,1
Brazil-Serie_A,Gremio,Cruzeiro,0,1
Brazil-Serie_A,Botafogo RJ,Chapecoense AF,2,1
Brazil-Serie_A,Vitoria,Sport Recife,1,2
Brazil-Serie_A,Corinthians,Coritiba,3,1
Brazil-Serie_A,Avai FC,Vasco da Gama,1,2
Bulgaria-First_Professional_League,Botev Plovdiv,Septemvri Sofia,5,0
Finland-Veikkausliiga,JJK,Ilves,0,0
Finland-Veikkausliiga,FC Lahti,IFK Mariehamn,0,1
Finland-Veikkausliiga,KuPS,RoPS,1,1
Finland-Veikkausliiga,SJK,HJK,0,2
Finland-Veikkausliiga,HIFK,PS Kemi,4,0
Finland-Veikkausliiga,VPS,FC Inter,2,2
Mexico-Liga_MX_Apertura,Toluca,Lobos de la BUAP,3,1
Norway-Eliteserien,Vaalerenga,FK Haugesund,3,0
Spain-Segunda_Division,Osasuna,Albacete,1,0
Spain-Segunda_Division,Lugo,Cordoba,2,0
Spain-Segunda_Division,Valladolid,Alcorcon,4,0
Spain-Segunda_Division,Rayo Vallecano,Almeria,1,0
USA-Major_League_Soccer,Houston Dynamo,Sporting Kansas City,2,1
USA-USL,San Antonio FC,Portland Timbers II,2,1
USA-USL,Swope Park Rangers,Seattle Sounders FC II,2,1
International-World_Cup_U17_Grp__A,USA U17,Colombia U17,1,3
International-World_Cup_U17_Grp__A,Ghana U17,India U17,4,0
International-World_Cup_U17_Grp__B,Mali U17,New Zealand U17,3,1
International-World_Cup_U17_Grp__B,Turkey U17,Paraguay U17,1,3
Egypt-Premier_League,Alassiouty,Al Mokawloon Al Arab,1,1
Egypt-Premier_League,Al Ahly,Al-Ittihad Al-Sakandary,2,0
Egypt-Premier_League,Al Masry,Misr El-Maqasa,3,2
Portugal-Cup,ARC Oleiros,Sporting CP,2,4
Wales-Premier_League,Newtown,Bala Town,1,3
Albania-Kategoria_Superiore,Luftetari,KF Kamza,1,2
Albania-Kategoria_Superiore,Skenderbeu,Laci,2,1
Albania-Kategoria_Superiore,Vllaznia,Flamurtari,1,1
Albania-Kategoria_Superiore,Teuta Durres,Partizani,1,2
Albania-Kategoria_Superiore,Lushnja,Kukesi,0,2
Algeria-Ligue_1,NA Hussein Dey,Paradou AC,1,1
Brazil-Serie_A,Palmeiras,Bahia,2,2
France-Ligue_1,Lyon,Monaco,3,2
Germany-1__Bundesliga,VfB Stuttgart,FC Cologne,2,1
Russia-Premier_League,FK Akhmat,Spartak Moscow,1,2
Spain-Primera_Division,Espanyol,Levante,0,0
Australia-A_League,Brisbane Roar FC,Adelaide United,1,2
Belgium-First_Division_A,KV Mechelen,Anderlecht,3,4
Bulgaria-First_Professional_League,Beroe,Lokomotiv Plovdiv,1,2
Croatia-1__Division,Rudes,NK Lokomotiva,0,1
Czech_Republic-1__Division,Bohemians 1905,Banik Ostrava,2,1
Denmark-Superligaen,SoenderjyskE,FC Midtjylland,0,1
England-Championship,Bristol City,Burton Albion,0,0
England-Championship,Birmingham City,Cardiff City,1,0
France-Coupe_de_France,US Matoury,AS ET Matoury,5,6
Germany-2__Bundesliga,Duisburg,Eintracht Braunschweig,0,0
Germany-2__Bundesliga,St. Pauli,Kaiserslautern,1,1
Ireland-Premier_Division,Shamrock Rovers,Sligo Rovers,1,1
Ireland-Premier_Division,Dundalk,Bray Wanderers,1,0
Ireland-Premier_Division,Galway United FC,St. Patrick's Athletic,1,1
Ireland-Premier_Division,Bohemian FC,Cork City,0,0
Ireland-Premier_Division,Derry City,Finn Harps,3,0
Italy-Serie_B,Foggia,Perugia,2,1
Netherlands-Eerste_Divisie,Telstar,FC Dordrecht,3,0
Netherlands-Eerste_Divisie,Cambuur,FC Oss,1,3
Netherlands-Eerste_Divisie,FC Den Bosch,Jong FC Utrecht,1,0
Netherlands-Eerste_Divisie,FC Emmen,Jong PSV,3,1
Netherlands-Eerste_Divisie,MVV Maastricht,Fortuna Sittard,1,2
Netherlands-Eerste_Divisie,NEC Nijmegen,RKC Waalwijk,2,0
Netherlands-Eerste_Divisie,FC Eindhoven,FC Volendam,1,0
N__Ireland-Premiership,Warrenpoint Town,Ballinamallard United,2,1
Poland-Ekstraklasa,Jagiellonia Bialystok,Lech Poznan,1,1
Poland-Ekstraklasa,Korona Kielce,Wisla Plock,2,0
Romania-Liga_I,FC Voluntari,FC FCSB,0,0
Scotland-Premiership,St.Johnstone,Rangers,0,3
Scotland-FA_Cup,Edinburgh City,Stenhousemuir,0,1
Slovenia-Prva_Liga,Rudar Velenje,Maribor,1,2
Spain-Segunda_Division,Sporting Gijon,Huesca,1,1
Turkey-Super_Lig,Genclerbirligi,Besiktas,2,1
Ukraine-Premier_League,Shakhtar Donetsk,Vorskla,3,2
USA-USL,Orlando City B,Tampa Bay Rowdies,0,2
England-Premier_League,Manchester City,Stoke City,7,2
England-Premier_League,Burnley,West Ham United,1,1
England-Premier_League,Swansea City,Huddersfield Town,2,0
England-Premier_League,Liverpool,Manchester United,0,0
England-Premier_League,Crystal Palace,Chelsea,2,1
England-Premier_League,Tottenham Hotspur,AFC Bournemouth,1,0
England-Premier_League,Watford,Arsenal,2,1
England-FA_Cup_Qualification,Brackley Town,Billericay,3,3
England-FA_Cup_Qualification,Maidenhead United,Havant and Waterlooville,2,1
England-FA_Cup_Qualification,AFC Fylde,Wrexham,1,0
England-FA_Cup_Qualification,Margate,Leatherhead,1,2
England-FA_Cup_Qualification,Dagenham &amp; Redbridge,Leyton Orient,0,0
England-FA_Cup_Qualification,Harrogate,Gainsborough,1,2
England-FA_Cup_Qualification,South Shields,Hartlepool United,1,2
England-FA_Cup_Qualification,Hampton &amp; Richmond,Truro City,0,2
England-FA_Cup_Qualification,Bath City,Chelmsford,0,0
England-FA_Cup_Qualification,Buxton,Gateshead FC,1,2
England-FA_Cup_Qualification,Burgess Hill Town,Dartford,0,1
England-FA_Cup_Qualification,East Thurrock United,Ebbsfleet United,0,0
England-FA_Cup_Qualification,Haringey Borough,Heybridge Swifts,2,4
England-FA_Cup_Qualification,Kidderminster Harriers,Chester FC,2,0
England-FA_Cup_Qualification,Paulton Rovers,Sutton United,2,3
England-FA_Cup_Qualification,Eastleigh,Hereford,1,2
England-FA_Cup_Qualification,Scarborough Athletic,Hyde United,0,2
England-FA_Cup_Qualification,Chorley,Boston United,0,0
England-FA_Cup_Qualification,Dover,Bromley,0,0
England-FA_Cup_Qualification,Oxford City,Bognor Regis Town,1,0
England-FA_Cup_Qualification,Guiseley,Shildon AFC,6,0
England-FA_Cup_Qualification,Maidstone,Enfield Town,2,2
England-FA_Cup_Qualification,Solihull Moors,Ossett Town,1,1
England-FA_Cup_Qualification,FC Halifax Town,Tranmere Rovers,1,3
England-FA_Cup_Qualification,Woking,Concord Rangers,1,1
England-FA_Cup_Qualification,Stourbridge,Macclesfield Town,0,5
England-FA_Cup_Qualification,Telford,FC United of Manchester,3,1
England-FA_Cup_Qualification,Aldershot Town,Torquay United,1,0
England-FA_Cup_Qualification,Nantwich Town,Kettering Town FC,1,1
England-FA_Cup_Qualification,Slough Town,Folkestone Invicta,1,0
England-FA_Cup_Qualification,St.Albans,Boreham Wood,1,3
France-Ligue_1,Dijon,Paris Saint Germain,1,2
France-Ligue_1,Lille,Troyes,2,2
Brazil-Serie_A,Vasco da Gama,Botafogo RJ,1,0
Brazil-Serie_A,Sport Recife,Atletico MG,1,1
Brazil-Serie_A,Sao Paulo,Atletico PR,2,1
Brazil-Serie_A,Coritiba,Gremio,0,1
Brazil-Serie_A,Atletico GO,Palmeiras,1,3
Brazil-Serie_A,Bahia,Corinthians,2,0
Brazil-Serie_A,Fluminense,Avai FC,1,0
Brazil-Serie_A,Chapecoense AF,Flamengo,0,1
England-Premier_League,Southampton,Newcastle United,2,2
England-Premier_League,Brighton &amp; Hove Albion,Everton,1,1
England-FA_Cup_Qualification,Shaw Lane AFC,Barrow,2,1
France-Ligue_1,Strasbourg,Marseille,3,3
France-Ligue_1,Montpellier,Nice,2,0
France-Ligue_1,Bordeaux,Nantes,1,1
Germany-1__Bundesliga,Bayer Leverkusen,Wolfsburg,2,2
Germany-1__Bundesliga,Werder Bremen,Borussia Moenchengladbach,0,2
Italy-Serie_A,Sampdoria,Atalanta,3,1
Italy-Serie_A,Fiorentina,Udinese,2,1
Italy-Serie_A,Cagliari,Genoa,2,3
Italy-Serie_A,Sassuolo,ChievoVerona,0,0
Italy-Serie_A,Inter,AC Milan,3,2
Italy-Serie_A,Crotone,Torino,2,2
Italy-Serie_A,Bologna,SPAL 2013,2,1
Netherlands-Eredivisie,Heracles,Vitesse,1,1
Netherlands-Eredivisie,VVV-Venlo,PSV Eindhoven,2,5
Netherlands-Eredivisie,ADO Den Haag,Excelsior,1,2
Netherlands-Eredivisie,FC Groningen,AZ Alkmaar,1,1
Netherlands-Eredivisie,Willem II,FC Twente,3,1
Russia-Premier_League,FC Ufa,Lokomotiv Moscow,1,0
Russia-Premier_League,FC Rostov,Rubin Kazan,0,1
Russia-Premier_League,Zenit St. Petersburg,Arsenal Tula,0,1
Spain-Primera_Division,Girona,Villarreal,1,2
Spain-Primera_Division,Real Betis,Valencia,3,6
Spain-Primera_Division,Eibar,Deportivo La Coruna,0,0
Spain-Primera_Division,Malaga,Leganes,0,2
Argentina-Superliga,Racing Club,Tigre,1,0
Argentina-Superliga,Belgrano,Talleres,0,0
Argentina-Superliga,Chacarita Juniors,Independiente,1,2
Argentina-Superliga,Godoy Cruz,Gimnasia LP,3,0
Argentina-Superliga,River Plate,Atletico Tucuman,2,2
England-Premier_League,Leicester City,West Bromwich Albion,1,1
England-FA_Cup_Qualification,Chelmsford,Bath City,1,0
Italy-Serie_A,Hellas Verona,Benevento,1,0
Russia-Premier_League,Amkar,Tosno,0,0
Spain-Primera_Division,Las Palmas,Celta Vigo,2,5
Argentina-Superliga,Patronato de Parana,Boca Juniors,0,2
Bulgaria-First_Professional_League,Botev Plovdiv,Vereya,1,0
Bulgaria-First_Professional_League,Septemvri Sofia,Vitosha Bistritsa,1,0
Denmark-Superligaen,AGF,Lyngby,0,2
Finland-Veikkausliiga,JJK,IFK Mariehamn,1,0
Finland-Veikkausliiga,FC Inter,HIFK,4,1
Finland-Veikkausliiga,HJK,FC Lahti,3,0
Germany-2__Bundesliga,Darmstadt,Nuernberg,3,4
Greece-Super_League,Panathinaikos,AE Larissa,2,1
Israel-Ligat_HaAl,Beitar Jerusalem,Maccabi Netanya,4,1
Italy-Serie_B,Entella,Empoli,2,3
Mexico-Liga_MX_Apertura,Santos,Atlas,0,1
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Helmond Sport,1,3
Netherlands-Eerste_Divisie,Jong Ajax,Almere City FC,3,0
Norway-Eliteserien,Sarpsborg 08,Stabaek,2,2
Poland-Ekstraklasa,Cracovia,Pogon Szczecin,3,0
Romania-Liga_I,Dinamo Bucuresti,Juventus Bucuresti,3,0
Romania-Liga_I,ACS Poli Timisoara,Concordia Chiajna,0,3
Spain-Segunda_Division,Alcorcon,Lugo,0,1
Sweden-Allsvenskan,IFK Norrkoeping,Malmoe FF,1,3
Sweden-Allsvenskan,Kalmar FF,Hammarby,2,0
Turkey-Super_Lig,Bursaspor,Osmanlispor FK,3,1
USA-Major_League_Soccer,Colorado Rapids,Real Salt Lake,1,0
USA-Major_League_Soccer,Sporting Kansas City,Houston Dynamo,0,0
USA-Major_League_Soccer,Portland Timbers,DC United,4,0
USA-Major_League_Soccer,Seattle Sounders FC,FC Dallas,4,0
USA-Major_League_Soccer,Vancouver Whitecaps,San Jose Earthquakes,1,1
USA-Major_League_Soccer,LA Galaxy,Minnesota United,3,0
USA-USL,OKC Energy FC,Seattle Sounders FC II,3,1
International-World_Cup_U17_Final_Stage,Paraguay U17,USA U17,0,5
International-World_Cup_U17_Final_Stage,Colombia U17,Germany U17,0,4
Belgium-First_Division_B_1st_Stage,Union St.-Gilloise,Lierse,3,2
Egypt-Premier_League,Al Ahly,El Raja Marsa Matruh,4,1
International-EURO_U17_Qualification_Grp__11,Azerbaijan U17,Bulgaria U17,2,1
International-EURO_U17_Qualification_Grp__11,Ukraine U17,Ireland U17,1,3
International-Champions_League_Grp__E,Maribor,Liverpool,0,7
International-Champions_League_Grp__E,Spartak Moscow,Sevilla,5,1
International-Champions_League_Grp__F,Manchester City,SSC Napoli,2,1
International-Champions_League_Grp__F,Feyenoord,Shakhtar Donetsk,1,2
International-Champions_League_Grp__G,Monaco,Besiktas,1,2
International-Champions_League_Grp__G,RasenBallsport Leipzig,FC Porto,3,2
International-Champions_League_Grp__H,APOEL Nicosia,Borussia Dortmund,1,1
International-Champions_League_Grp__H,Real Madrid,Tottenham Hotspur,1,1
Brazil-Serie_A,Santos FC,Vitoria,2,2
England-FA_Cup_Qualification,Concord Rangers,Woking,1,2
England-FA_Cup_Qualification,Ossett Town,Solihull Moors,1,2
England-FA_Cup_Qualification,Billericay,Brackley Town,2,1
England-FA_Cup_Qualification,Ebbsfleet United,East Thurrock United,3,0
England-FA_Cup_Qualification,Boston United,Chorley,3,4
England-FA_Cup_Qualification,Leyton Orient,Dagenham &amp; Redbridge,1,0
England-FA_Cup_Qualification,Bromley,Dover,3,0
England-FA_Cup_Qualification,Enfield Town,Maidstone,1,3
England-FA_Cup_Qualification,Kettering Town FC,Nantwich Town,0,1
International-AFC_Champions_League_Final_Stage,Persepolis,Al Hilal,2,2
Argentina-Superliga,Arsenal Sarandi,San Martin San Juan,0,1
Argentina-Superliga,Olimpo,Huracan,0,2
Hungary-NB_I,Vasas Budapest,Haladas,1,0
Ireland-Premier_Division,Cork City,Derry City,0,0
International-World_Cup_U17_Final_Stage,Iran U17,Mexico U17,2,1
International-World_Cup_U17_Final_Stage,Mali U17,Iraq U17,5,1
International-World_Cup_U17_Final_Stage,France U17,Spain U17,1,2
International-World_Cup_U17_Final_Stage,England U17,Japan U17,5,3
Brazil-Serie_B,Guarani,ABC,1,1
Brazil-Serie_B,Londrina EC,Figueirense,1,0
Brazil-Serie_B,Boa Esporte Clube,Internacional,0,0
England-League_1,Blackpool,Bury,2,1
England-League_1,Shrewsbury Town,Bristol Rovers,4,0
England-League_1,Gillingham,Wigan Athletic,1,1
England-League_1,AFC Wimbledon,Rotherham United,3,1
England-League_1,Rochdale,Northampton Town,2,2
England-League_1,Bradford City,Oldham Athletic,1,1
England-League_1,Southend United,Peterborough United,1,1
England-League_1,Milton Keynes Dons,Walsall,1,1
England-League_1,Blackburn Rovers,Plymouth Argyle,1,1
England-League_1,Scunthorpe United,Fleetwood Town,1,1
International-Champions_League_Grp__A,CSKA Moscow,Basel,0,2
International-Champions_League_Grp__A,Benfica,Manchester United,0,1
International-Champions_League_Grp__B,Anderlecht,Paris Saint Germain,0,4
International-Champions_League_Grp__B,Bayern Munich,Celtic,3,0
International-Champions_League_Grp__C,Chelsea,Roma,3,3
International-Champions_League_Grp__C,Qarabag FK,Atletico Madrid,0,0
International-Champions_League_Grp__D,Juventus,Sporting CP,2,1
International-Champions_League_Grp__D,Barcelona,Olympiacos,3,1
Brazil-Serie_A,Coritiba,Cruzeiro,1,0
Brazil-Serie_A,Atletico GO,Vasco da Gama,0,1
International-AFC_Champions_League_Final_Stage,Urawa Red Diamonds,Shanghai SIPG FC,1,0
Mexico-Liga_MX_Apertura,Pumas,Leon,2,0
Mexico-Liga_MX_Apertura,Queretaro FC,Cruz Azul,1,2
Mexico-Liga_MX_Apertura,Atlas,Monarcas Morelia,0,1
Mexico-Liga_MX_Apertura,Tigres,Veracruz,1,0
Mexico-Liga_MX_Apertura,Lobos de la BUAP,Tijuana,1,2
International-World_Cup_U17_Final_Stage,Brazil U17,Honduras U17,3,0
International-World_Cup_U17_Final_Stage,Ghana U17,Niger U17,2,0
International-AFC_Cup_Final_Stage,Bengaluru FC,FC Istiklol,2,2
Brazil-Serie_B,Luverdense,Paysandu,1,1
Brazil-Serie_B,Criciuma,Vila Nova,0,1
Brazil-Serie_B,CRB,Nautico,2,2
Brazil-Serie_B,Ceara,Parana Clube,1,0
Brazil-Serie_B,Brasil de Pelotas,America MG,0,0
Brazil-Serie_B,Goias,Juventude,1,0
Brazil-Serie_B,Santa Cruz,Oeste FC,2,2
International-Club_Friendlies,Grasshopper,Aarau,3,3
International-EURO_U17_Qualification_Grp__5,Norway U17,Greece U17,0,1
International-EURO_U17_Qualification_Grp__5,Serbia U17,Gibraltar U17,7,0
Gibraltar-Premier_Division,Mons Calpe SC,Lynx,3,0
Philippines-Philippines_Football_League,Ceres-Negros FC,JP Voltes FC,2,2
Philippines-Philippines_Football_League,Ilocos United,Davao Aguilas,2,4
Slovakia-FA_Cup,Zilina,Zeleziarne Podbrezova,3,0
Slovakia-FA_Cup,Slovan Bratislava,Nitra,3,1
Slovakia-FA_Cup,Liptovsky Mikulas,Lokomotiva Zvolen,2,0
Slovakia-FA_Cup,MFK Spartak Medzev,DAC 1904 Dunajska Streda,1,5
Slovakia-FA_Cup,Spartak Trnava,FK Spisska Nova Ves,3,0
Slovakia-FA_Cup,FK Iskra Borcice,Zemplin Michalovce,2,0
Slovakia-FA_Cup,Skalica,Ruzomberok,0,1
Argentina-Primera_B_Metropolitana,Club Atletico Platense,CD UAI Urquiza,0,1
Brazil-Serie_A,Corinthians,Gremio,0,0
Brazil-Serie_A,Avai FC,Botafogo RJ,1,1
Brazil-Serie_A,Atletico MG,Chapecoense AF,2,3
Brazil-Serie_A,Fluminense,Sao Paulo,3,1
International-Europa_League_Grp__A,Villarreal,Slavia Prague,2,2
International-Europa_League_Grp__A,FC Astana,Maccabi Tel Aviv,4,0
International-Europa_League_Grp__B,Skenderbeu,Partizan Beograd,0,0
International-Europa_League_Grp__B,Dynamo Kyiv,Young Boys,2,2
International-Europa_League_Grp__C,Braga,Ludogorets Razgrad,0,2
International-Europa_League_Grp__C,Hoffenheim,Istanbul Basaksehir,3,1
International-Europa_League_Grp__D,Austria Wien,Rijeka,1,3
International-Europa_League_Grp__D,AC Milan,AEK Athens,0,0
International-Europa_League_Grp__E,Atalanta,Apollon Limassol,3,1
International-Europa_League_Grp__E,Everton,Lyon,1,2
International-Europa_League_Grp__F,FC Sheriff,Lokomotiv Moscow,1,1
International-Europa_League_Grp__F,Zlin,FC Koebenhavn,1,1
International-Europa_League_Grp__G,Lugano,Viktoria Plzen,3,2
International-Europa_League_Grp__G,Hapoel Beer Sheva,FC FCSB,1,2
International-Europa_League_Grp__H,BATE Borisov,FC Cologne,1,0
International-Europa_League_Grp__H,FK Crvena Zvezda,Arsenal,0,1
International-Europa_League_Grp__I,Konyaspor,Salzburg,0,2
International-Europa_League_Grp__I,Marseille,Vitoria de Guimaraes,2,1
International-Europa_League_Grp__J,Zorya,Hertha Berlin,2,1
International-Europa_League_Grp__J,Oestersunds FK,Athletic Bilbao,2,2
International-Europa_League_Grp__K,Nice,Lazio,1,3
International-Europa_League_Grp__K,Zulte-Waregem,Vitesse,1,1
International-Europa_League_Grp__L,Zenit St. Petersburg,Rosenborg,3,1
International-Europa_League_Grp__L,FK Vardar Skopje,Real Sociedad,0,6
Czech_Republic-1__Division,Dukla Praha,Slovacko,1,1
France-Coupe_de_France,Sporting BM,Etoile de Morne-a-l-Eau,0,4
Mexico-Liga_MX_Apertura,Santos,Necaxa,3,2
Mexico-Liga_MX_Apertura,CF America,CD Guadalajara,2,1
Mexico-Liga_MX_Apertura,Pachuca,Toluca,2,2
Mexico-Liga_MX_Apertura,Puebla,Monterrey,2,0
Egypt-Premier_League,El Geish,Tanta,0,0
Egypt-Premier_League,Misr El-Maqasa,ENPPI,1,2
Egypt-Premier_League,Al-Ittihad Al-Sakandary,El Entag El Harby,1,1
Egypt-Premier_League,Al Nasr,Alassiouty,2,2
International-EURO_U17_Qualification_Grp__2,Spain U17,Liechtenstein U17,3,0
International-EURO_U17_Qualification_Grp__2,Albania U17,Croatia U17,0,1
Brazil-Serie_A,Vitoria,Atletico PR,2,3
Brazil-Serie_A,Flamengo,Bahia,4,1
Brazil-Serie_A,Sport Recife,Santos FC,1,1
Brazil-Serie_A,Palmeiras,Ponte Preta,2,0
England-Premier_League,West Ham United,Brighton &amp; Hove Albion,0,3
France-Ligue_1,Saint-Etienne,Montpellier,0,1
Germany-1__Bundesliga,Schalke 04,Mainz 05,2,0
Netherlands-Eredivisie,FC Groningen,Willem II,0,1
Portugal-Primeira_Liga,Estoril,Boavista,0,3
Australia-A_League,Adelaide United,Melbourne Victory,2,2
Belgium-First_Division_A,Royal Excel Mouscron,Standard Liege,1,3
Bulgaria-First_Professional_League,Dunav Ruse,Botev Plovdiv,0,0
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Slavia Sofia,0,0
Croatia-1__Division,Inter Zapresic,Rudes,3,1
Czech_Republic-1__Division,Banik Ostrava,Sigma Olomouc,1,1
Czech_Republic-1__Division,Vysocina Jihlava,Bohemians 1905,2,4
Denmark-Superligaen,FC Midtjylland,AC Horsens,4,2
Finland-Veikkausliiga,KuPS,JJK,2,1
Finland-Veikkausliiga,HIFK,SJK,2,2
Finland-Veikkausliiga,RoPS,IFK Mariehamn,0,3
Finland-Veikkausliiga,Ilves,PS Kemi,1,0
Finland-Veikkausliiga,VPS,FC Lahti,2,1
Finland-Veikkausliiga,FC Inter,HJK,1,3
Germany-2__Bundesliga,Fortuna Duesseldorf,Darmstadt,1,0
Germany-2__Bundesliga,Ingolstadt,FC Heidenheim,3,0
Ireland-Premier_Division,Dundalk,Bohemian FC,0,1
Ireland-Premier_Division,St. Patrick's Athletic,Cork City,4,2
Ireland-Premier_Division,Bray Wanderers,Shamrock Rovers,1,0
Ireland-Premier_Division,Limerick,Galway United FC,2,2
Italy-Serie_B,Bari,Cittadella,4,2
Italy-Serie_B,Cremonese,Brescia,2,0
Netherlands-Eerste_Divisie,Jong FC Utrecht,MVV Maastricht,2,1
Netherlands-Eerste_Divisie,Helmond Sport,Telstar,1,2
Netherlands-Eerste_Divisie,Jong PSV,RKC Waalwijk,3,2
Netherlands-Eerste_Divisie,FC Oss,FC Den Bosch,1,1
Netherlands-Eerste_Divisie,FC Volendam,NEC Nijmegen,0,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,FC Emmen,2,1
Netherlands-Eerste_Divisie,Go Ahead Eagles,Jong Ajax,4,1
Netherlands-Eerste_Divisie,Almere City FC,Cambuur,1,1
Netherlands-Eerste_Divisie,FC Dordrecht,De Graafschap,1,1
Brazil-Serie_A,Vasco da Gama,Coritiba,1,1
England-Premier_League,Manchester City,Burnley,3,0
England-Premier_League,Swansea City,Leicester City,1,2
England-Premier_League,Southampton,West Bromwich Albion,1,0
England-Premier_League,Newcastle United,Crystal Palace,1,0
England-Premier_League,Huddersfield Town,Manchester United,2,1
England-Premier_League,Chelsea,Watford,4,2
England-Premier_League,Stoke City,AFC Bournemouth,1,2
France-Ligue_1,Monaco,Caen,2,0
France-Ligue_1,Angers,Toulouse,0,1
France-Ligue_1,Rennes,Lille,1,0
France-Ligue_1,Metz,Dijon,1,2
France-Ligue_1,Amiens,Bordeaux,1,0
France-Ligue_1,Nantes,Guingamp,2,1
Germany-1__Bundesliga,Hamburger SV,Bayern Munich,0,1
Germany-1__Bundesliga,Borussia Moenchengladbach,Bayer Leverkusen,1,5
Germany-1__Bundesliga,Eintracht Frankfurt,Borussia Dortmund,2,2
Germany-1__Bundesliga,RasenBallsport Leipzig,VfB Stuttgart,1,0
Germany-1__Bundesliga,Augsburg,Hannover 96,1,2
Italy-Serie_A,Sampdoria,Crotone,5,0
Italy-Serie_A,SSC Napoli,Inter,0,0
Netherlands-Eredivisie,NAC Breda,PEC Zwolle,0,2
Netherlands-Eredivisie,Excelsior,Sparta Rotterdam,1,1
Netherlands-Eredivisie,FC Twente,Roda JC Kerkrade,3,0
Netherlands-Eredivisie,VVV-Venlo,ADO Den Haag,0,2
Portugal-Primeira_Liga,FC Porto,Pacos de Ferreira,6,1
Portugal-Primeira_Liga,Feirense,Rio Ave,1,0
Portugal-Primeira_Liga,Vitoria de Setubal,Maritimo,3,1
Russia-Premier_League,Spartak Moscow,Amkar,0,0
Russia-Premier_League,Rubin Kazan,Dinamo Moscow,0,0
Russia-Premier_League,Tosno,FC Rostov,1,1
Russia-Premier_League,SKA-Khabarovsk,FC Ufa,2,2
Spain-Primera_Division,Barcelona,Malaga,2,0
Spain-Primera_Division,Valencia,Sevilla,4,0
Spain-Primera_Division,Levante,Getafe,1,1
Spain-Primera_Division,Real Betis,Alaves,2,0
Australia-A_League,Sydney FC,Western Sydney Wanderers FC,2,2
Australia-A_League,Melbourne City FC,Wellington Phoenix,1,0
Austria-Bundesliga,SKN St. Poelten,LASK,0,1
Austria-Bundesliga,Sturm Graz,Mattersburg,3,2
Brazil-Serie_A,Atletico PR,Sport Recife,2,1
Brazil-Serie_A,Sao Paulo,Flamengo,2,0
Brazil-Serie_A,Gremio,Palmeiras,1,3
Brazil-Serie_A,Ponte Preta,Avai FC,1,2
Brazil-Serie_A,Cruzeiro,Atletico MG,1,3
Brazil-Serie_A,Bahia,Vitoria,2,1
Brazil-Serie_A,Chapecoense AF,Fluminense,2,0
Brazil-Serie_A,Santos FC,Atletico GO,1,0
England-Premier_League,Tottenham Hotspur,Liverpool,4,1
England-Premier_League,Everton,Arsenal,2,5
France-Ligue_1,Nice,Strasbourg,1,2
France-Ligue_1,Marseille,Paris Saint Germain,2,2
France-Ligue_1,Troyes,Lyon,0,5
Germany-1__Bundesliga,Freiburg,Hertha Berlin,1,1
Germany-1__Bundesliga,Wolfsburg,Hoffenheim,1,1
Germany-1__Bundesliga,FC Cologne,Werder Bremen,0,0
Italy-Serie_A,Benevento,Fiorentina,0,3
Italy-Serie_A,Torino,Roma,0,1
Italy-Serie_A,Lazio,Cagliari,3,0
Italy-Serie_A,AC Milan,Genoa,0,0
Italy-Serie_A,Udinese,Juventus,2,6
Italy-Serie_A,Atalanta,Bologna,1,0
Italy-Serie_A,ChievoVerona,Hellas Verona,3,2
Italy-Serie_A,SPAL 2013,Sassuolo,0,1
Netherlands-Eredivisie,PSV Eindhoven,Heracles,3,0
Netherlands-Eredivisie,AZ Alkmaar,FC Utrecht,3,0
Netherlands-Eredivisie,SC Heerenveen,Vitesse,0,4
Netherlands-Eredivisie,Feyenoord,Ajax,1,4
Portugal-Primeira_Liga,Tondela,Belenenses,2,0
Portugal-Primeira_Liga,Sporting CP,Chaves,5,1
Portugal-Primeira_Liga,Aves,Benfica,1,3
Russia-Premier_League,Anzhi Makhachkala,Arsenal Tula,3,2
Russia-Premier_League,Ural,FK Akhmat,2,0
Russia-Premier_League,CSKA Moscow,Zenit St. Petersburg,0,0
Spain-Primera_Division,Celta Vigo,Atletico Madrid,0,1
Spain-Primera_Division,Villarreal,Las Palmas,4,0
Spain-Primera_Division,Real Madrid,Eibar,3,0
Spain-Primera_Division,Leganes,Athletic Bilbao,1,0
Australia-A_League,Brisbane Roar FC,Newcastle Jets,1,2
Australia-A_League,Perth Glory,Central Coast Mariners,2,1
Portugal-Primeira_Liga,Vitoria de Guimaraes,Portimonense,3,3
Portugal-Primeira_Liga,Moreirense,Braga,0,1
Russia-Premier_League,Lokomotiv Moscow,FC Krasnodar,2,0
Spain-Primera_Division,Real Sociedad,Espanyol,1,1
Spain-Primera_Division,Deportivo La Coruna,Girona,1,2
Bulgaria-First_Professional_League,Ludogorets Razgrad,Etar,4,0
Denmark-Superligaen,Randers FC,AaB,1,1
Germany-2__Bundesliga,Sandhausen,St. Pauli,1,1
Greece-Super_League,AEK Athens,Atromitos,0,1
Ireland-Premier_Division,Finn Harps,Drogheda United,2,3
Israel-Ligat_HaAl,Hapoel Beer Sheva,Maccabi Tel Aviv,2,1
Italy-Serie_B,Brescia,Bari,2,1
Mexico-Liga_MX_Apertura,Veracruz,CD Guadalajara,2,3
Netherlands-Eerste_Divisie,FC Oss,Jong AZ Alkmaar,2,1
N__Ireland-Premiership,Linfield,Crusaders,2,5
Norway-Eliteserien,Odds Ballklubb,Lillestroem,1,0
Poland-Ekstraklasa,Wisla Plock,Slask Wroclaw,4,1
Romania-Liga_I,Botosani,Dinamo Bucuresti,0,0
Spain-Segunda_Division,Leonesa,Albacete,0,0
Sweden-Allsvenskan,Joenkoepings Soedra,Kalmar FF,2,0
Sweden-Allsvenskan,Malmoe FF,AIK,0,0
Sweden-Allsvenskan,Hammarby,Sirius,3,3
Turkey-Super_Lig,Besiktas,Istanbul Basaksehir,1,1
Belgium-First_Division_B_1st_Stage,Union St.-Gilloise,Tubize,1,2
International-EURO_U17_Qualification_Grp__10,Lithuania U17,Romania U17,1,2
International-EURO_U17_Qualification_Grp__10,Austria U17,Luxembourg U17,2,1
International-EURO_U17_Qualification_Grp__12,San Marino U17,Cyprus U17,0,5
International-EURO_U17_Qualification_Grp__12,Sweden U17,Poland U17,1,1
France-Ligue_2,AC Ajaccio,GFC Ajaccio,2,0
Italy-Serie_C_Grp__A,Pontedera,Pistoiese,2,2
Italy-Serie_C_Grp__B,Vicenza,Triestina,1,3
Italy-Serie_C_Grp__C,Trapani,Catanzaro,3,3
Singapore-S_League,Home United FC,Tampines Rovers FC,0,2
Sweden-Superettan,IFK Vaernamo,Syrianska,6,1
Albania-Kategoria_Superiore,Teuta Durres,Skenderbeu,1,4
Argentina-Primera_B_Metropolitana,Comunicaciones,CA San Miguel,0,0
Argentina-Cup,Godoy Cruz,Rosario Central,2,3
Armenia-1__Division,Banants II,Pyunik II,3,1
Armenia-1__Division,Shirak II,Alashkert FC II,0,2
Armenia-1__Division,Ararat II,Avan Academy,0,1
Brazil-Serie_A,Botafogo RJ,Corinthians,2,1
Italy-Serie_A,Inter,Sampdoria,3,2
Belgium-First_Division_A,Oostende,Sporting Charleroi,3,0
Belgium-First_Division_A,KV Mechelen,Lokeren,0,2
Belgium-First_Division_A,Gent,Eupen,3,0
England-EFL_Cup,Leicester City,Leeds United,3,1
England-EFL_Cup,Swansea City,Manchester United,0,2
England-EFL_Cup,Manchester City,Wolverhampton Wanderers,4,1
England-EFL_Cup,AFC Bournemouth,Middlesbrough,3,1
England-EFL_Cup,Arsenal,Norwich City,2,1
England-EFL_Cup,Bristol City,Crystal Palace,4,1
Germany-DFB_Pokal,Mainz 05,Holstein Kiel,3,2
Germany-DFB_Pokal,Wehen,Schalke 04,1,3
Germany-DFB_Pokal,FC Schweinfurt,Eintracht Frankfurt,0,4
Germany-DFB_Pokal,Bayer Leverkusen,Union Berlin,4,1
Germany-DFB_Pokal,Greuther Fuerth,Ingolstadt,1,3
Germany-DFB_Pokal,Fortuna Duesseldorf,Borussia Moenchengladbach,0,1
Germany-DFB_Pokal,Magdeburg,Borussia Dortmund,0,5
Germany-DFB_Pokal,Paderborn,Bochum,2,0
Italy-Serie_B,Carpi,Palermo,1,3
Italy-Serie_B,Foggia,Parma Calcio 1913,0,3
Italy-Serie_B,Ascoli Picchio FC 1898,Spezia,3,1
Italy-Serie_B,Perugia,Cesena,0,3
Italy-Serie_B,Cittadella,Venezia,2,1
Italy-Serie_B,Frosinone,Ternana,4,2
Italy-Serie_B,Avellino,Pro Vercelli,1,0
Italy-Serie_B,Entella,Cremonese,1,1
Italy-Serie_B,Empoli,Pescara,3,1
Italy-Serie_B,Novara,Salernitana,2,3
Netherlands-KNVB_Cup,NEC Nijmegen,Achilles 29,3,0
Netherlands-KNVB_Cup,Katwijk,VVSB,1,2
Netherlands-KNVB_Cup,FC Den Bosch,Cambuur,0,2
Netherlands-KNVB_Cup,Fortuna Sittard,Go Ahead Eagles,3,0
Netherlands-KNVB_Cup,GVVV Veenendaal,Koninklijke HFC,1,0
Netherlands-KNVB_Cup,FC Twente,FC Eindhoven,3,0
Netherlands-KNVB_Cup,PEC Zwolle,Kozakken Boys,3,2
Netherlands-KNVB_Cup,RKC Waalwijk,De Treffers,7,0
Scotland-Premiership,Hibernian,Hearts,1,0
Scotland-Premiership,St.Johnstone,Ross County,0,0
Scotland-Premiership,Hamilton Academical,Partick Thistle,0,0
International-Copa_Libertadores_Final_Stage,River Plate,Lanus,1,0
Italy-Serie_A,Fiorentina,Torino,3,0
Italy-Serie_A,Roma,Crotone,1,0
Italy-Serie_A,Bologna,Lazio,1,2
Italy-Serie_A,Cagliari,Benevento,2,1
Italy-Serie_A,Atalanta,Hellas Verona,3,0
Italy-Serie_A,Genoa,SSC Napoli,2,3
Italy-Serie_A,Sassuolo,Udinese,0,1
Italy-Serie_A,ChievoVerona,AC Milan,1,4
Italy-Serie_A,Juventus,SPAL 2013,4,1
Belgium-First_Division_A,Waasland-Beveren,Kortrijk,2,1
Belgium-First_Division_A,Anderlecht,Zulte-Waregem,2,0
Belgium-First_Division_A,Genk,Club Brugge,2,0
England-EFL_Cup,Tottenham Hotspur,West Ham United,2,3
England-EFL_Cup,Chelsea,Everton,2,1
International-Friendlies,Grenada,Panama,0,5
Germany-DFB_Pokal,Osnabrueck,Nuernberg,2,3
Germany-DFB_Pokal,RasenBallsport Leipzig,Bayern Munich,5,6
Germany-DFB_Pokal,Kaiserslautern,VfB Stuttgart,1,3
Germany-DFB_Pokal,Werder Bremen,Hoffenheim,1,0
Germany-DFB_Pokal,Hertha Berlin,FC Cologne,1,3
Germany-DFB_Pokal,Freiburg,Dynamo Dresden,3,1
Germany-DFB_Pokal,Wolfsburg,Hannover 96,1,0
Germany-DFB_Pokal,Jahn Regensburg,FC Heidenheim,2,5
Netherlands-KNVB_Cup,Roda JC Kerkrade,FC Groningen,3,1
Netherlands-KNVB_Cup,VVV-Venlo,FC Utrecht,3,1
Netherlands-KNVB_Cup,Willem II,SC Heerenveen,2,1
Netherlands-KNVB_Cup,Heracles,Hoek,3,1
Netherlands-KNVB_Cup,Feyenoord,AVV Swift,4,1
Netherlands-KNVB_Cup,ASV de Dijk,Ajax,1,4
Russia-Cup,Avangard Kursk,FC Tambov,
Russia-Cup,Rubin Kazan,Krylya Sovetov Samara,1,2
Russia-Cup,SKA-Khabarovsk,Dinamo St Petersburg,2,0
Russia-Cup,Shinnik Yaroslavl,Olimpiec Nizhny,4,0
Russia-Cup,Luch Energiya Vladivostok,FC Yenisey Krasnoyarsk,2,1
Russia-Cup,Tosno,Tom Tomsk,6,5
Russia-Cup,FC Tambov,Avangard Kursk,0,2
Russia-Cup,FC Rostov,Amkar,10,11
Russia-Cup,Spartak Moscow,Spartak Nalchik,5,2
Scotland-Premiership,Rangers,Kilmarnock,1,1
International-Copa_Libertadores_Final_Stage,Barcelona SC,Gremio,0,3
Belgium-First_Division_A,Royal Antwerp,Standard Liege,0,0
Belgium-First_Division_A,St.Truiden,Royal Excel Mouscron,1,0
France-Coupe_de_France,CS Le Moule,US Ste Rose,1,0
Netherlands-KNVB_Cup,FC Volendam,PSV Eindhoven,0,2
Netherlands-KNVB_Cup,Almere City FC,AZ Alkmaar,0,4
Spain-Copa_del_Rey,Girona,Levante,0,2
Spain-Copa_del_Rey,Fuenlabrada,Real Madrid,0,2
Spain-Copa_del_Rey,Lleida Esportiu,Real Sociedad,0,1
Spain-Copa_del_Rey,Tenerife,Espanyol,0,0
Spain-Copa_del_Rey,Deportivo La Coruna,Las Palmas,1,4
Turkey-Cup,Yesil Bursa,Kayserispor,1,2
Turkey-Cup,Giresunspor,Menemen Belediyespor,2,1
Turkey-Cup,Yeni Altindag Belediyespor,Bursaspor,2,4
Turkey-Cup,Manisaspor,Hatayspor,1,0
Turkey-Cup,Anadolu Selcukspor,Boluspor,0,1
Turkey-Cup,Karabukspor,Keciorengucu,3,1
USA-Major_League_Soccer_Playoff,Chicago Fire,New York Red Bulls,0,4
USA-Major_League_Soccer_Playoff,Vancouver Whitecaps,San Jose Earthquakes,5,0
Bulgaria-Cup,Etar,Septemvri Sofia,2,1
Bulgaria-Cup,Ludogorets Razgrad,Beroe,5,4
International-Copa_Sudamericana,Fluminense,Flamengo,0,1
International-Copa_Sudamericana,Nacional,Independiente,1,4
Denmark-DBU_Pokalen,Holbaek,Randers FC,1,4
Egypt-Premier_League,Smouha SC,El Geish,0,1
Egypt-Premier_League,Tanta,Misr El-Maqasa,3,3
International-EURO_U17_Qualification_Grp__1,Belgium U17,Malta U17,3,1
International-EURO_U17_Qualification_Grp__1,N.Ireland U17,Switzerland U17,0,5
International-EURO_U17_Qualification_Grp__10,Romania U17,Luxembourg U17,0,0
International-EURO_U17_Qualification_Grp__10,Austria U17,Lithuania U17,2,0
Gibraltar-Premier_Division,Lynx,Lincoln Red Imps FC,0,4
Greece-Cup_Grp__1,OFI Crete,Platanias,1,0
Greece-Cup_Grp__3,Apollon Larissa,AEK Athens,0,7
Greece-Cup_Grp__4,Trikala,Atromitos,1,1
Greece-Cup_Grp__5,Asteras Tripolis,Kissamikos FC,2,1
Kosovo-Superliga,KF Vllaznia Pozheran,Feronikeli,0,3
Kosovo-Superliga,Besa Peje,Gjilani,0,0
Poland-FA_Cup,Zaglebie Lubin,Korona Kielce,0,1
Singapore-S_League,Balestier Khalsa FC,Albirex Niigata FC,0,3
Switzerland-Cup,Delemont,St. Gallen,1,2
France-Ligue_1,Paris Saint Germain,Nice,3,0
Germany-1__Bundesliga,Mainz 05,Eintracht Frankfurt,1,1
Netherlands-Eredivisie,FC Twente,Excelsior,1,3
Portugal-Primeira_Liga,Benfica,Feirense,1,0
Portugal-Primeira_Liga,Rio Ave,Sporting CP,0,1
Russia-Premier_League,Arsenal Tula,CSKA Moscow,1,0
Australia-A_League,Sydney FC,Perth Glory,2,0
Belgium-First_Division_A,Sporting Charleroi,Gent,2,1
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Botev Plovdiv,1,2
Bulgaria-First_Professional_League,Vitosha Bistritsa,Cherno More Varna,1,2
Czech_Republic-1__Division,Karvina,Viktoria Plzen,1,3
Denmark-Superligaen,AGF,FC Nordsjaelland,1,4
England-Championship,Leeds United,Sheffield United,1,2
Germany-2__Bundesliga,Arminia Bielefeld,Ingolstadt,1,3
Germany-2__Bundesliga,St. Pauli,Erzgebirge Aue,1,1
Ireland-Premier_Division,Bohemian FC,Finn Harps,3,1
Ireland-Premier_Division,Galway United FC,Dundalk,3,4
Ireland-Premier_Division,Cork City,Bray Wanderers,1,0
Ireland-Premier_Division,Shamrock Rovers,Limerick,2,1
Ireland-Premier_Division,Derry City,St. Patrick's Athletic,1,1
Ireland-Premier_Division,Drogheda United,Sligo Rovers,0,0
Netherlands-Eerste_Divisie,FC Den Bosch,Helmond Sport,2,2
Netherlands-Eerste_Divisie,FC Emmen,FC Oss,1,1
Netherlands-Eerste_Divisie,FC Eindhoven,Jong Ajax,2,3
Netherlands-Eerste_Divisie,De Graafschap,Fortuna Sittard,2,0
Netherlands-Eerste_Divisie,Cambuur,Jong PSV,0,1
Netherlands-Eerste_Divisie,Go Ahead Eagles,Jong AZ Alkmaar,2,1
Netherlands-Eerste_Divisie,NEC Nijmegen,Jong FC Utrecht,3,1
Netherlands-Eerste_Divisie,RKC Waalwijk,FC Dordrecht,1,0
N__Ireland-Premiership,Crusaders,Ballinamallard United,2,0
Poland-Ekstraklasa,Lech Poznan,Wisla Krakow,1,1
Poland-Ekstraklasa,Slask Wroclaw,Pogon Szczecin,3,0
Romania-Liga_I,CSMS Iasi,Concordia Chiajna,3,1
Spain-Segunda_Division,Zaragoza,Leonesa,0,0
Turkey-Super_Lig,Kasimpasa,Goztepe,3,1
USA-Major_League_Soccer_Playoff,Houston Dynamo,Sporting Kansas City,1,0
USA-Major_League_Soccer_Playoff,Atlanta United,Columbus Crew,1,3
Belgium-First_Division_B_1st_Stage,KFCO Beerschot-Wilrijk,Roeselare,5,0
Brazil-Serie_B,Figueirense,CRB,3,1
International-CONCACAF_League,Santos de Guapiles,CD Olimpia,1,5
Brazil-Serie_A,Flamengo,Vasco da Gama,0,0
Brazil-Serie_A,Sao Paulo,Santos FC,2,1
England-Premier_League,Watford,Stoke City,0,1
England-Premier_League,Crystal Palace,West Ham United,2,2
England-Premier_League,West Bromwich Albion,Manchester City,2,3
England-Premier_League,AFC Bournemouth,Chelsea,0,1
England-Premier_League,Manchester United,Tottenham Hotspur,1,0
England-Premier_League,Liverpool,Huddersfield Town,3,0
England-Premier_League,Arsenal,Swansea City,2,1
France-Ligue_1,Dijon,Nantes,1,0
France-Ligue_1,Strasbourg,Angers,2,2
France-Ligue_1,Bordeaux,Monaco,0,2
France-Ligue_1,Guingamp,Amiens,1,1
France-Ligue_1,Caen,Troyes,1,0
France-Ligue_1,Montpellier,Rennes,0,1
Germany-1__Bundesliga,Hoffenheim,Borussia Moenchengladbach,1,3
Germany-1__Bundesliga,Bayer Leverkusen,FC Cologne,2,1
Germany-1__Bundesliga,Hertha Berlin,Hamburger SV,2,1
Germany-1__Bundesliga,Bayern Munich,RasenBallsport Leipzig,2,0
Germany-1__Bundesliga,Hannover 96,Borussia Dortmund,4,2
Germany-1__Bundesliga,Schalke 04,Wolfsburg,1,1
Italy-Serie_A,AC Milan,Juventus,0,2
Italy-Serie_A,Roma,Bologna,1,0
Netherlands-Eredivisie,Willem II,Ajax,1,3
Netherlands-Eredivisie,Roda JC Kerkrade,Feyenoord,1,1
Netherlands-Eredivisie,PEC Zwolle,ADO Den Haag,2,0
Netherlands-Eredivisie,Heracles,VVV-Venlo,3,0
Portugal-Primeira_Liga,Maritimo,Tondela,2,0
Portugal-Primeira_Liga,Belenenses,Moreirense,3,0
Portugal-Primeira_Liga,Boavista,FC Porto,0,3
Russia-Premier_League,FC Rostov,Spartak Moscow,2,2
Spain-Primera_Division,Alaves,Valencia,1,2
Spain-Primera_Division,Sevilla,Leganes,2,1
Spain-Primera_Division,Atletico Madrid,Villarreal,1,1
Spain-Primera_Division,Athletic Bilbao,Barcelona,0,2
Argentina-Superliga,Argentinos Juniors,Arsenal Sarandi,3,2
Argentina-Superliga,Atletico Tucuman,Racing Club,3,1
Argentina-Superliga,Huracan,Lanus,4,0
Argentina-Superliga,Banfield,Colon,1,1
Argentina-Superliga,San Martin San Juan,Estudiantes,1,0
Brazil-Serie_A,Atletico MG,Botafogo RJ,0,0
Brazil-Serie_A,Avai FC,Gremio,2,2
Brazil-Serie_A,Sport Recife,Coritiba,3,4
Brazil-Serie_A,Atletico PR,Chapecoense AF,0,0
Brazil-Serie_A,Ponte Preta,Corinthians,1,0
Brazil-Serie_A,Vitoria,Atletico GO,1,1
Brazil-Serie_A,Fluminense,Bahia,1,1
England-Premier_League,Leicester City,Everton,2,0
England-Premier_League,Brighton &amp; Hove Albion,Southampton,1,1
France-Ligue_1,Lille,Marseille,0,1
France-Ligue_1,Toulouse,Saint-Etienne,0,0
France-Ligue_1,Lyon,Metz,2,0
Germany-1__Bundesliga,VfB Stuttgart,Freiburg,3,0
Germany-1__Bundesliga,Werder Bremen,Augsburg,0,3
Italy-Serie_A,SPAL 2013,Genoa,1,0
Italy-Serie_A,SSC Napoli,Sassuolo,3,1
Italy-Serie_A,Benevento,Lazio,1,5
Italy-Serie_A,Udinese,Atalanta,2,1
Italy-Serie_A,Sampdoria,ChievoVerona,4,1
Italy-Serie_A,Torino,Cagliari,2,1
Italy-Serie_A,Crotone,Fiorentina,2,1
Netherlands-Eredivisie,Sparta Rotterdam,FC Groningen,2,1
Netherlands-Eredivisie,SC Heerenveen,AZ Alkmaar,1,2
Netherlands-Eredivisie,FC Utrecht,NAC Breda,2,2
Netherlands-Eredivisie,Vitesse,PSV Eindhoven,2,4
Portugal-Primeira_Liga,Braga,Chaves,1,0
Portugal-Primeira_Liga,Aves,Vitoria de Guimaraes,1,3
Portugal-Primeira_Liga,Pacos de Ferreira,Estoril,1,0
Russia-Premier_League,Amkar,Ural,1,1
Russia-Premier_League,Zenit St. Petersburg,Lokomotiv Moscow,0,3
Russia-Premier_League,FC Krasnodar,SKA-Khabarovsk,4,1
Russia-Premier_League,Dinamo Moscow,Tosno,0,1
Spain-Primera_Division,Girona,Real Madrid,2,1
Spain-Primera_Division,Eibar,Levante,2,2
Spain-Primera_Division,Malaga,Celta Vigo,2,1
Spain-Primera_Division,Getafe,Real Sociedad,2,1
Argentina-Superliga,Boca Juniors,Belgrano,4,0
Argentina-Superliga,Gimnasia LP,Velez Sarsfield,4,0
Argentina-Superliga,Talleres,River Plate,4,0
Argentina-Superliga,Newells Old Boys,Chacarita Juniors,2,1
Brazil-Serie_A,Palmeiras,Cruzeiro,2,2
England-Premier_League,Burnley,Newcastle United,1,0
Italy-Serie_A,Hellas Verona,Inter,1,2
Portugal-Primeira_Liga,Portimonense,Vitoria de Setubal,5,2
Russia-Premier_League,FK Akhmat,Anzhi Makhachkala,1,1
Russia-Premier_League,FC Ufa,Rubin Kazan,2,1
Spain-Primera_Division,Las Palmas,Deportivo La Coruna,1,3
Spain-Primera_Division,Espanyol,Real Betis,1,0
Argentina-Superliga,Defensa y Justicia,Olimpo,1,1
Argentina-Superliga,Independiente,Patronato de Parana,1,1
Bulgaria-First_Professional_League,Dunav Ruse,Septemvri Sofia,0,1
Bulgaria-First_Professional_League,Lokomotiv Plovdiv,Etar,2,0
Croatia-1__Division,NK Istra 1961,Inter Zapresic,1,1
Denmark-Superligaen,Broendby IF,Randers FC,3,1
Germany-2__Bundesliga,Bochum,Fortuna Duesseldorf,0,0
Greece-Super_League,PAOK Thessaloniki FC,Asteras Tripolis,2,0
Israel-Ligat_HaAl,Maccabi Petach Tikva,Bnei Yehuda Tel Aviv,1,2
Italy-Serie_B,Ternana,Carpi,0,0
Mexico-Liga_MX_Apertura,Santos,Pachuca,2,2
Norway-Eliteserien,Lillestroem,Aalesund,4,0
Poland-Ekstraklasa,Lechia Gdansk,Korona Kielce,0,5
Romania-Liga_I,Dinamo Bucuresti,FC Viitorul Constanta,0,4
Romania-Liga_I,Sepsi OSK,Botosani,0,2
Spain-Segunda_Division,Granada,Lorca FC,4,1
Sweden-Allsvenskan,AIK,IFK Gothenburg,2,1
Sweden-Allsvenskan,IFK Norrkoeping,Oerebro,2,0
Turkey-Super_Lig,Fenerbahce,Kayserispor,3,3
Ukraine-Premier_League,Chernomorets Odessa,Mariupol,0,0
USA-Major_League_Soccer_Playoff,Vancouver Whitecaps,Seattle Sounders FC,0,0
International-EURO_U17_Qualification_Grp__13,Georgia U17,Italy U17,0,2
International-EURO_U17_Qualification_Grp__13,Montenegro U17,Latvia U17,1,1
France-Ligue_2,Chateauroux,Lens,0,0
Italy-Serie_C_Grp__C,Lecce,Cosenza,1,0
Kosovo-Superliga,Feronikeli,Gjilani,2,1
Sweden-Superettan,Oesters IF,Brommapojkarna,0,0
Sweden-Superettan,Norrby,IFK Vaernamo,2,3
Turkey-1__Lig,Rizespor,Boluspor,1,0
Turkey-1__Lig,Ankaragucu,Istanbulspor,1,0
Albania-Kategoria_Superiore,Laci,KF Kamza,0,1
Argentina-Federal_A_Zona_2,Desamparados,Deportivo Maipu,1,2
International-Champions_League_Grp__A,Basel,CSKA Moscow,1,2
International-Champions_League_Grp__A,Manchester United,Benfica,2,0
International-Champions_League_Grp__B,Celtic,Bayern Munich,1,2
International-Champions_League_Grp__B,Paris Saint Germain,Anderlecht,5,0
International-Champions_League_Grp__C,Roma,Chelsea,3,0
International-Champions_League_Grp__C,Atletico Madrid,Qarabag FK,1,1
International-Champions_League_Grp__D,Sporting CP,Juventus,1,1
International-Champions_League_Grp__D,Olympiacos,Barcelona,0,0
Argentina-Superliga,Tigre,Rosario Central,1,1
England-Championship,Sunderland,Bolton Wanderers,3,3
England-Championship,Fulham,Bristol City,0,2
England-Championship,Queens Park Rangers,Sheffield United,1,0
England-Championship,Reading,Nottingham Forest,3,1
England-Championship,Burton Albion,Barnsley,2,4
England-Championship,Hull City,Middlesbrough,1,3
England-Championship,Leeds United,Derby County,1,2
England-Championship,Sheffield Wednesday,Millwall,2,1
England-Championship,Cardiff City,Ipswich Town,3,1
England-Championship,Norwich City,Wolverhampton Wanderers,0,2
N__Ireland-Premiership,Coleraine,Ballinamallard United,2,1
Scotland-Premiership,Kilmarnock,Hibernian,0,3
USA-Major_League_Soccer_Playoff,Houston Dynamo,Portland Timbers,0,0
USA-Major_League_Soccer_Playoff,New York Red Bulls,Toronto FC,1,2
Brazil-Serie_B,Goias,Criciuma,1,1
England-League_1,Blackburn Rovers,Fleetwood Town,2,2
England-EFL_Trophy_Northern_Grp__G,Mansfield Town,Everton Academy,1,0
England-EFL_Trophy_Northern_Grp__H,Doncaster Rovers,Scunthorpe United,4,3
England-EFL_Trophy_Southern_Grp__C,Bristol Rovers,West Ham United Academy,1,3
England-EFL_Trophy_Southern_Grp__C,Swindon Town,Wycombe Wanderers,1,0
England-EFL_Trophy_Southern_Grp__E,Forest Green Rovers,Swansea City Academy,0,2
England-EFL_Trophy_Southern_Grp__F,AFC Wimbledon,Luton Town,1,2
Philippines-Philippines_Football_League,Loyola Meralco Sparks FC,JP Voltes FC,1,0
Singapore-S_League,Home United FC,Young Lions,4,0
Spain-Segunda_B_Grp__II,Real Sociedad B,SD Leioa,0,0
Argentina-Primera_B_Nacional,Aldosivi,Juventud Unida Gualeguaychu,2,0
Argentina-Primera_C,San Martin Burzaco,Leandro N. Alem,1,0
Argentina-Primera_C,Berazategui,Central Cordoba de Rosario,0,4
Argentina-Primera_C,Laferrere,Sportivo Barracas,0,0
Austria-Erste_Liga,Wattens,Wiener Neustadt,0,1
Austria-Erste_Liga,Kapfenberger SV,Floridsdorfer AC,4,1
International-Champions_League_Grp__E,Sevilla,Spartak Moscow,2,1
International-Champions_League_Grp__E,Liverpool,Maribor,3,0
International-Champions_League_Grp__F,SSC Napoli,Manchester City,2,4
International-Champions_League_Grp__F,Shakhtar Donetsk,Feyenoord,3,1
International-Champions_League_Grp__G,Besiktas,Monaco,1,1
International-Champions_League_Grp__G,FC Porto,RasenBallsport Leipzig,3,1
International-Champions_League_Grp__H,Borussia Dortmund,APOEL Nicosia,1,1
International-Champions_League_Grp__H,Tottenham Hotspur,Real Madrid,3,1
International-Copa_Libertadores_Final_Stage,Lanus,River Plate,4,2
England-Championship,Preston North End,Aston Villa,0,2
England-Championship,Birmingham City,Brentford,0,2
Spain-Segunda_Division,Gimnastic,Barcelona B,0,0
USA-Major_League_Soccer_Playoff,Columbus Crew,New York City FC,4,1
Brazil-Serie_B,Parana Clube,Oeste FC,1,2
International-Copa_Sudamericana,Racing Club,Libertad,0,0
Czech_Republic-Cup,Slovan Liberec,Karvina,5,3
Denmark-DBU_Pokalen,Hobro,FC Nordsjaelland,5,4
England-EFL_Trophy_Northern_Grp__B,Blackpool,Middlesbrough Academy,4,1
England-EFL_Trophy_Southern_Grp__A,Charlton Athletic,Fulham Academy,3,2
International-EURO_U17_Qualification_Grp__1,Switzerland U17,Belgium U17,0,2
International-EURO_U17_Qualification_Grp__1,Malta U17,N.Ireland U17,0,1
Finland-Veikkausliga_Qualification,Honka,HIFK,0,0
Gibraltar-Premier_Division,Glacis United,Lynx,0,0
Portugal-Segunda_Liga,Academico Viseu,Sporting Covilha,0,0
Portugal-Segunda_Liga,Braga B,Varzim,1,0
Portugal-Segunda_Liga,Benfica B,Santa Clara,1,3
Portugal-Segunda_Liga,Oliveirense,Academica,0,2
Portugal-Segunda_Liga,FC Porto B,Real SC,3,1
Portugal-Segunda_Liga,Arouca,Uniao da Madeira,1,0
Spain-Segunda_B_Grp__I,Gimnastica Segoviana,Ponferradina,0,0
Spain-Segunda_B_Grp__I,Celta Vigo B,Real Madrid Castilla,1,4
Spain-Segunda_B_Grp__I,Rapido de Bouzas,Racing de Ferrol,1,1
Spain-Segunda_B_Grp__I,Guijuelo,CF Talavera de la Reina,0,0
Spain-Segunda_B_Grp__I,Navalcarnero,Valladolid B,1,0
Spain-Segunda_B_Grp__I,Cerceda,San Sebastian de los Reyes,0,3
Spain-Segunda_B_Grp__I,Pontevedra,RC Deportivo Fabril,2,2
Spain-Segunda_B_Grp__I,Toledo,Fuenlabrada,3,4
Spain-Segunda_B_Grp__I,Atletico Madrid B,Rayo Majadahonda,0,0
Spain-Segunda_B_Grp__I,AD Union Adarve,Coruxo F.C.,1,0
Spain-Segunda_B_Grp__II,Athletic Bilbao B,CD Vitoria,1,0
International-Copa_Libertadores_Final_Stage,Gremio,Barcelona SC,0,1
International-Europa_League_Grp__A,Maccabi Tel Aviv,FC Astana,0,1
International-Europa_League_Grp__A,Slavia Prague,Villarreal,0,2
International-Europa_League_Grp__B,Partizan Beograd,Skenderbeu,2,0
International-Europa_League_Grp__B,Young Boys,Dynamo Kyiv,0,1
International-Europa_League_Grp__C,Istanbul Basaksehir,Hoffenheim,1,1
International-Europa_League_Grp__C,Ludogorets Razgrad,Braga,1,1
International-Europa_League_Grp__D,AEK Athens,AC Milan,0,0
International-Europa_League_Grp__D,Rijeka,Austria Wien,1,4
International-Europa_League_Grp__E,Lyon,Everton,3,0
International-Europa_League_Grp__E,Apollon Limassol,Atalanta,1,1
International-Europa_League_Grp__F,Lokomotiv Moscow,FC Sheriff,1,2
International-Europa_League_Grp__F,FC Koebenhavn,Zlin,3,0
International-Europa_League_Grp__G,FC FCSB,Hapoel Beer Sheva,1,1
International-Europa_League_Grp__G,Viktoria Plzen,Lugano,4,1
International-Europa_League_Grp__H,Arsenal,FK Crvena Zvezda,0,0
International-Europa_League_Grp__H,FC Cologne,BATE Borisov,5,2
International-Europa_League_Grp__I,Vitoria de Guimaraes,Marseille,1,0
International-Europa_League_Grp__I,Salzburg,Konyaspor,0,0
International-Europa_League_Grp__J,Hertha Berlin,Zorya,2,0
International-Europa_League_Grp__J,Athletic Bilbao,Oestersunds FK,1,0
International-Europa_League_Grp__K,Lazio,Nice,1,0
International-Europa_League_Grp__K,Vitesse,Zulte-Waregem,0,2
International-Europa_League_Grp__L,Rosenborg,Zenit St. Petersburg,1,1
International-Europa_League_Grp__L,Real Sociedad,FK Vardar Skopje,3,0
Mexico-Liga_MX_Apertura,Atlas,Tigres,1,1
International-Copa_Sudamericana,Independiente,Nacional,2,0
International-Copa_Sudamericana,Flamengo,Fluminense,3,3
Egypt-Premier_League,Ismaily SC,ENPPI,1,1
Egypt-Premier_League,Al Mokawloon Al Arab,El Dakhleya,1,1
Gibraltar-Premier_Division,Lincoln Red Imps FC,Manchester 62 FC,3,0
Philippines-Philippines_Football_League,Global FC,Stallion FC,4,3
Philippines-Philippines_Football_League,Ceres-Negros FC,Davao Aguilas,5,1
Singapore-S_League,Hougang United FC,Balestier Khalsa FC,0,1
Bolivia-Nacional_B_Grp__B,Universitario Beni,Vaca Diez,5,2
Colombia-Primera_A_Clausura,La Equidad,Bucaramanga,0,0
Colombia-Primera_A_Clausura,Envigado,Cortulua,2,0
Colombia-Primera_A_Clausura,America de Cali,Independiente Medellin,2,0
Costa_Rica-Primera_Division_Apertura,AD Municipal Liberia,C.S. Cartagines,0,3
Costa_Rica-Primera_Division_Apertura,Municipal Perez Zeledon,LD Alajuelense,3,2
England-FA_Cup,Notts County,Bristol Rovers,4,2
England-FA_Cup,Hyde United,Milton Keynes Dons,0,4
England-FA_Cup,Port Vale,Oxford United,2,0
France-Ligue_1,Rennes,Bordeaux,1,0
Germany-1__Bundesliga,Eintracht Frankfurt,Werder Bremen,2,1
Netherlands-Eredivisie,Sparta Rotterdam,SC Heerenveen,0,0
Portugal-Primeira_Liga,Vitoria de Setubal,Aves,0,1
Russia-Premier_League,Ural,Dinamo Moscow,2,2
Spain-Primera_Division,Real Betis,Getafe,2,2
Argentina-Superliga,Chacarita Juniors,Gimnasia LP,2,0
Australia-A_League,Melbourne City FC,Sydney FC,0,1
Belgium-First_Division_A,Gent,Standard Liege,1,0
Bulgaria-First_Professional_League,Botev Plovdiv,Slavia Sofia,1,1
Croatia-1__Division,Inter Zapresic,Osijek,3,1
Denmark-Superligaen,Silkeborg,AC Horsens,2,2
Denmark-Superligaen,FC Midtjylland,FC Helsingoer,2,1
England-Championship,Wolverhampton Wanderers,Fulham,2,0
Germany-2__Bundesliga,Sandhausen,Duisburg,0,1
Germany-2__Bundesliga,Kaiserslautern,Bochum,0,0
Italy-Serie_B,Pescara,Palermo,2,2
Netherlands-Eerste_Divisie,Helmond Sport,FC Emmen,3,1
Netherlands-Eerste_Divisie,Fortuna Sittard,FC Oss,4,0
Netherlands-Eerste_Divisie,Almere City FC,Jong AZ Alkmaar,3,2
Netherlands-Eerste_Divisie,FC Dordrecht,FC Den Bosch,0,3
Netherlands-Eerste_Divisie,NEC Nijmegen,Cambuur,3,1
Netherlands-Eerste_Divisie,Jong FC Utrecht,FC Eindhoven,1,2
Netherlands-Eerste_Divisie,Telstar,Go Ahead Eagles,3,1
Netherlands-Eerste_Divisie,MVV Maastricht,RKC Waalwijk,0,0
Netherlands-Eerste_Divisie,Jong Ajax,De Graafschap,0,5
Netherlands-Eerste_Divisie,FC Volendam,Jong PSV,1,0
Norway-Eliteserien,Sandefjord,Vaalerenga,2,0
Poland-Ekstraklasa,Korona Kielce,Slask Wroclaw,3,0
Poland-Ekstraklasa,Arka Gdynia,Lechia Gdansk,0,1
Romania-Liga_I,Botosani,FC Voluntari,1,0
Romania-Liga_I,Astra Giurgiu,CS Universitatea Craiova,2,2
Slovakia-Super_Liga,Tatran Presov,Zemplin Michalovce,1,0
Slovakia-Super_Liga,DAC 1904 Dunajska Streda,Slovan Bratislava,2,1
Slovakia-Super_Liga,Zeleziarne Podbrezova,Trencin,1,8
Slovenia-Prva_Liga,NK Celje,Rudar Velenje,2,1
Spain-Segunda_Division,Numancia,Alcorcon,1,0
Brazil-Serie_A,Botafogo RJ,Fluminense,1,2
Brazil-Serie_A,Atletico GO,Sao Paulo,0,1
Brazil-Serie_A,Santos FC,Atletico MG,3,1
England-Premier_League,Stoke City,Leicester City,2,2
England-Premier_League,West Ham United,Liverpool,1,4
England-Premier_League,Huddersfield Town,West Bromwich Albion,1,0
England-Premier_League,Swansea City,Brighton &amp; Hove Albion,0,1
England-Premier_League,Newcastle United,AFC Bournemouth,0,1
England-Premier_League,Southampton,Burnley,0,1
England-FA_Cup,Ebbsfleet United,Doncaster Rovers,2,6
England-FA_Cup,Bradford City,Chesterfield,2,0
England-FA_Cup,Crewe Alexandra,Rotherham United,2,1
England-FA_Cup,Plymouth Argyle,Grimsby Town,1,0
England-FA_Cup,Peterborough United,Tranmere Rovers,1,1
England-FA_Cup,Wigan Athletic,Crawley Town,2,1
England-FA_Cup,Shaw Lane AFC,Mansfield Town,1,3
England-FA_Cup,Carlisle United,Oldham Athletic,3,2
England-FA_Cup,Luton Town,Portsmouth,1,0
England-FA_Cup,Gateshead FC,Chelmsford,2,0
England-FA_Cup,Newport County,Walsall,2,1
England-FA_Cup,Boreham Wood,Blackpool,2,1
England-FA_Cup,Shrewsbury Town,Aldershot Town,5,0
England-FA_Cup,Morecambe,Hartlepool United,3,0
England-FA_Cup,Gainsborough,Slough Town,0,6
England-FA_Cup,AFC Wimbledon,Lincoln City,1,0
England-FA_Cup,Forest Green Rovers,Macclesfield Town,1,0
England-FA_Cup,Hereford,Telford,1,0
England-FA_Cup,Blackburn Rovers,Barnet,3,1
England-FA_Cup,Stevenage,Nantwich Town,5,0
England-FA_Cup,Cheltenham Town,Maidstone,2,4
England-FA_Cup,Colchester United,Oxford City,0,1
England-FA_Cup,Yeovil Town,Southend United,1,0
England-FA_Cup,Northampton Town,Scunthorpe United,0,0
England-FA_Cup,Rochdale,Bromley,4,0
England-FA_Cup,AFC Fylde,Kidderminster Harriers,4,2
England-FA_Cup,Gillingham,Leyton Orient,2,1
France-Ligue_1,Monaco,Guingamp,6,0
France-Ligue_1,Troyes,Strasbourg,3,0
France-Ligue_1,Montpellier,Amiens,1,1
France-Ligue_1,Nantes,Toulouse,2,1
Brazil-Serie_A,Gremio,Flamengo,3,1
Brazil-Serie_A,Chapecoense AF,Sport Recife,1,1
Brazil-Serie_A,Bahia,Ponte Preta,2,0
Brazil-Serie_A,Coritiba,Avai FC,4,0
Brazil-Serie_A,Corinthians,Palmeiras,3,2
Brazil-Serie_A,Cruzeiro,Atletico PR,1,0
Brazil-Serie_A,Vasco da Gama,Vitoria,1,1
England-Premier_League,Chelsea,Manchester United,1,0
England-Premier_League,Manchester City,Arsenal,3,1
England-Premier_League,Tottenham Hotspur,Crystal Palace,1,0
England-Premier_League,Everton,Watford,3,2
England-FA_Cup,Leatherhead,Billericay,1,1
England-FA_Cup,Woking,Bury,1,1
England-FA_Cup,Cambridge United,Sutton United,1,0
England-FA_Cup,Exeter City,Heybridge Swifts,3,1
England-FA_Cup,Coventry City,Maidenhead United,2,0
England-FA_Cup,Solihull Moors,Wycombe Wanderers,0,2
England-FA_Cup,Guiseley,Accrington Stanley,0,0
England-FA_Cup,Dartford,Swindon Town,1,5
England-FA_Cup,Charlton Athletic,Truro City,3,1
France-Ligue_1,Marseille,Caen,5,0
France-Ligue_1,Saint-Etienne,Lyon,0,5
France-Ligue_1,Nice,Dijon,1,0
France-Ligue_1,Metz,Lille,0,3
Germany-1__Bundesliga,FC Cologne,Hoffenheim,0,3
Germany-1__Bundesliga,Wolfsburg,Hertha Berlin,3,3
Italy-Serie_A,Cagliari,Hellas Verona,2,1
Italy-Serie_A,Atalanta,SPAL 2013,1,1
Italy-Serie_A,Juventus,Benevento,2,1
Italy-Serie_A,Inter,Torino,1,1
Italy-Serie_A,ChievoVerona,SSC Napoli,0,0
Italy-Serie_A,Sassuolo,AC Milan,0,2
Italy-Serie_A,Fiorentina,Roma,2,4
Netherlands-Eredivisie,Ajax,FC Utrecht,1,2
Netherlands-Eredivisie,PSV Eindhoven,FC Twente,4,3
Netherlands-Eredivisie,Vitesse,PEC Zwolle,0,0
Netherlands-Eredivisie,ADO Den Haag,Feyenoord,2,2
Portugal-Primeira_Liga,Vitoria de Guimaraes,Benfica,1,3
Portugal-Primeira_Liga,Chaves,Pacos de Ferreira,4,2
Portugal-Primeira_Liga,Sporting CP,Braga,2,2
England-FA_Cup,Chorley,Fleetwood Town,1,2
Argentina-Superliga,Patronato de Parana,Newells Old Boys,0,0
Argentina-Superliga,Arsenal Sarandi,Tigre,0,0
Australia-A_League,Melbourne Victory,Western Sydney Wanderers FC,1,1
Bulgaria-First_Professional_League,Septemvri Sofia,Pirin Blagoevgrad,1,0
Germany-2__Bundesliga,Nuernberg,Ingolstadt,1,2
Greece-Super_League,Levadiakos,Lamia,0,0
Israel-Ligat_HaAl,Hapoel Ashkelon,Hapoel Ironi Kiryat Shmona,0,0
Italy-Serie_B,Perugia,Avellino,1,1
Mexico-Liga_MX_Apertura,Tigres,Necaxa,1,0
Mexico-Liga_MX_Apertura,Veracruz,Toluca,0,1
N__Ireland-Premiership,Glentoran,Ballymena United,1,1
Romania-Liga_I,Juventus Bucuresti,ACS Poli Timisoara,1,1
Spain-Segunda_Division,Huesca,Zaragoza,3,1
USA-Major_League_Soccer_Playoff,Portland Timbers,Houston Dynamo,1,2
Brazil-Serie_B,Luverdense,Internacional,2,2
France-Ligue_2,Le Havre,Reims,0,0
Italy-Serie_C_Grp__A,Carrarese,Alessandria,2,1
Portugal-Segunda_Liga,Vitoria de Guimaraes B,Arouca,1,2
Argentina-Primera_B_Nacional,Deportivo Riestra,Villa Dalmine,1,1
Argentina-Primera_B_Metropolitana,CA Talleres Remedios de Escalada,Almirante Brown,2,1
Argentina-Primera_B_Metropolitana,CA Fenix,San Telmo,0,1
Armenia-1__Division,Pyunik II,Lori,1,2
Armenia-1__Division,Gandzasar II,Alashkert FC II,0,2
Armenia-1__Division,Erebuni,Ararat II,3,0
Belarus-Premier_League,Torpedo Zhodino,BATE Borisov,2,4
Bolivia-Primera_Division___Clausura_Adecuacion,Blooming,Oriente Petrolero,2,2
Chile-Primera_B_Torneo_de_Transicion,San Marcos,Union La Calera,1,3
Colombia-Primera_A_Clausura,Patriotas,Millonarios,1,2
Colombia-Primera_A_Clausura,Deportivo Cali,Atletico Nacional,1,0
Colombia-Primera_A_Clausura,Rionegro Aguilas,La Equidad,0,1
Colombia-Primera_A_Clausura,Tolima,Atletico Junior,2,2
Colombia-Primera_B_Clausura_Final_Stage,Cucuta,Barranquilla FC,3,0
Denmark-1__Division,Fredericia,Viborg,2,2
Denmark-Reserve_League_First_Stage_Grp__1,Broendby Reserves,FC Helsingoer Reserves,3,1
Denmark-Reserve_League_First_Stage_Grp__1,FC Koebenhavn Reserves,Lyngby Reserves,2,3
Denmark-Reserve_League_First_Stage_Grp__2,SoenderjyskE Reserves,OB Reserves,0,1
Denmark-Reserve_League_First_Stage_Grp__3,AC Horsens Reserves,FC Midtjylland Reserves,1,3
Denmark-Reserve_League_First_Stage_Grp__3,AGF Reserves,Silkeborg Reserves,2,0
Denmark-Reserve_League_First_Stage_Grp__4,Hobro Reserves,Randers FC Reserves,2,2
Argentina-Superliga,Velez Sarsfield,Union,0,2
International-Friendlies,Saudi Arabia,Latvia,2,0
Brazil-Serie_B,Brasil de Pelotas,Parana Clube,2,0
Brazil-Serie_B,Criciuma,Boa Esporte Clube,2,0
Brazil-Serie_B,Nautico,Paysandu,1,3
Brazil-Serie_B,Londrina EC,Goias,2,0
Brazil-Serie_B,Vila Nova,Santa Cruz,1,1
Brazil-Serie_B,Oeste FC,Figueirense,1,1
Brazil-Serie_B,America MG,ABC,2,0
England-EFL_Trophy_Northern_Grp__A,Morecambe,Leicester City Academy,6,4
England-EFL_Trophy_Northern_Grp__B,Wigan Athletic,Accrington Stanley,0,4
England-EFL_Trophy_Northern_Grp__C,Rochdale,Blackburn Rovers,6,4
England-EFL_Trophy_Northern_Grp__D,Port Vale,Crewe Alexandra,4,2
England-EFL_Trophy_Northern_Grp__D,Oldham Athletic,Newcastle Academy,4,1
England-EFL_Trophy_Northern_Grp__E,Coventry City,West Bromwich Albion Academy,2,1
England-EFL_Trophy_Northern_Grp__E,Shrewsbury Town,Walsall,0,1
England-EFL_Trophy_Northern_Grp__F,Bradford City,Rotherham United,0,3
England-EFL_Trophy_Northern_Grp__G,Lincoln City,Notts County,2,1
England-EFL_Trophy_Southern_Grp__A,Charlton Athletic,Portsmouth,0,1
England-EFL_Trophy_Southern_Grp__B,Gillingham,Reading Academy,7,5
England-EFL_Trophy_Southern_Grp__B,Southend United,Colchester United,2,0
England-EFL_Trophy_Southern_Grp__E,Newport County,Cheltenham Town,1,2
England-EFL_Trophy_Southern_Grp__G,Oxford United,Milton Keynes Dons,3,4
England-EFL_Trophy_Southern_Grp__G,Stevenage,Brighton &amp; Hove Albion Academy,3,1
England-EFL_Trophy_Southern_Grp__H,Cambridge United,Peterborough United,0,2
England-EFL_Trophy_Southern_Grp__H,Northampton Town,Southampton Academy,7,5
International-EURO_U19_Qualification_Grp__13,Wales U19,Slovakia U19,1,2
International-EURO_U19_Qualification_Grp__13,Turkey U19,Kazakhstan U19,3,0
Italy-Serie_C_Grp__C,Reggina,Siracusa Calcio,0,2
Italy-Serie_C_Grp__C,Akragas,Cosenza,0,2
Italy-Serie_C_Grp__C,Catanzaro,Monopoli,1,0
Italy-Serie_C_Grp__C,Lecce,Casertana,2,1
Italy-Serie_C_Grp__C,Sicula Leonzio,Fidelis Andria,1,1
Italy-Serie_C_Grp__C,Bisceglie,Matera,2,1
Italy-Serie_C_Grp__C,Juve Stabia,Virtus Francavilla,1,1
Italy-Serie_C_Grp__C,Paganese,Catania,2,5
Italy-Serie_C_Grp__C,Trapani,Rende,4,0
Wales-Premier_League,Bangor City,Aberystwyth,3,2
Algeria-Ligue_1,CR Belouizdad,MC Oran,0,0
Algeria-Ligue_1,ES Setif,JS Kabylie,0,0
Brazil-Serie_A,Ponte Preta,Gremio,0,1
Brazil-Serie_A,Avai FC,Bahia,1,2
International-EURO_U21_Qualification_Grp__1,Croatia U21,San Marino U21,5,0
International-Friendlies,Congo,Benin,1,1
International-Friendlies,Iceland,Czech Republic,1,2
International-Friendlies,Lesotho,Zimbabwe,1,0
Brazil-Serie_B,Ceara,Guarani,2,2
Brazil-Serie_B,CRB,Juventude,2,0
International-Club_Friendlies,Borussia Moenchengladbach,Arminia Bielefeld,4,1
International-Club_Friendlies,Cambuur,AZ Alkmaar,1,5
International-Club_Friendlies,FC Groningen,Preussen Muenster,4,1
International-Club_Friendlies,Sparta Rotterdam,FC Volendam,4,0
England-EFL_Trophy_Northern_Grp__A,Carlisle United,Fleetwood Town,1,2
England-EFL_Trophy_Northern_Grp__C,Bury,Stoke City Academy,3,1
England-EFL_Trophy_Northern_Grp__H,Grimsby Town,Sunderland Academy,7,8
England-EFL_Trophy_Southern_Grp__C,Bristol Rovers,Swindon Town,2,4
International-EURO_U19_Qualification_Grp__1,Croatia U19,San Marino U19,3,0
International-EURO_U19_Qualification_Grp__1,Latvia U19,Denmark U19,1,2
International-EURO_U19_Qualification_Grp__10,Russia U19,Gibraltar U19,6,0
International-EURO_U19_Qualification_Grp__10,Romania U19,Greece U19,2,1
International-EURO_U19_Qualification_Grp__11,Bosnia and Herzegovina U19,Georgia U19,1,0
International-EURO_U19_Qualification_Grp__11,France U19,Andorra U19,7,0
International-EURO_U19_Qualification_Grp__3,Czech Republic U19,Armenia U19,5,0
International-EURO_U19_Qualification_Grp__3,Luxembourg U19,Scotland U19,1,3
International-EURO_U19_Qualification_Grp__5,Belgium U19,Liechtenstein U19,3,0
International-EURO_U19_Qualification_Grp__5,Macedonia U19,Switzerland U19,2,1
International-EURO_U19_Qualification_Grp__8,Iceland U19,Bulgaria U19,1,2
International-EURO_U19_Qualification_Grp__8,England U19,Faroe Islands U19,6,0
Gibraltar-Premier_Division,Manchester 62 FC,Glacis United,1,1
Italy-Serie_C_Grp__A,Pontedera,Cuneo,0,3
Italy-Serie_C_Grp__A,Pro Piacenza,Monza,1,0
Italy-Serie_C_Grp__A,Lucchese,Prato,0,0
Italy-Serie_C_Grp__A,Giana Erminio,Piacenza,4,3
Italy-Serie_C_Grp__A,Pistoiese,Robur Siena,1,2
Italy-Serie_C_Grp__A,Livorno,Viterbese,3,0
Italy-Serie_C_Grp__A,US Gavorrano,Arezzo,0,0
Italy-Serie_C_Grp__B,Calcio Padova,Mestre,2,1
Italy-Serie_C_Grp__B,Sambenedettese,Sudtirol,0,1
Italy-Serie_C_Grp__B,Gubbio,Ravenna,0,1
Italy-Serie_C_Grp__B,Reggiana,Pordenone Calcio,1,0
Brazil-Serie_A,Santos FC,Vasco da Gama,1,2
Brazil-Serie_A,Atletico MG,Atletico GO,3,2
Brazil-Serie_A,Atletico PR,Corinthians,0,1
Brazil-Serie_A,Vitoria,Palmeiras,3,1
Brazil-Serie_A,Sport Recife,Botafogo RJ,1,2
Brazil-Serie_A,Flamengo,Cruzeiro,2,0
Brazil-Serie_A,Sao Paulo,Chapecoense AF,2,2
International-World_Cup_Qualification_UEFA_2nd_Round,Croatia,Greece,4,1
International-World_Cup_Qualification_UEFA_2nd_Round,N.Ireland,Switzerland,0,1
International-EURO_U21_Qualification_Grp__2,Spain U21,Iceland U21,1,0
International-EURO_U21_Qualification_Grp__5,Kosovo U21,Israel U21,0,4
International-EURO_U21_Qualification_Grp__5,Azerbaijan U21,Germany U21,0,7
International-EURO_U21_Qualification_Grp__6,Belgium U21,Cyprus U21,3,2
International-EURO_U21_Qualification_Grp__9,France U21,Bulgaria U21,3,0
International-EURO_U21_Qualification_Grp__9,Slovenia U21,Montenegro U21,2,0
International-Friendlies,Cambodia,Myanmar,1,2
International-Friendlies,Nicaragua,Dominican Republic,0,3
International-Friendlies,Hong Kong,Bahrain,0,2
International-Friendlies,Romania,Turkey,2,0
International-Friendlies,Armenia,Belarus,4,1
International-Friendlies,Finland,Estonia,3,0
International-Friendlies,Singapore,Lebanon,0,1
International-Friendlies,Panama,Iran,1,2
International-Friendlies,Scotland,Netherlands,0,1
International-Friendlies,Luxembourg,Hungary,2,1
International-Friendlies,Egypt,U.A.E.,
International-Club_Friendlies,Mantova,ChievoVerona,0,6
International-Club_Friendlies,Hamburger SV,SV Curslack-Neuengamme,6,0
International-Club_Friendlies,Francs Borains,Sporting Charleroi,0,1
International-Club_Friendlies,Bayer Leverkusen,Duisburg,3,3
International-Club_Friendlies,Union Berlin,AC Horsens,1,1
International-Club_Friendlies,Mattersburg,Trencin,5,2
International-Club_Friendlies,Torino,ASD Calcio Chieri 1955,3,0
International-Club_Friendlies,Wolfsburg,FC Twente,2,1
International-Club_Friendlies,Nuorese,Cagliari,0,3
International-Club_Friendlies,Werder Bremen,SC Heerenveen,2,2
International-Club_Friendlies,Mainz 05,F91 Dudelange,3,5
International-Club_Friendlies,FC Zuerich,Aarau,
Gibraltar-Premier_Division,Lions Gibraltar,Mons Calpe SC,2,1
Italy-Serie_C_Grp__A,Carrarese,Pisa,2,3
Brazil-Serie_A,Fluminense,Coritiba,2,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Algeria,Nigeria,3,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,South Africa,Senegal,0,2
International-World_Cup_Qualification_Inter_Confederation_Playoff,Honduras,Australia,0,0
International-World_Cup_Qualification_UEFA_2nd_Round,Sweden,Italy,1,0
International-Asian_Cup_Qualification_Round_3_Grp__B,North Korea,Malaysia,4,1
Australia-A_League,Central Coast Mariners,Sydney FC,2,0
International-EURO_U21_Qualification_Grp__2,Albania U21,N.Ireland U21,1,1
International-EURO_U21_Qualification_Grp__3,Faroe Islands U21,Poland U21,2,2
International-EURO_U21_Qualification_Grp__3,Georgia U21,Finland U21,2,2
International-EURO_U21_Qualification_Grp__4,Netherlands U21,Andorra U21,8,0
International-EURO_U21_Qualification_Grp__4,Ukraine U21,England U21,0,2
International-EURO_U21_Qualification_Grp__4,Scotland U21,Latvia U21,1,1
International-EURO_U21_Qualification_Grp__6,Hungary U21,Sweden U21,2,2
International-EURO_U21_Qualification_Grp__6,Malta U21,Turkey U21,0,1
International-EURO_U21_Qualification_Grp__7,Austria U21,Serbia U21,1,3
International-EURO_U21_Qualification_Grp__7,Armenia U21,Russia U21,1,2
International-EURO_U21_Qualification_Grp__8,Wales U21,Bosnia and Herzegovina U21,0,4
International-EURO_U21_Qualification_Grp__8,Romania U21,Portugal U21,1,1
France-Coupe_de_France,Noeux-les-Mines,Lens,0,5
International-Friendlies,Ukraine,Slovakia,2,1
International-Friendlies,Portugal,Saudi Arabia,3,0
International-Friendlies,Georgia,Cyprus,1,0
International-Friendlies,China,Serbia,0,2
International-Friendlies,England,Germany,0,0
International-Friendlies,South Korea,Colombia,2,1
International-Friendlies,Poland,Uruguay,0,0
International-Friendlies,U.A.E.,Haiti,0,1
International-Friendlies,France,Wales,2,0
International-Friendlies,Japan,Brazil,1,3
International-Friendlies,Belgium,Mexico,3,3
Mexico-Liga_MX_Apertura,Monterrey,Santos,1,1
N__Ireland-Premiership,Ballymena United,Linfield,2,1
Spain-Segunda_Division,Cordoba,Osasuna,0,1
Brazil-Serie_B,Juventude,Oeste FC,0,0
International-Club_Friendlies,Luzern,Chiasso,0,3
International-Club_Friendlies,SV Enter,Heracles,3,5
International-Club_Friendlies,Austria Wien,Dinamo Brest,3,2
International-Club_Friendlies,Eintracht Frankfurt,Sandhausen,5,3
International-Club_Friendlies,St. Pauli,OB,3,1
Brazil-Serie_A,Corinthians,Avai FC,1,0
Brazil-Serie_A,Botafogo RJ,Atletico PR,0,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,DR Congo,Guinea,3,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__A,Tunisia,Libya,0,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__B,Zambia,Cameroon,2,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Ivory Coast,Morocco,0,2
International-World_Cup_Qualification_CAF_3rd_Round_Grp__C,Gabon,Mali,0,0
International-World_Cup_Qualification_Inter_Confederation_Playoff,New Zealand,Peru,0,0
International-World_Cup_Qualification_UEFA_2nd_Round,Denmark,Ireland,0,0
Australia-A_League,Adelaide United,Newcastle Jets,1,2
Australia-A_League,Melbourne Victory,Brisbane Roar FC,1,1
International-EURO_U21_Qualification_Grp__1,Czech Republic U21,San Marino U21,3,1
France-Coupe_de_France,Feurs,Lyon la Duchere,1,2
France-Coupe_de_France,Seyssinet Pariset,Bourg en Bresse Peronnas,2,3
France-Coupe_de_France,AF Vire,Chambly,0,1
France-Coupe_de_France,Epinal,CS Le Moule,6,2
France-Coupe_de_France,Feignies Aulnoye,AS Excelsior,1,3
France-Coupe_de_France,Tournefeuille,Niort,1,5
France-Coupe_de_France,Les Sables TVEC,Olympique Saumur,1,2
France-Coupe_de_France,SC Hazebrouck,Quevilly,2,1
France-Coupe_de_France,Langon FC,US Colomiers,0,1
France-Coupe_de_France,St Pontivyen,Laval,0,3
France-Coupe_de_France,Concarneau,Golden Lion de Saint Joseph,7,0
France-Coupe_de_France,Tarentaise,4 Rivieres 70 FC,2,0
France-Coupe_de_France,AS ET Matoury,Avranches,3,2
France-Coupe_de_France,Angouleme,Bressuire,2,0
France-Coupe_de_France,Epernay,Raon L Etape,0,2
France-Coupe_de_France,Caen PTT,Le Mans,0,1
France-Coupe_de_France,Stade Briochin,Le Geldar de Kourou,9,1
France-Coupe_de_France,Chamalieres,Auxerre,1,3
France-Coupe_de_France,La Tour Saint-Clair,Gueugnon,0,1
France-Coupe_de_France,Arras,Gallia CL,3,2
France-Coupe_de_France,FC de la Valdaine,Fabregues,0,4
France-Coupe_de_France,Montauban,La Brede,3,4
France-Coupe_de_France,Douarnenez,Lorient,0,4
France-Coupe_de_France,Entente SSG,AS Lossi,7,1
France-Coupe_de_France,Villefranche Beaujolais,Sochaux,1,2
France-Coupe_de_France,St Maur Lusitanos,CM Aubervilliers,0,2
France-Coupe_de_France,Agglo Troyenne,Valenciennes,0,2
France-Coupe_de_France,Annecy FC,Grenoble,1,3
Brazil-Serie_A,Cruzeiro,Fluminense,3,1
Brazil-Serie_A,Gremio,Vitoria,1,1
Brazil-Serie_A,Bahia,Atletico MG,2,2
Brazil-Serie_A,Vasco da Gama,Sao Paulo,1,1
Brazil-Serie_A,Coritiba,Ponte Preta,1,1
Brazil-Serie_A,Atletico GO,Sport Recife,2,0
Brazil-Serie_A,Palmeiras,Flamengo,2,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Congo,Uganda,1,1
International-World_Cup_Qualification_CAF_3rd_Round_Grp__E,Ghana,Egypt,1,1
International-World_Cup_Qualification_UEFA_2nd_Round,Greece,Croatia,0,0
International-World_Cup_Qualification_UEFA_2nd_Round,Switzerland,N.Ireland,0,0
Australia-A_League,Wellington Phoenix,Perth Glory,5,2
Australia-A_League,Melbourne City FC,Western Sydney Wanderers FC,1,1
France-Coupe_de_France,AFC Compiegne,Furiani Agliani,0,1
France-Coupe_de_France,AJ Petite Ile,Beauvais,0,1
France-Coupe_de_France,Sene FC,Quimperle,3,2
France-Coupe_de_France,Evreux,Le Havre,3,2
France-Coupe_de_France,Pledran,Brest,0,5
France-Coupe_de_France,Lille Oms Fives,Itancourt Neuville,6,4
France-Coupe_de_France,Feytiat,Cholet,1,6
France-Coupe_de_France,La Courneuve,Blanc Mesnil,0,2
France-Coupe_de_France,Plomelin,St. Malo,0,5
France-Coupe_de_France,Chaumont,Le Puy,0,3
France-Coupe_de_France,Chantilly US,Racing Club de France Colombes 92,0,3
France-Coupe_de_France,Tefana,Rodez,0,3
France-Coupe_de_France,UL Rombas,Thaon,2,0
France-Coupe_de_France,Anduzien,Sud Ardeche,2,0
France-Coupe_de_France,Geispolsheim,Reims,0,2
France-Coupe_de_France,FC Chartres,Orleans,3,1
France-Coupe_de_France,St Amand FC,AC Ajaccio,1,3
France-Coupe_de_France,Pays Argentonnais,Tours,0,8
France-Coupe_de_France,Vallee Gresse,Cluses Scionzier,2,5
France-Coupe_de_France,US Granvillaise,Vierzon FC,3,2
France-Coupe_de_France,AS Cagnes le Cros,GFC Ajaccio,1,4
France-Coupe_de_France,Liffre,Vannes,1,2
France-Coupe_de_France,Bron Grand Lyon,Imphy-Decize,0,3
France-Coupe_de_France,Marcquois,Fleury Merogis U.S,1,2
France-Coupe_de_France,Club Colonial Fort de France,ASM Belfort,2,3
France-Coupe_de_France,La Chapelle Sur Erdre,Bergerac Perigord,0,2
France-Coupe_de_France,Rungis,Amiens Portugais,2,0
Brazil-Serie_A,Chapecoense AF,Santos FC,2,0
International-World_Cup_Qualification_UEFA_2nd_Round,Italy,Sweden,0,0
International-Asian_Cup_Qualification_Round_3_Grp__B,Malaysia,North Korea,1,4
International-EURO_U21_Qualification_Grp__1,Greece U21,Croatia U21,1,1
International-EURO_U21_Qualification_Grp__9,Slovenia U21,France U21,1,3
International-Friendlies,Iraq,Syria,1,1
International-Friendlies,Venezuela,Iran,0,1
International-Friendlies,Turkey,Albania,2,3
International-Friendlies,Armenia,Cyprus,3,2
International-Friendlies,Bulgaria,Saudi Arabia,1,0
International-Friendlies,Georgia,Belarus,2,2
International-Friendlies,Poland,Mexico,0,1
International-Friendlies,Kosovo,Latvia,4,3
Spain-Segunda_Division,Cadiz,Reus,1,0
International-Club_Friendlies,Werder Bremen,BSV Rehden,4,1
International-EURO_U19_Qualification_Grp__13,Slovakia U19,Turkey U19,3,2
International-EURO_U19_Qualification_Grp__13,Kazakhstan U19,Wales U19,3,2
Gibraltar-Premier_Division,Glacis United,Mons Calpe SC,1,0
Italy-Serie_C_Grp__B,Santarcangelo,Vicenza,2,1
Argentina-Federal_A_Zona_2,Gutierrez SC,Deportivo Maipu,2,3
Argentina-Federal_A_Zona_2,Huracan Las Heras,Union Aconquija,0,0
Argentina-Federal_A_Zona_2,Desamparados,Juventud Unida Universitario,3,0
Argentina-Federal_A_Zona_3,Douglas Haig,Defensores de Belgrano de Villa Ramallo,0,2
Argentina-Primera_C,Defensores de Cambaceres,San Martin Burzaco,2,0
Argentina-Cup,River Plate,Deportivo Moron,3,0
Bolivia-Primera_Division___Clausura_Adecuacion,Oriente Petrolero,San Jose,1,2
Colombia-Primera_A_Clausura,Deportivo Pasto,Envigado,1,2
Colombia-Primera_A_Clausura,Tigres FC,Atletico Nacional,1,0
Denmark-1__Division,Vendsyssel FF,Thisted,4,1
Denmark-Reserve_League_First_Stage_Grp__2,OB Reserves,Esbjerg Reserves,3,1
DR_Congo-Super_League_Zone_South_Central,Don Bosco,J.S. Bazano,1,1
DR_Congo-Super_League_Zone_South_Central,TP Mazembe,Ecofoot Katumbi,2,0
England-FA_Trophy_Qualification,Kingstonian,Ashford Town,2,0
England-FA_Trophy_Qualification,Haringey Borough,Sittingbourne,1,0
England-FA_Trophy_Qualification,Beaconsfield Town,Taunton Town,7,8
Italy-Serie_D_Grp__A,Inveruno,Como,0,1
Jamaica-Premier_League,Montego Bay United FC,Waterhouse FC,1,0
Kenya-National_Super_League,Nairobi City Stars,Administration Police,1,1
Kenya-National_Super_League,MOSCA FC,Bidco United,0,1
Moldova-Division_A,Zimbru II,Real Succes Lilcora,1,0
England-FA_Cup,Accrington Stanley,Guiseley,4,5
England-FA_Cup,Bury,Woking,0,3
England-FA_Cup,Scunthorpe United,Northampton Town,1,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,Burkina Faso,Cape Verde,4,0
International-World_Cup_Qualification_CAF_3rd_Round_Grp__D,Senegal,South Africa,2,1
International-World_Cup_Qualification_UEFA_2nd_Round,Ireland,Denmark,1,5
International-Asian_Cup_Qualification_Round_3_Grp__A,India,Myanmar,2,2
International-Asian_Cup_Qualification_Round_3_Grp__A,Macau,Kyrgyzstan,3,4
International-Asian_Cup_Qualification_Round_3_Grp__B,Hong Kong,Lebanon,0,1
International-Asian_Cup_Qualification_Round_3_Grp__C,Cambodia,Jordan,0,1
International-Asian_Cup_Qualification_Round_3_Grp__C,Vietnam,Afghanistan,0,0
International-Asian_Cup_Qualification_Round_3_Grp__D,Bhutan,Oman,2,4
International-Asian_Cup_Qualification_Round_3_Grp__D,Palestine,Maldives,8,1
International-Asian_Cup_Qualification_Round_3_Grp__E,Turkmenistan,Chinese Taipei,2,1
International-Asian_Cup_Qualification_Round_3_Grp__E,Singapore,Bahrain,0,3
International-Asian_Cup_Qualification_Round_3_Grp__F,Tajikistan,Yemen,0,0
International-Asian_Cup_Qualification_Round_3_Grp__F,Nepal,Philippines,0,0
International-EURO_U21_Qualification_Grp__1,Moldova U21,Czech Republic U21,1,3
International-EURO_U21_Qualification_Grp__2,Estonia U21,Iceland U21,2,3
International-EURO_U21_Qualification_Grp__2,Spain U21,Slovakia U21,5,1
International-EURO_U21_Qualification_Grp__3,Poland U21,Denmark U21,3,1
International-EURO_U21_Qualification_Grp__3,Georgia U21,Lithuania U21,1,0
International-EURO_U21_Qualification_Grp__4,Scotland U21,Ukraine U21,0,2
International-EURO_U21_Qualification_Grp__5,Israel U21,Germany U21,2,5
International-EURO_U21_Qualification_Grp__5,Azerbaijan U21,Kosovo U21,0,0
International-EURO_U21_Qualification_Grp__5,Norway U21,Ireland U21,2,1
International-EURO_U21_Qualification_Grp__6,Turkey U21,Belgium U21,1,2
International-EURO_U21_Qualification_Grp__6,Cyprus U21,Hungary U21,0,2
International-EURO_U21_Qualification_Grp__7,Macedonia U21,Austria U21,0,4
International-EURO_U21_Qualification_Grp__7,Armenia U21,Serbia U21,0,1
International-EURO_U21_Qualification_Grp__8,Wales U21,Romania U21,0,0
International-EURO_U21_Qualification_Grp__8,Portugal U21,Switzerland U21,2,1
International-EURO_U21_Qualification_Grp__9,Bulgaria U21,Montenegro U21,3,1
International-Friendlies,U.A.E.,Uzbekistan,1,0
International-Friendlies,Belgium,Japan,1,0
International-Friendlies,Gabon,Botswana,0,0
International-Friendlies,Botswana,Ghana,
International-Friendlies,Argentina,Nigeria,2,4
International-Friendlies,Romania,Netherlands,0,3
International-Friendlies,England,Brazil,0,0
Brazil-Serie_A,Gremio,Sao Paulo,1,0
Brazil-Serie_A,Ponte Preta,Atletico PR,2,1
Brazil-Serie_A,Cruzeiro,Avai FC,2,2
England-FA_Cup,Tranmere Rovers,Peterborough United,0,5
International-World_Cup_Qualification_Inter_Confederation_Playoff,Australia,Honduras,3,1
International-Friendlies,Trinidad and Tobago,Guyana,1,1
N__Ireland-League_Cup,Ballymena United,Ards,3,2
N__Ireland-League_Cup,Dungannon Swifts,Ballyclare Comrades,2,1
N__Ireland-League_Cup,Carrick Rangers,Cliftonville,0,1
N__Ireland-League_Cup,Crusaders,Linfield,2,0
Brazil-Serie_B,CRB,Goias,2,1
Brazil-Serie_B,America MG,Juventude,1,0
Brazil-Serie_B,Ceara,Paysandu,2,0
Brazil-Serie_B,Luverdense,Boa Esporte Clube,0,1
Brazil-Serie_B,Santa Cruz,Parana Clube,0,0
International-Club_Friendlies,Real Betis,Ecija,4,0
Egypt-Premier_League,El Dakhleya,Alassiouty,2,0
Egypt-Premier_League,ENPPI,Al-Ittihad Al-Sakandary,2,0
Egypt-Premier_League,Wadi Degla FC,Misr El-Maqasa,3,3
Gibraltar-Premier_Division,Lincoln Red Imps FC,Lions Gibraltar,3,1
Philippines-Philippines_Football_League,Ilocos United,Global FC,3,3
Sweden-Allsvenskan_Qualification,Trelleborgs FF,Joenkoepings Soedra,2,0
Albania-Kategoria_Superiore,Luftetari,Teuta Durres,2,3
Argentina-Federal_A_Zona_1,Independiente de Neuquen,Deportivo Madryn,1,0
Argentina-Federal_A_Zona_4,Deportivo San Jorge Tucuman,CA Chaco For Ever,0,0
Argentina-Primera_B_Metropolitana,Atlanta,Acassuso,0,2
Costa_Rica-Liga_de_Ascenso_Apertura_Final_Stage,Escazu FC,ADR Jicaral,1,1
Costa_Rica-Liga_de_Ascenso_Apertura_Final_Stage,Sporting San Jose,Puntarenas FC,1,1
Denmark-1__Division,Nykoebing FC,Fredericia,2,3
Denmark-Ligaen_U17,AGF U17,FC Koebenhavn U17,1,2
DR_Congo-Super_League_Zone_East,Bukavu Dawa,CS Makiso,1,0
DR_Congo-Super_League_Zone_East,Dauphins Noirs,Mont Bleu,1,0
DR_Congo-Super_League_Zone_East,Virunga,Maniema Union,2,1
DR_Congo-Super_League_Zone_East,Bukavu Dawa,CS Makiso,1,0
DR_Congo-Super_League_Zone_West,AS Vita Club,Molunge,3,0
DR_Congo-Super_League_Zone_West,Shark XI,Nord Sport,0,3
El_Salvador-Primera_Division___Apertura,CD Dragon,Firpo,0,0
El_Salvador-Primera_Division___Apertura,Municipal Limeno,Alianza FC,0,1
England-Southern_Premier_Division,Frome Town,Dorchester Town,3,1
England-FA_Trophy_Qualification,Cleethorpes Town,Hednesford,2,1
Brazil-Serie_A,Corinthians,Fluminense,3,1
Brazil-Serie_A,Palmeiras,Sport Recife,5,1
Brazil-Serie_A,Chapecoense AF,Vitoria,2,1
Brazil-Serie_A,Vasco da Gama,Atletico MG,1,1
Brazil-Serie_A,Botafogo RJ,Atletico GO,1,2
England-FA_Cup,Billericay,Leatherhead,1,3
International-World_Cup_Qualification_Inter_Confederation_Playoff,Peru,New Zealand,2,0
Australia-A_League,Central Coast Mariners,Adelaide United,1,2
Egypt-Premier_League,Tanta,Ismaily SC,0,1
Egypt-Premier_League,Smouha SC,El Raja Marsa Matruh,1,0
Egypt-Premier_League,El Entag El Harby,Al Ahly,1,2
Gibraltar-Premier_Division,Gibraltar Phoenix,Manchester 62 FC,1,1
Portugal-Cup,Sporting CP,Famalicao,2,0
Albania-Kategoria_Superiore,KF Kamza,Kukesi,2,2
Albania-Kategoria_Superiore,Laci,Partizani,1,0
Albania-Kategoria_Superiore,Flamurtari,Skenderbeu,1,1
Algeria-Ligue_1,USM Alger,JS Saoura,0,2
Argentina-Federal_A_Zona_1,Villa Mitre,CA Alvarado,2,1
Argentina-Federal_A_Zona_1,Ferro Carril Oeste General Pico,Sansinena BB,1,0
Argentina-Federal_A_Zona_1,Deportivo Roca,Club Cipolletti,3,1
Argentina-Federal_A_Zona_4,Crucero del Norte,Guarani Antonio Franco,0,0
Argentina-Federal_A_Zona_4,Altos Hornos Zapla,Sportivo Patria,1,0
Argentina-Federal_A_Zona_4,Sarmiento de Resistencia,Gimnasia y Tiro,1,1
Argentina-Federal_A_Zona_4,Juventud Antoniana,Deportivo Mandiyu,2,1
Colombia-Primera_A_Clausura,Atletico Junior,Rionegro Aguilas,2,2
Colombia-Primera_A_Clausura,Deportivo Pasto,Atletico Huila,4,0
Costa_Rica-Primera_Division_Apertura,AD Municipal Liberia,Santos de Guapiles,0,2
Costa_Rica-Liga_de_Ascenso_Apertura_Final_Stage,AS Puma Generalena,AD Cofutpa,0,1
DR_Congo-Super_League_Zone_South_Central,Dibumba,Don Bosco,1,1
Ecuador-Serie_A___Clausura,Emelec,Barcelona SC,3,0
El_Salvador-Primera_Division___Apertura,Santa Tecla FC,CD Chalatenango,2,1
El_Salvador-Primera_Division___Apertura,CD Audaz,CD Aguila,2,2
El_Salvador-Primera_Division___Apertura,CD FAS,Pasaquina,1,1
El_Salvador-Primera_Division___Apertura,Isidro Metapan,CD Sonsonate,3,1
Macedonia-Prva_Liga,Rabotnicki,Pobeda,4,0
Macedonia-Prva_Liga,Renova,FK Vardar Skopje,2,5
Macedonia-Prva_Liga,Pelister,FC Academy Pandev,3,4
Macedonia-Prva_Liga,FK Sileks,KF Shkendija,0,2
France-National,Pau,Entente SSG,2,2
Guatemala-Liga_Nacional_Apertura,CSD Comunicaciones,Coban Imperial,0,0
Brazil-Serie_A,Coritiba,Flamengo,1,0
Brazil-Serie_A,Bahia,Santos FC,3,1
France-Ligue_1,Lille,Saint-Etienne,3,1
France-Ligue_1,Amiens,Monaco,1,1
Germany-1__Bundesliga,VfB Stuttgart,Borussia Dortmund,2,1
Spain-Primera_Division,Girona,Real Sociedad,1,1
Argentina-Superliga,Atletico Tucuman,Arsenal Sarandi,0,0
Argentina-Superliga,Argentinos Juniors,Colon,0,1
Australia-A_League,Brisbane Roar FC,Melbourne City FC,3,1
Belgium-First_Division_A,Sporting Charleroi,KV Mechelen,2,0
Bulgaria-First_Professional_League,Slavia Sofia,Septemvri Sofia,4,1
Croatia-1__Division,Rudes,Slaven,1,2
Czech_Republic-1__Division,Sparta Prague,Vysocina Jihlava,1,0
Denmark-Superligaen,FC Helsingoer,Hobro,0,1
England-Championship,Burton Albion,Sheffield United,1,3
England-Championship,Preston North End,Bolton Wanderers,0,0
Germany-2__Bundesliga,Darmstadt,Sandhausen,1,2
Germany-2__Bundesliga,Arminia Bielefeld,Eintracht Braunschweig,2,2
Italy-Serie_B,Frosinone,Avellino,1,1
Netherlands-Eerste_Divisie,RKC Waalwijk,Telstar,4,1
Netherlands-Eerste_Divisie,FC Den Bosch,FC Volendam,3,1
Netherlands-Eerste_Divisie,FC Emmen,Almere City FC,2,2
Netherlands-Eerste_Divisie,FC Eindhoven,MVV Maastricht,3,2
Netherlands-Eerste_Divisie,De Graafschap,NEC Nijmegen,1,3
Netherlands-Eerste_Divisie,Cambuur,Fortuna Sittard,1,0
Netherlands-Eerste_Divisie,Go Ahead Eagles,FC Dordrecht,0,3
Netherlands-Eerste_Divisie,FC Oss,Helmond Sport,0,0
Poland-Ekstraklasa,Jagiellonia Bialystok,Termalica Nieciecza,0,0
Poland-Ekstraklasa,Wisla Krakow,Pogon Szczecin,1,0
Romania-Liga_I,CSMS Iasi,FC FCSB,1,0
Romania-Liga_I,ACS Poli Timisoara,Botosani,1,1
Slovenia-Prva_Liga,Maribor,Olimpija Ljubljana,1,0
Spain-Segunda_Division,Almeria,Zaragoza,3,0
Turkey-Super_Lig,Besiktas,Akhisar Belediye Genclik Ve Spor,0,0
Ukraine-Premier_League,Shakhtar Donetsk,FC Olexandria,1,2
Belgium-First_Division_B_2nd_Stage,Lierse,Cercle Brugge,1,0
Brazil-Serie_B,Guarani,Luverdense,0,0
International-Club_Friendlies,Tondela,Lusitano FC,0,1
International-Club_Friendlies,AIK,IK Brage,0,0
Egypt-Premier_League,Petrojet,El Geish,2,0
England-Premier_League,Liverpool,Southampton,3,0
England-Premier_League,Crystal Palace,Everton,2,2
England-Premier_League,West Bromwich Albion,Chelsea,0,4
England-Premier_League,AFC Bournemouth,Huddersfield Town,4,0
England-Premier_League,Manchester United,Newcastle United,4,1
England-Premier_League,Leicester City,Manchester City,0,2
England-Premier_League,Arsenal,Tottenham Hotspur,2,0
England-Premier_League,Burnley,Swansea City,2,0
France-Ligue_1,Strasbourg,Rennes,2,1
France-Ligue_1,Dijon,Troyes,3,1
France-Ligue_1,Toulouse,Metz,0,0
France-Ligue_1,Paris Saint Germain,Nantes,4,1
France-Ligue_1,Guingamp,Angers,1,1
Germany-1__Bundesliga,Bayern Munich,Augsburg,3,0
Germany-1__Bundesliga,Mainz 05,FC Cologne,1,0
Germany-1__Bundesliga,Hertha Berlin,Borussia Moenchengladbach,2,4
Germany-1__Bundesliga,Hoffenheim,Eintracht Frankfurt,1,1
Germany-1__Bundesliga,Wolfsburg,Freiburg,3,1
Germany-1__Bundesliga,Bayer Leverkusen,RasenBallsport Leipzig,2,2
Italy-Serie_A,SSC Napoli,AC Milan,2,1
Italy-Serie_A,Roma,Lazio,2,1
Netherlands-Eredivisie,NAC Breda,Ajax,0,8
Netherlands-Eredivisie,Feyenoord,VVV-Venlo,1,1
Netherlands-Eredivisie,Willem II,Sparta Rotterdam,2,2
Netherlands-Eredivisie,FC Twente,SC Heerenveen,0,4
Russia-Premier_League,FC Krasnodar,Spartak Moscow,1,4
Russia-Premier_League,Dinamo Moscow,FK Akhmat,1,1
Russia-Premier_League,Arsenal Tula,Rubin Kazan,0,0
Russia-Premier_League,SKA-Khabarovsk,CSKA Moscow,2,4
Spain-Primera_Division,Sevilla,Celta Vigo,2,1
Spain-Primera_Division,Getafe,Alaves,4,1
Spain-Primera_Division,Atletico Madrid,Real Madrid,0,0
Spain-Primera_Division,Leganes,Barcelona,0,3
International-AFC_Champions_League_Final_Stage,Al Hilal,Urawa Red Diamonds,1,1
Argentina-Superliga,Banfield,Temperley,0,0
Argentina-Superliga,Newells Old Boys,Belgrano,0,1
Argentina-Superliga,Defensa y Justicia,Lanus,3,0
Argentina-Superliga,San Martin San Juan,San Lorenzo,1,3
Australia-A_League,Sydney FC,Newcastle Jets,2,1
Austria-Bundesliga,Austria Wien,Admira Moedling,2,3
Brazil-Serie_A,Sao Paulo,Botafogo RJ,0,0
Brazil-Serie_A,Atletico GO,Chapecoense AF,1,1
Brazil-Serie_A,Atletico MG,Coritiba,3,0
Brazil-Serie_A,Sport Recife,Bahia,1,0
Brazil-Serie_A,Atletico PR,Vasco da Gama,3,1
Brazil-Serie_A,Flamengo,Corinthians,3,0
Brazil-Serie_A,Vitoria,Cruzeiro,1,1
Brazil-Serie_A,Santos FC,Gremio,1,0
England-Premier_League,Watford,West Ham United,2,0
France-Ligue_1,Bordeaux,Marseille,1,1
France-Ligue_1,Lyon,Montpellier,0,0
France-Ligue_1,Caen,Nice,1,1
Germany-1__Bundesliga,Werder Bremen,Hannover 96,4,0
Germany-1__Bundesliga,Schalke 04,Hamburger SV,2,0
Italy-Serie_A,SPAL 2013,Fiorentina,1,1
Italy-Serie_A,Benevento,Sassuolo,1,2
Italy-Serie_A,Inter,Atalanta,2,0
Italy-Serie_A,Torino,ChievoVerona,1,1
Italy-Serie_A,Crotone,Genoa,0,1
Italy-Serie_A,Sampdoria,Juventus,3,2
Italy-Serie_A,Udinese,Cagliari,0,1
Netherlands-Eredivisie,ADO Den Haag,Heracles,4,1
Netherlands-Eredivisie,Roda JC Kerkrade,AZ Alkmaar,0,1
Netherlands-Eredivisie,FC Groningen,Vitesse,4,2
Netherlands-Eredivisie,PEC Zwolle,PSV Eindhoven,0,1
Netherlands-Eredivisie,FC Utrecht,Excelsior,3,1
Russia-Premier_League,Anzhi Makhachkala,Lokomotiv Moscow,0,1
Russia-Premier_League,FC Ufa,Ural,2,0
Russia-Premier_League,FC Rostov,Amkar,0,0
Russia-Premier_League,Zenit St. Petersburg,Tosno,5,0
Spain-Primera_Division,Malaga,Deportivo La Coruna,3,2
Spain-Primera_Division,Athletic Bilbao,Villarreal,1,1
Spain-Primera_Division,Las Palmas,Levante,0,2
Spain-Primera_Division,Espanyol,Valencia,0,2
Argentina-Superliga,Union,Chacarita Juniors,0,0
Argentina-Superliga,Tigre,Estudiantes,2,0
Argentina-Superliga,Boca Juniors,Racing Club,1,2
Argentina-Superliga,Independiente,River Plate,1,0
Australia-A_League,Perth Glory,Melbourne Victory,0,2
Austria-Bundesliga,Salzburg,Sturm Graz,5,0
Brazil-Serie_A,Fluminense,Ponte Preta,2,0
Brazil-Serie_A,Avai FC,Palmeiras,2,1
England-Premier_League,Brighton &amp; Hove Albion,Stoke City,2,2
France-Ligue_1,Amiens,Lille,3,0
Italy-Serie_A,Hellas Verona,Bologna,2,3
Spain-Primera_Division,Eibar,Real Betis,5,0
Argentina-Superliga,Gimnasia LP,Patronato de Parana,2,0
Argentina-Superliga,Talleres,Rosario Central,0,1
Argentina-Superliga,Olimpo,Godoy Cruz,1,1
Bulgaria-First_Professional_League,Vereya,Etar,2,0
Denmark-Superligaen,AaB,FC Midtjylland,0,1
Germany-2__Bundesliga,Dynamo Dresden,Kaiserslautern,1,2
Greece-Super_League,PAOK Thessaloniki FC,Atromitos,2,1
Italy-Serie_B,Palermo,Cittadella,0,3
Mexico-Liga_MX_Apertura,Santos,CF America,0,1
Netherlands-Eerste_Divisie,Jong PSV,Jong FC Utrecht,2,0
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Jong Ajax,4,2
Poland-Ekstraklasa,Zaglebie Lubin,Korona Kielce,0,0
Romania-Liga_I,FC Voluntari,FC Viitorul Constanta,0,0
Slovenia-Prva_Liga,Rudar Velenje,Gorica,2,0
Turkey-Super_Lig,Karabukspor,Kasimpasa,0,2
Egypt-Premier_League,Ismaily SC,Al Ahly,0,2
France-Ligue_2,Lens,Niort,3,1
Gibraltar-Premier_Division,Gibraltar Phoenix,Lions Gibraltar,1,0
Italy-Serie_C_Grp__A,Pro Piacenza,Pisa,0,3
Turkey-1__Lig,Gaziantepspor,Boluspor,0,3
Albania-Kategoria_Superiore,Kukesi,Partizani,1,2
Albania-Kategoria_Superiore,Luftetari,Laci,1,1
Argentina-Primera_B_Nacional,Instituto,Atletico Rafaela,0,0
Argentina-Primera_B_Nacional,Deportivo Riestra,Los Andes,0,1
Argentina-Federal_A_Zona_1,Deportivo Madryn,Villa Mitre,1,0
Argentina-Federal_A_Zona_1,Club Rivadavia,Ferro Carril Oeste General Pico,4,0
Argentina-Federal_A_Zona_3,Sportivo Belgrano,Central Cordoba de Santiago,0,0
Argentina-Federal_A_Zona_3,Defensores de Belgrano de Villa Ramallo,Sportivo Las Parejas,1,1
Argentina-Federal_A_Zona_4,Guarani Antonio Franco,Deportivo San Jorge Tucuman,2,0
Argentina-Primera_B_Metropolitana,Club Atletico Platense,Comunicaciones,1,1
Argentina-Primera_B_Metropolitana,Acassuso,Deportivo Espanol,0,0
Argentina-Primera_C,Berazategui,El Porvenir,1,1
Argentina-Primera_C,San Martin Burzaco,CA Ferrocarril Midland,1,1
Argentina-Primera_C,Justo Jose de Urquiza,CA Defensores Unidos,1,1
International-Champions_League_Grp__E,Sevilla,Liverpool,3,3
International-Champions_League_Grp__E,Spartak Moscow,Maribor,1,1
International-Champions_League_Grp__F,SSC Napoli,Shakhtar Donetsk,3,0
International-Champions_League_Grp__F,Manchester City,Feyenoord,1,0
International-Champions_League_Grp__G,Monaco,RasenBallsport Leipzig,1,4
International-Champions_League_Grp__G,Besiktas,FC Porto,1,1
International-Champions_League_Grp__H,Borussia Dortmund,Tottenham Hotspur,1,2
International-Champions_League_Grp__H,APOEL Nicosia,Real Madrid,0,6
Argentina-Superliga,Huracan,Velez Sarsfield,1,0
England-Championship,Sheffield United,Fulham,4,5
England-Championship,Brentford,Burton Albion,1,1
England-Championship,Millwall,Hull City,0,0
England-Championship,Aston Villa,Sunderland,2,1
England-Championship,Bristol City,Preston North End,1,2
England-Championship,Nottingham Forest,Norwich City,1,0
England-Championship,Bolton Wanderers,Reading,2,2
England-Championship,Barnsley,Cardiff City,0,1
England-Championship,Derby County,Queens Park Rangers,2,0
N__Ireland-Premiership,Dungannon Swifts,Crusaders,0,4
N__Ireland-Premiership,Coleraine,Ards,4,1
Scotland-FA_Cup,Queen of South,Montrose,2,1
Brazil-Serie_B,Santa Cruz,Juventude,5,2
International-Club_Friendlies,Ajax,Borussia Moenchengladbach,2,1
Denmark-DBU_Pokalen,HIK,Silkeborg,0,3
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Tanta,1,1
England-League_1,Peterborough United,Portsmouth,2,1
England-League_1,Wigan Athletic,Doncaster Rovers,3,0
England-League_1,Bury,Shrewsbury Town,1,0
England-League_1,Oldham Athletic,AFC Wimbledon,0,0
England-League_1,Blackpool,Gillingham,1,1
England-League_1,Plymouth Argyle,Northampton Town,2,0
England-League_1,Charlton Athletic,Rochdale,2,1
England-League_1,Oxford United,Blackburn Rovers,2,4
England-League_1,Bradford City,Scunthorpe United,1,2
England-League_1,Walsall,Fleetwood Town,4,2
England-League_1,Milton Keynes Dons,Southend United,1,1
England-League_2,Newport County,Barnet,1,2
England-League_2,Crawley Town,Exeter City,3,1
England-League_2,Morecambe,Crewe Alexandra,0,1
England-League_2,Chesterfield,Forest Green Rovers,3,2
International-Champions_League_Grp__A,CSKA Moscow,Benfica,2,0
International-Champions_League_Grp__A,Basel,Manchester United,1,0
International-Champions_League_Grp__B,Paris Saint Germain,Celtic,7,1
International-Champions_League_Grp__B,Anderlecht,Bayern Munich,1,2
International-Champions_League_Grp__C,Atletico Madrid,Roma,2,0
International-Champions_League_Grp__C,Qarabag FK,Chelsea,0,4
International-Champions_League_Grp__D,Juventus,Barcelona,0,0
International-Champions_League_Grp__D,Sporting CP,Olympiacos,3,1
Argentina-Superliga,River Plate,Union,2,0
England-Championship,Wolverhampton Wanderers,Leeds United,4,1
England-Championship,Ipswich Town,Sheffield Wednesday,2,2
England-Championship,Middlesbrough,Birmingham City,2,0
USA-Major_League_Soccer_Playoff,Houston Dynamo,Seattle Sounders FC,0,2
USA-Major_League_Soccer_Playoff,Columbus Crew,Toronto FC,0,0
International-Copa_Sudamericana,Libertad,Independiente,1,0
Egypt-Premier_League,Misr El-Maqasa,Petrojet,2,0
Egypt-Premier_League,El Raja Marsa Matruh,Wadi Degla FC,3,3
Gibraltar-Premier_Division,Manchester 62 FC,Europa FC,0,2
Kosovo-Superliga,Drenica,Drita,0,0
Kosovo-Superliga,Liria,KF Flamurtari,2,0
Kosovo-Superliga,Feronikeli,KF Vellaznimi,3,0
Kosovo-Superliga,Besa Peje,Llapi,1,6
Kosovo-Superliga,Gjilani,Trepca 89,0,0
Russia-National_Football_League,Luch Energiya Vladivostok,Tyumen,4,2
Albania-Kategoria_Superiore,Vllaznia,Lushnja,2,1
Argentina-Primera_B_Metropolitana,CA Talleres Remedios de Escalada,Club Atletico Estudiantes,1,0
Argentina-Primera_C,Deportivo Merlo,Ituzaingo,2,1
Costa_Rica-Primera_Division_Apertura,Guadalupe FC,Universidad de Costa Rica,1,1
Costa_Rica-Primera_Division_Apertura,Deportiva Carmelita,Club Sport Herediano,0,1
Croatia-2__Division,NK Dugopolje,Hajduk Split B,2,0
DR_Congo-Super_League_Zone_South_Central,FC Lubumbashi Sport,Ocean Pacifique,4,1
DR_Congo-Super_League_Zone_West,AC Rangers,Renaissance,3,0
England-FA_Trophy_Qualification,Cray Wanderers,Moneyfields FC,4,1
Macedonia-Prva_Liga,FK Skopje,Shkupi,0,0
Georgia-Erovnuli_Liga,Saburtalo,Dinamo Tbilisi,0,0
Georgia-Erovnuli_Liga,Kolkheti-1913 Poti,Chikhura,0,4
Georgia-Erovnuli_Liga,Lokomotivi Tbilisi,Samtredia,2,5
Georgia-Erovnuli_Liga,Torpedo Kutaisi,Dinamo Batumi,2,0
Georgia-Erovnuli_Liga,Dila Gori,FC Shukura Kobuleti,0,1
Germany-Regionalliga_North,Hannover 96 II,FC Hansa Lueneburg,3,0
International-Copa_Libertadores_Final_Stage,Gremio,Lanus,1,0
International-Europa_League_Grp__A,FC Astana,Villarreal,2,3
International-Europa_League_Grp__A,Maccabi Tel Aviv,Slavia Prague,0,2
International-Europa_League_Grp__B,Partizan Beograd,Young Boys,2,1
International-Europa_League_Grp__B,Skenderbeu,Dynamo Kyiv,3,2
International-Europa_League_Grp__C,Ludogorets Razgrad,Istanbul Basaksehir,1,2
International-Europa_League_Grp__C,Braga,Hoffenheim,3,1
International-Europa_League_Grp__D,AC Milan,Austria Wien,5,1
International-Europa_League_Grp__D,AEK Athens,Rijeka,2,2
International-Europa_League_Grp__E,Everton,Atalanta,1,5
International-Europa_League_Grp__E,Lyon,Apollon Limassol,4,0
International-Europa_League_Grp__F,FC Sheriff,Zlin,1,0
International-Europa_League_Grp__F,Lokomotiv Moscow,FC Koebenhavn,2,1
International-Europa_League_Grp__G,Viktoria Plzen,FC FCSB,2,0
International-Europa_League_Grp__G,Lugano,Hapoel Beer Sheva,1,0
International-Europa_League_Grp__H,FC Cologne,Arsenal,1,0
International-Europa_League_Grp__H,BATE Borisov,FK Crvena Zvezda,0,0
International-Europa_League_Grp__I,Konyaspor,Marseille,1,1
International-Europa_League_Grp__I,Salzburg,Vitoria de Guimaraes,3,0
International-Europa_League_Grp__J,Oestersunds FK,Zorya,2,0
International-Europa_League_Grp__J,Athletic Bilbao,Hertha Berlin,3,2
International-Europa_League_Grp__K,Lazio,Vitesse,1,1
International-Europa_League_Grp__K,Nice,Zulte-Waregem,3,1
International-Europa_League_Grp__L,Rosenborg,Real Sociedad,0,1
International-Europa_League_Grp__L,Zenit St. Petersburg,FK Vardar Skopje,2,1
Argentina-Superliga,Velez Sarsfield,Godoy Cruz,0,1
Australia-A_League,Newcastle Jets,Melbourne Victory,4,1
International-Friendlies,Vanuatu,Estonia,0,1
Mexico-Liga_MX_Apertura_Playoff,Leon,Tigres,1,1
Mexico-Liga_MX_Apertura_Playoff,Toluca,Monarcas Morelia,2,1
Egypt-Premier_League,Alassiouty,Al Masry,1,2
Egypt-Premier_League,Al Mokawloon Al Arab,ENPPI,2,2
Egypt-Premier_League,Al Nasr,El Entag El Harby,0,1
Gibraltar-Premier_Division,St Joseph's,Lynx,2,1
Kosovo-Superliga,KF Vllaznia Pozheran,FC Prishtina,0,2
Argentina-Federal_A_Zona_3,Douglas Haig,Defensores de Pronunciamiento,1,1
Armenia-1__Division,Banants II,Artsakh,0,3
Armenia-1__Division,Lori,Avan Academy,4,1
Colombia-Primera_B_Clausura_Final_Stage,Llaneros FC,Leones,1,4
Costa_Rica-Primera_Division_Apertura,Municipal Perez Zeledon,AD Municipal Liberia,4,0
England-Premier_League,West Ham United,Leicester City,1,1
France-Ligue_1,Saint-Etienne,Strasbourg,2,2
Germany-1__Bundesliga,Hannover 96,VfB Stuttgart,1,1
Netherlands-Eredivisie,AZ Alkmaar,FC Twente,2,0
Portugal-Primeira_Liga,Belenenses,Chaves,0,1
Russia-Premier_League,Amkar,Dinamo Moscow,2,1
Spain-Primera_Division,Celta Vigo,Leganes,1,0
Argentina-Superliga,Banfield,Defensa y Justicia,0,1
Argentina-Superliga,Chacarita Juniors,Huracan,0,2
Australia-A_League,Melbourne City FC,Perth Glory,1,3
Belgium-First_Division_A,Gent,Royal Excel Mouscron,3,1
Bulgaria-First_Professional_League,Cherno More Varna,Pirin Blagoevgrad,0,1
Croatia-1__Division,Inter Zapresic,NK Lokomotiva,1,1
Czech_Republic-1__Division,Vysocina Jihlava,FC Zbrojovka Brno,0,2
Czech_Republic-1__Division,Bohemians 1905,Slovan Liberec,0,0
Czech_Republic-1__Division,Dukla Praha,Mlada Boleslav,4,1
Denmark-Superligaen,Randers FC,SoenderjyskE,0,2
Germany-2__Bundesliga,Union Berlin,Darmstadt,3,3
Germany-2__Bundesliga,Sandhausen,FC Heidenheim,1,2
Italy-Serie_B,Empoli,Frosinone,3,3
Mexico-Liga_MX_Apertura_Playoff,Cruz Azul,CF America,0,0
Mexico-Liga_MX_Apertura_Playoff,Atlas,Monterrey,1,2
Netherlands-Eerste_Divisie,RKC Waalwijk,FC Oss,2,1
Netherlands-Eerste_Divisie,Fortuna Sittard,Go Ahead Eagles,2,1
Netherlands-Eerste_Divisie,FC Volendam,FC Emmen,2,3
Netherlands-Eerste_Divisie,Jong PSV,Telstar,6,0
Netherlands-Eerste_Divisie,Cambuur,FC Den Bosch,2,2
Netherlands-Eerste_Divisie,De Graafschap,FC Eindhoven,4,0
Netherlands-Eerste_Divisie,FC Dordrecht,Jong AZ Alkmaar,3,2
Netherlands-Eerste_Divisie,MVV Maastricht,Helmond Sport,3,1
Netherlands-Eerste_Divisie,Jong FC Utrecht,Almere City FC,2,4
Netherlands-Eerste_Divisie,NEC Nijmegen,Jong Ajax,2,1
N__Ireland-Premiership,Glenavon,Linfield,0,1
Poland-Ekstraklasa,Cracovia,Lechia Gdansk,2,1
Poland-Ekstraklasa,Gornik Zabrze,Jagiellonia Bialystok,3,1
Romania-Liga_I,Juventus Bucuresti,Concordia Chiajna,0,5
Romania-Liga_I,Botosani,CS Universitatea Craiova,1,0
Scotland-Premiership,Dundee FC,Rangers,2,1
Spain-Segunda_Division,Tenerife,Rayo Vallecano,2,2
Turkey-Super_Lig,Osmanlispor FK,Genclerbirligi,2,0
Brazil-Serie_A,Fluminense,Sport Recife,1,2
England-Premier_League,Newcastle United,Watford,0,3
England-Premier_League,Crystal Palace,Stoke City,2,1
England-Premier_League,Swansea City,AFC Bournemouth,0,0
England-Premier_League,Liverpool,Chelsea,1,1
England-Premier_League,Manchester United,Brighton &amp; Hove Albion,1,0
England-Premier_League,Tottenham Hotspur,West Bromwich Albion,1,1
France-Ligue_1,Metz,Amiens,0,2
France-Ligue_1,Caen,Bordeaux,1,0
France-Ligue_1,Rennes,Nantes,2,1
France-Ligue_1,Montpellier,Lille,3,0
France-Ligue_1,Dijon,Toulouse,3,1
France-Ligue_1,Troyes,Angers,3,0
Germany-1__Bundesliga,RasenBallsport Leipzig,Werder Bremen,2,0
Germany-1__Bundesliga,Augsburg,Wolfsburg,2,1
Germany-1__Bundesliga,Freiburg,Mainz 05,2,1
Germany-1__Bundesliga,Borussia Dortmund,Schalke 04,4,4
Germany-1__Bundesliga,Borussia Moenchengladbach,Bayern Munich,2,1
Germany-1__Bundesliga,Eintracht Frankfurt,Bayer Leverkusen,0,1
Italy-Serie_A,Cagliari,Inter,1,3
Italy-Serie_A,ChievoVerona,SPAL 2013,2,1
Italy-Serie_A,Sassuolo,Hellas Verona,0,2
Italy-Serie_A,Bologna,Sampdoria,3,0
Netherlands-Eredivisie,FC Groningen,Feyenoord,0,2
Netherlands-Eredivisie,VVV-Venlo,Willem II,3,3
Netherlands-Eredivisie,SC Heerenveen,PEC Zwolle,1,2
Netherlands-Eredivisie,Heracles,NAC Breda,2,1
Portugal-Primeira_Liga,Portimonense,Tondela,2,0
Portugal-Primeira_Liga,Aves,FC Porto,1,1
Portugal-Primeira_Liga,Boavista,Moreirense,1,0
Russia-Premier_League,Tosno,Arsenal Tula,3,2
Russia-Premier_League,FK Akhmat,FC Ufa,2,1
Spain-Primera_Division,Levante,Atletico Madrid,0,5
Spain-Primera_Division,Alaves,Eibar,1,2
Spain-Primera_Division,Real Madrid,Malaga,3,2
Spain-Primera_Division,Real Betis,Girona,2,2
International-AFC_Champions_League_Final_Stage,Urawa Red Diamonds,Al Hilal,1,0
Argentina-Superliga,Colon,Tigre,3,1
Argentina-Superliga,Belgrano,Gimnasia LP,2,0
Argentina-Superliga,Patronato de Parana,Union,2,3
Brazil-Serie_A,Bahia,Chapecoense AF,0,1
Brazil-Serie_A,Avai FC,Atletico PR,1,0
Brazil-Serie_A,Corinthians,Atletico MG,2,2
Brazil-Serie_A,Flamengo,Santos FC,1,2
Brazil-Serie_A,Gremio,Atletico GO,1,1
Brazil-Serie_A,Cruzeiro,Vasco da Gama,0,1
Brazil-Serie_A,Ponte Preta,Vitoria,2,3
Brazil-Serie_A,Coritiba,Sao Paulo,1,2
England-Premier_League,Southampton,Everton,4,1
England-Premier_League,Burnley,Arsenal,0,1
England-Premier_League,Huddersfield Town,Manchester City,1,2
France-Ligue_1,Nice,Lyon,0,5
France-Ligue_1,Marseille,Guingamp,1,0
France-Ligue_1,Monaco,Paris Saint Germain,1,2
Germany-1__Bundesliga,FC Cologne,Hertha Berlin,0,2
Germany-1__Bundesliga,Hamburger SV,Hoffenheim,3,0
Italy-Serie_A,Genoa,Roma,1,1
Italy-Serie_A,Lazio,Fiorentina,1,1
Italy-Serie_A,AC Milan,Torino,0,0
Italy-Serie_A,Juventus,Crotone,3,0
Italy-Serie_A,Udinese,SSC Napoli,0,1
Netherlands-Eredivisie,Ajax,Roda JC Kerkrade,5,1
Netherlands-Eredivisie,Vitesse,ADO Den Haag,2,0
Netherlands-Eredivisie,Excelsior,PSV Eindhoven,1,2
Netherlands-Eredivisie,Sparta Rotterdam,FC Utrecht,1,3
Portugal-Primeira_Liga,Benfica,Vitoria de Setubal,6,0
Portugal-Primeira_Liga,Pacos de Ferreira,Sporting CP,1,2
Portugal-Primeira_Liga,Maritimo,Estoril,0,0
Russia-Premier_League,Rubin Kazan,CSKA Moscow,0,1
Russia-Premier_League,FC Rostov,Anzhi Makhachkala,2,0
Russia-Premier_League,Ural,FC Krasnodar,0,1
Spain-Primera_Division,Villarreal,Sevilla,2,3
Spain-Primera_Division,Deportivo La Coruna,Athletic Bilbao,2,2
Spain-Primera_Division,Valencia,Barcelona,1,1
Spain-Primera_Division,Real Sociedad,Las Palmas,2,2
Argentina-Superliga,Racing Club,Independiente,0,1
Argentina-Superliga,River Plate,Newells Old Boys,1,3
Argentina-Superliga,Estudiantes,Atletico Tucuman,1,0
Australia-A_League,Adelaide United,Western Sydney Wanderers FC,2,0
Austria-Bundesliga,Wolfsberger AC,Austria Wien,1,2
Brazil-Serie_A,Palmeiras,Botafogo RJ,2,0
Italy-Serie_A,Atalanta,Benevento,1,0
Portugal-Primeira_Liga,Rio Ave,Vitoria de Guimaraes,0,1
Portugal-Primeira_Liga,Braga,Feirense,3,1
Russia-Premier_League,SKA-Khabarovsk,Lokomotiv Moscow,1,2
Russia-Premier_League,Spartak Moscow,Zenit St. Petersburg,3,1
Spain-Primera_Division,Espanyol,Getafe,1,0
Argentina-Superliga,Rosario Central,Boca Juniors,1,0
Argentina-Superliga,Velez Sarsfield,Olimpo,3,0
Argentina-Superliga,Arsenal Sarandi,Talleres,0,1
Bulgaria-First_Professional_League,Ludogorets Razgrad,Vitosha Bistritsa,3,0
Czech_Republic-1__Division,Zlin,Slovacko,2,1
Czech_Republic-1__Division,Jablonec,Slavia Prague,1,1
Denmark-Superligaen,FC Midtjylland,AGF,4,0
England-Championship,Queens Park Rangers,Brentford,2,2
Germany-2__Bundesliga,Fortuna Duesseldorf,Dynamo Dresden,1,3
Greece-Super_League,AEK Athens,Platanias,3,0
Israel-Ligat_HaAl,Beitar Jerusalem,Hapoel Beer Sheva,2,2
Italy-Serie_B,Cesena,Brescia,1,0
Mexico-Liga_MX_Apertura_Playoff,CF America,Cruz Azul,0,0
Mexico-Liga_MX_Apertura_Playoff,Monterrey,Atlas,4,1
Netherlands-Eerste_Divisie,Telstar,NEC Nijmegen,3,2
Netherlands-Eerste_Divisie,Go Ahead Eagles,Jong FC Utrecht,0,0
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,FC Volendam,0,2
Netherlands-Eerste_Divisie,FC Oss,Jong PSV,0,3
Netherlands-Eerste_Divisie,Helmond Sport,Fortuna Sittard,1,3
Netherlands-Eerste_Divisie,FC Den Bosch,De Graafschap,1,1
Netherlands-Eerste_Divisie,Almere City FC,RKC Waalwijk,3,2
Netherlands-Eerste_Divisie,FC Eindhoven,Cambuur,2,1
Netherlands-Eerste_Divisie,FC Emmen,MVV Maastricht,2,1
Netherlands-Eerste_Divisie,Jong Ajax,FC Dordrecht,3,0
Poland-Ekstraklasa,Termalica Nieciecza,Wisla Krakow,3,3
Romania-Liga_I,CFR Cluj,Sepsi OSK,2,0
Turkey-Super_Lig,Kayserispor,Istanbul Basaksehir,1,1
Egypt-Premier_League,El Geish,Al Nasr,1,3
Egypt-Premier_League,Petrojet,El Raja Marsa Matruh,0,1
Egypt-Premier_League,El Zamalek,Misr El-Maqasa,1,3
France-Ligue_2,Reims,Auxerre,2,0
Italy-Serie_C_Grp__B,Teramo,Sambenedettese,0,2
Kosovo-Superliga,FC Prishtina,Gjilani,2,1
England-Premier_League,Brighton &amp; Hove Albion,Crystal Palace,0,0
England-Premier_League,Watford,Manchester United,2,4
England-Premier_League,Leicester City,Tottenham Hotspur,2,1
England-Premier_League,West Bromwich Albion,Newcastle United,2,2
France-Ligue_1,Amiens,Dijon,2,1
France-Ligue_1,Bordeaux,Saint-Etienne,3,0
France-Ligue_1,Strasbourg,Caen,0,0
Argentina-Superliga,Temperley,San Martin San Juan,1,0
Austria-Bundesliga,Sturm Graz,Admira Moedling,6,1
Bulgaria-First_Professional_League,Botev Plovdiv,Beroe,1,1
Bulgaria-First_Professional_League,Slavia Sofia,Cherno More Varna,2,0
England-Championship,Derby County,Ipswich Town,0,1
England-Championship,Reading,Barnsley,3,0
Italy-Coppa_Italia,Cagliari,Pordenone Calcio,1,2
Italy-Coppa_Italia,SPAL 2013,Cittadella,0,2
Italy-Coppa_Italia,Sampdoria,Pescara,4,1
Slovakia-Super_Liga,Zemplin Michalovce,Trencin,1,1
Spain-Copa_del_Rey,Celta Vigo,Eibar,1,0
Spain-Copa_del_Rey,Real Madrid,Fuenlabrada,2,2
Spain-Copa_del_Rey,Malaga,Numancia,1,1
Spain-Copa_del_Rey,Levante,Girona,1,1
Spain-Copa_del_Rey,Leganes,Valladolid,1,0
Turkey-Cup,Karsspor,Genclerbirligi,1,2
Turkey-Cup,Ankara Demirspor,Akhisar Belediye Genclik Ve Spor,0,3
Turkey-Cup,Besiktas,Manisaspor,9,0
Turkey-Cup,Osmanlispor FK,Yeni Malatyaspor,3,1
Turkey-Cup,Galatasaray,Sivas Belediye Spor,5,1
Belgium-Cup,Royal Excel Mouscron,Sporting Charleroi,0,1
Belgium-Cup,Oostende,St.Truiden,2,0
Denmark-DBU_Pokalen,Jammerbugt FC,SoenderjyskE,1,4
Egypt-Premier_League,Al Masry,Al Ahly,0,2
Egypt-Premier_League,Tanta,Al Mokawloon Al Arab,0,1
Egypt-Premier_League,ENPPI,Alassiouty,0,0
England-League_1,Blackpool,Blackburn Rovers,2,4
England-League_1,Charlton Athletic,Peterborough United,2,2
England-EFL_Trophy_Final_Stage,Rochdale,Doncaster Rovers,6,5
England-EFL_Trophy_Southern_Grp__C,Wycombe Wanderers,West Ham United Academy,2,0
England-EFL_Trophy_Southern_Grp__D,Yeovil Town,Plymouth Argyle,2,1
England-EFL_Trophy_Southern_Grp__D,Exeter City,Chelsea Academy,1,3
England-EFL_Trophy_Southern_Grp__F,Barnet,Tottenham Academy,2,1
England-Premier_League,Everton,West Ham United,4,0
England-Premier_League,Chelsea,Swansea City,1,0
England-Premier_League,Manchester City,Southampton,2,1
England-Premier_League,Arsenal,Huddersfield Town,5,0
England-Premier_League,Stoke City,Liverpool,0,3
England-Premier_League,AFC Bournemouth,Burnley,1,2
France-Ligue_1,Paris Saint Germain,Troyes,2,0
France-Ligue_1,Lyon,Lille,1,2
France-Ligue_1,Toulouse,Nice,1,2
France-Ligue_1,Angers,Rennes,1,2
France-Ligue_1,Metz,Marseille,0,3
France-Ligue_1,Guingamp,Montpellier,0,0
France-Ligue_1,Nantes,Monaco,1,0
Austria-Bundesliga,Salzburg,Mattersburg,2,0
Austria-Bundesliga,SKN St. Poelten,Austria Wien,1,0
Austria-Bundesliga,LASK,Wolfsberger AC,2,0
Austria-Bundesliga,Rapid Wien,Altach,1,2
Bulgaria-First_Professional_League,Dunav Ruse,Levski Sofia,0,4
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Etar,3,2
Italy-Coppa_Italia,Sassuolo,Bari,2,1
Italy-Coppa_Italia,Torino,Carpi,2,0
Italy-Coppa_Italia,ChievoVerona,Hellas Verona,5,6
Scotland-Premiership,Motherwell,Celtic,1,1
Scotland-Premiership,Rangers,Aberdeen,3,0
Spain-Copa_del_Rey,Atletico Madrid,Elche,3,0
Spain-Copa_del_Rey,Barcelona,Real Murcia,5,0
Spain-Copa_del_Rey,Athletic Bilbao,SD Formentera,0,1
Spain-Copa_del_Rey,Real Sociedad,Lleida Esportiu,2,3
Spain-Copa_del_Rey,Sevilla,Cartagena,4,0
Spain-Copa_del_Rey,Las Palmas,Deportivo La Coruna,2,3
Turkey-Cup,Fenerbahce,Adana Demirspor,6,0
Turkey-Cup,Batman Petrolspor,Konyaspor,0,3
Turkey-Cup,Karabukspor,Istanbulspor,2,1
Turkey-Cup,Kasimpasa,Boluspor,1,3
Turkey-Cup,Adanaspor,Bursaspor,0,2
Turkey-Cup,Sivasspor,Bucaspor,2,1
Belgium-Cup,Anderlecht,Standard Liege,0,1
Belgium-Cup,KV Mechelen,Genk,5,6
Belgium-Cup,Gent,Lokeren,2,1
Belgium-Cup,Waasland-Beveren,Eupen,2,0
International-Copa_Libertadores_Final_Stage,Lanus,Gremio,1,2
Argentina-Superliga,San Lorenzo,Atletico Tucuman,2,0
Bulgaria-First_Professional_League,Vereya,Ludogorets Razgrad,2,1
Bulgaria-First_Professional_League,Vitosha Bistritsa,Lokomotiv Plovdiv,1,1
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Septemvri Sofia,2,0
Italy-Coppa_Italia,Udinese,Perugia,8,3
Italy-Coppa_Italia,Genoa,Crotone,1,0
Mexico-Liga_MX_Apertura_Playoff,CF America,Tigres,0,1
Spain-Copa_del_Rey,Valencia,Zaragoza,4,1
Spain-Copa_del_Rey,Villarreal,Ponferradina,3,0
Spain-Copa_del_Rey,Real Betis,Cadiz,3,5
Spain-Copa_del_Rey,Alaves,Getafe,3,0
Spain-Copa_del_Rey,Espanyol,Tenerife,3,2
Turkey-Cup,Erzurum BB,Trabzonspor,0,4
Turkey-Cup,Orhangazispor,Antalyaspor,0,3
Turkey-Cup,Kayserispor,Eyupspor,3,2
Turkey-Cup,Kahramanmarasspor,Istanbul Basaksehir,1,3
Turkey-Cup,Giresunspor,Alanyaspor,4,2
USA-Major_League_Soccer_Playoff,Toronto FC,Columbus Crew,1,0
Belgium-Cup,Zulte-Waregem,Club Brugge,2,3
Gibraltar-Premier_Division,Europa FC,Mons Calpe SC,3,0
Greece-Cup_Grp__2,Apollon Pontou,Levadiakos,1,2
Greece-Cup_Grp__3,Kallithea,AEK Athens,2,3
Greece-Cup_Grp__6,Ergotelis,Panetolikos,0,5
Greece-Cup_Grp__7,Panegialios,Panionios,1,0
Switzerland-Cup,Lugano,Grasshopper,1,3
Switzerland-Cup,Young Boys,St. Gallen,2,1
Argentina-Federal_A_Zona_2,Desamparados,Gutierrez SC,0,1
Argentina-Federal_A_Zona_3,Union de Sunchales,Douglas Haig,2,0
Argentina-Federal_A_Zona_3,Atletico Parana,Sportivo Las Parejas,1,0
Argentina-Federal_A_Zona_3,Sportivo Belgrano,CD Libertad,3,0
Argentina-Federal_A_Zona_3,Defensores de Belgrano de Villa Ramallo,Central Cordoba de Santiago,0,0
Argentina-Federal_A_Zona_3,Gimnasia y Esgrima de Concepcion,Defensores de Pronunciamiento,3,0
Argentina-Federal_A_Zona_4,Guarani Antonio Franco,Deportivo Mandiyu,4,1
Armenia-1__Division,Avan Academy,Shirak II,6,0
Bahrain-Premier_League,Manama,Malkia,2,2
Bahrain-Premier_League,Al-Riffa,Muharraq,0,1
Bolivia-Primera_Division___Clausura_Adecuacion,Nacional Potosi,Guabira,2,1
Bolivia-Primera_Division___Clausura_Adecuacion,Jorge Wilstermann,Sport Boys Warnes,3,1
Botswana-Premier_League,Security Systems,Extension Gunners,1,1
England-FA_Cup,AFC Fylde,Wigan Athletic,1,1
France-Ligue_1,Dijon,Bordeaux,3,2
Germany-1__Bundesliga,Freiburg,Hamburger SV,0,0
Italy-Serie_A,Roma,SPAL 2013,3,1
Italy-Serie_A,SSC Napoli,Juventus,0,1
Netherlands-Eredivisie,PEC Zwolle,FC Utrecht,1,1
Portugal-Primeira_Liga,FC Porto,Benfica,0,0
Portugal-Primeira_Liga,Sporting CP,Belenenses,1,0
Russia-Premier_League,CSKA Moscow,Tosno,6,0
Russia-Premier_League,Arsenal Tula,Spartak Moscow,0,1
Spain-Primera_Division,Malaga,Levante,0,0
Argentina-Superliga,Union,Belgrano,1,1
Argentina-Superliga,Defensa y Justicia,Godoy Cruz,3,2
Australia-A_League,Adelaide United,Sydney FC,0,1
Belgium-First_Division_A,Sporting Charleroi,Oostende,1,1
Czech_Republic-1__Division,Slavia Prague,Banik Ostrava,2,1
Denmark-Superligaen,AGF,FC Helsingoer,0,0
England-Championship,Cardiff City,Norwich City,3,1
England-Championship,Leeds United,Aston Villa,1,1
France-Coupe_de_France,Les Herbiers,Romorantin,2,1
France-Coupe_de_France,ASC Biesheim,Lyon la Duchere,1,0
International-Friendlies,Laos,Philippines,1,3
International-Friendlies,Fiji,Tuvalu,8,0
Germany-2__Bundesliga,FC Heidenheim,Kaiserslautern,3,2
Germany-2__Bundesliga,Arminia Bielefeld,St. Pauli,5,0
Mexico-Liga_MX_Apertura_Playoff,Monarcas Morelia,Monterrey,0,1
Netherlands-Eerste_Divisie,Cambuur,Telstar,2,1
Netherlands-Eerste_Divisie,MVV Maastricht,Jong Ajax,0,4
Netherlands-Eerste_Divisie,De Graafschap,Jong AZ Alkmaar,1,0
Netherlands-Eerste_Divisie,FC Volendam,Almere City FC,1,1
Netherlands-Eerste_Divisie,FC Eindhoven,FC Oss,1,3
Netherlands-Eerste_Divisie,NEC Nijmegen,FC Dordrecht,6,0
Netherlands-Eerste_Divisie,RKC Waalwijk,Helmond Sport,1,0
Netherlands-Eerste_Divisie,FC Den Bosch,Go Ahead Eagles,3,0
Poland-Ekstraklasa,Jagiellonia Bialystok,Pogon Szczecin,1,0
Poland-Ekstraklasa,Lechia Gdansk,Slask Wroclaw,3,1
Romania-Liga_I,FC Voluntari,CFR Cluj,0,3
USA-Major_League_Soccer_Playoff,Seattle Sounders FC,Houston Dynamo,3,0
Belgium-First_Division_B_2nd_Stage,KFCO Beerschot-Wilrijk,Roeselare,1,0
International-Copa_Sudamericana,Atletico Junior,Flamengo,0,2
England-Premier_League,Everton,Huddersfield Town,2,0
England-Premier_League,Watford,Tottenham Hotspur,1,1
England-Premier_League,Leicester City,Burnley,1,0
England-Premier_League,West Bromwich Albion,Crystal Palace,0,0
England-Premier_League,Arsenal,Manchester United,1,3
England-Premier_League,Chelsea,Newcastle United,3,1
England-Premier_League,Brighton &amp; Hove Albion,Liverpool,1,5
England-Premier_League,Stoke City,Swansea City,2,1
England-FA_Cup,Notts County,Oxford City,3,2
England-FA_Cup,Fleetwood Town,Hereford,1,1
England-FA_Cup,Shrewsbury Town,Morecambe,2,0
England-FA_Cup,Gillingham,Carlisle United,1,1
England-FA_Cup,Milton Keynes Dons,Maidstone,4,1
England-FA_Cup,Stevenage,Swindon Town,5,2
England-FA_Cup,Forest Green Rovers,Exeter City,3,3
England-FA_Cup,Port Vale,Yeovil Town,1,1
England-FA_Cup,Bradford City,Plymouth Argyle,3,1
France-Ligue_1,Rennes,Amiens,2,0
France-Ligue_1,Monaco,Angers,1,0
France-Ligue_1,Troyes,Guingamp,0,1
France-Ligue_1,Strasbourg,Paris Saint Germain,2,1
France-Ligue_1,Nice,Metz,3,1
France-Ligue_1,Lille,Toulouse,1,0
Germany-1__Bundesliga,Bayer Leverkusen,Borussia Dortmund,1,1
Germany-1__Bundesliga,Hoffenheim,RasenBallsport Leipzig,4,0
Germany-1__Bundesliga,Mainz 05,Augsburg,1,3
Germany-1__Bundesliga,Schalke 04,FC Cologne,2,2
Germany-1__Bundesliga,Werder Bremen,VfB Stuttgart,1,0
Germany-1__Bundesliga,Bayern Munich,Hannover 96,3,1
Italy-Serie_A,Torino,Atalanta,1,1
Netherlands-Eredivisie,Feyenoord,Vitesse,1,0
Netherlands-Eredivisie,FC Twente,Ajax,3,3
Netherlands-Eredivisie,Willem II,Heracles,3,1
Netherlands-Eredivisie,ADO Den Haag,FC Groningen,0,3
Portugal-Primeira_Liga,Tondela,Rio Ave,1,3
Portugal-Primeira_Liga,Moreirense,Maritimo,1,1
Portugal-Primeira_Liga,Chaves,Boavista,0,0
Russia-Premier_League,Zenit St. Petersburg,Ural,2,1
Russia-Premier_League,Lokomotiv Moscow,Rubin Kazan,1,0
Russia-Premier_League,Dinamo Moscow,FC Rostov,2,0
Brazil-Serie_A,Sport Recife,Corinthians,1,0
Brazil-Serie_A,Atletico MG,Gremio,4,3
Brazil-Serie_A,Atletico GO,Fluminense,1,1
Brazil-Serie_A,Santos FC,Avai FC,1,1
Brazil-Serie_A,Atletico PR,Palmeiras,3,0
Brazil-Serie_A,Botafogo RJ,Cruzeiro,2,2
Brazil-Serie_A,Chapecoense AF,Coritiba,2,1
Brazil-Serie_A,Sao Paulo,Bahia,1,1
Brazil-Serie_A,Vitoria,Flamengo,1,2
Brazil-Serie_A,Vasco da Gama,Ponte Preta,2,1
England-Premier_League,Manchester City,West Ham United,2,1
England-Premier_League,AFC Bournemouth,Southampton,1,1
England-FA_Cup,Doncaster Rovers,Scunthorpe United,3,0
England-FA_Cup,Gateshead FC,Luton Town,0,5
England-FA_Cup,Woking,Peterborough United,1,1
England-FA_Cup,Newport County,Cambridge United,2,0
England-FA_Cup,Mansfield Town,Guiseley,3,0
England-FA_Cup,Blackburn Rovers,Crewe Alexandra,3,3
England-FA_Cup,Wycombe Wanderers,Leatherhead,3,1
England-FA_Cup,AFC Wimbledon,Charlton Athletic,3,1
England-FA_Cup,Coventry City,Boreham Wood,3,0
France-Ligue_1,Saint-Etienne,Nantes,1,1
France-Ligue_1,Montpellier,Marseille,1,1
France-Ligue_1,Caen,Lyon,1,2
Germany-1__Bundesliga,Hertha Berlin,Eintracht Frankfurt,1,2
Germany-1__Bundesliga,Wolfsburg,Borussia Moenchengladbach,3,0
Italy-Serie_A,Inter,ChievoVerona,5,0
Italy-Serie_A,Sampdoria,Lazio,1,2
Italy-Serie_A,Bologna,Cagliari,1,1
Italy-Serie_A,Benevento,AC Milan,2,2
Italy-Serie_A,Fiorentina,Sassuolo,3,0
Netherlands-Eredivisie,NAC Breda,Excelsior,3,1
Netherlands-Eredivisie,PSV Eindhoven,Sparta Rotterdam,1,0
Netherlands-Eredivisie,VVV-Venlo,AZ Alkmaar,0,2
Netherlands-Eredivisie,Roda JC Kerkrade,SC Heerenveen,2,1
Portugal-Primeira_Liga,Feirense,Aves,0,1
Portugal-Primeira_Liga,Braga,Pacos de Ferreira,3,0
Portugal-Primeira_Liga,Vitoria de Setubal,Vitoria de Guimaraes,1,2
Russia-Premier_League,FC Ufa,Amkar,3,0
Russia-Premier_League,FC Krasnodar,FK Akhmat,3,2
England-FA_Cup,Slough Town,Rochdale,0,4
Italy-Serie_A,Hellas Verona,Genoa,0,1
Italy-Serie_A,Crotone,Udinese,0,3
Portugal-Primeira_Liga,Estoril,Portimonense,0,0
Spain-Primera_Division,Girona,Alaves,2,3
Argentina-Superliga,Atletico Tucuman,Colon,2,0
Argentina-Superliga,Lanus,Velez Sarsfield,0,0
Argentina-Superliga,Gimnasia LP,River Plate,2,1
Bulgaria-First_Professional_League,Ludogorets Razgrad,Dunav Ruse,2,0
Croatia-1__Division,NK Istra 1961,Rudes,2,1
Denmark-Superligaen,FC Midtjylland,OB,3,1
England-Championship,Birmingham City,Wolverhampton Wanderers,0,1
International-Friendlies,Brunei,Kyrgyzstan,0,4
International-Friendlies,Mongolia,Indonesia,2,3
International-Friendlies,Chinese Taipei,Timor-Leste,3,1
Germany-2__Bundesliga,Ingolstadt,Eintracht Braunschweig,0,2
Greece-Super_League,Platanias,Atromitos,1,3
Israel-Ligat_HaAl,Hapoel Haifa,Maccabi Haifa,1,0
Italy-Serie_B,Perugia,Ascoli Picchio FC 1898,1,0
Mexico-Liga_MX_Apertura_Playoff,Monterrey,Monarcas Morelia,4,0
Netherlands-Eerste_Divisie,Jong PSV,Fortuna Sittard,2,3
Netherlands-Eerste_Divisie,Jong FC Utrecht,FC Emmen,1,2
Poland-Ekstraklasa,Cracovia,Korona Kielce,2,2
Romania-Liga_I,Sepsi OSK,Dinamo Bucuresti,0,3
Romania-Liga_I,ACS Poli Timisoara,Gaz Metan Medias,1,1
Turkey-Super_Lig,Trabzonspor,Antalyaspor,3,0
Turkey-Super_Lig,Alanyaspor,Kayserispor,1,2
Egypt-Premier_League,Al Nasr,El Dakhleya,0,0
Egypt-Premier_League,El Entag El Harby,Al Masry,1,1
Egypt-Premier_League,Misr El-Maqasa,El Geish,4,0
Italy-Serie_C_Grp__B,Calcio Padova,Fermana,0,0
Serbia-Super_Liga,Cukaricki,FK Zemun,4,1
Serbia-Super_Liga,Rad Beograd,Radnicki Nis,2,3
Serbia-Super_Liga,Borac Cacak,Napredak,3,3
Turkey-1__Lig,Erzurum BB,Manisaspor,1,1
Albania-Kategoria_Superiore,Luftetari,Flamurtari,1,1
Argentina-Federal_A_Zona_2,Deportivo Maipu,Estudiantes de Rio Cuarto,2,1
Argentina-Federal_A_Zona_3,Sportivo Las Parejas,Union de Sunchales,2,2
Argentina-Federal_A_Zona_3,Douglas Haig,Sportivo Belgrano,4,1
Argentina-Primera_B_Metropolitana,Deportivo Espanol,Villa San Carlos,0,0
International-Champions_League_Grp__A,Benfica,Basel,0,2
International-Champions_League_Grp__A,Manchester United,CSKA Moscow,2,1
International-Champions_League_Grp__B,Bayern Munich,Paris Saint Germain,3,1
International-Champions_League_Grp__B,Celtic,Anderlecht,0,1
International-Champions_League_Grp__C,Chelsea,Atletico Madrid,1,1
International-Champions_League_Grp__C,Roma,Qarabag FK,1,0
International-Champions_League_Grp__D,Olympiacos,Juventus,0,2
International-Champions_League_Grp__D,Barcelona,Sporting CP,2,0
Argentina-Superliga,San Martin San Juan,Banfield,2,1
Bulgaria-First_Professional_League,Lokomotiv Plovdiv,Vereya,1,1
International-Friendlies,Timor-Leste,Philippines,1,0
International-Friendlies,Tuvalu,New Caledonia,2,1
International-Friendlies,Laos,Chinese Taipei,0,2
Slovakia-Super_Liga,Nitra,Spartak Trnava,0,1
England-EFL_Trophy_Final_Stage,Swindon Town,Forest Green Rovers,0,1
England-EFL_Trophy_Final_Stage,Fleetwood Town,Chesterfield,2,0
England-EFL_Trophy_Final_Stage,Swansea City Academy,Charlton Athletic,2,3
England-EFL_Trophy_Final_Stage,Scunthorpe United,Leicester City Academy,1,2
England-EFL_Trophy_Final_Stage,Luton Town,West Ham United Academy,4,0
England-EFL_Trophy_Final_Stage,Port Vale,Shrewsbury Town,1,2
England-EFL_Trophy_Final_Stage,Yeovil Town,AFC Wimbledon,2,0
England-EFL_Trophy_Final_Stage,Gillingham,Oxford United,1,2
England-EFL_Trophy_Final_Stage,Lincoln City,Accrington Stanley,3,2
England-EFL_Trophy_Final_Stage,Bradford City,Oldham Athletic,0,1
Algeria-Ligue_1,USM Alger,US Biskra,2,0
Argentina-Primera_B_Nacional,Almagro,Sarmiento,3,0
Argentina-Primera_B_Nacional,Santamarina,Los Andes,1,1
Argentina-Primera_B_Metropolitana,CA San Miguel,CA Fenix,2,0
Argentina-Primera_C,Ituzaingo,San Martin Burzaco,1,3
Argentina-Primera_C,Club Lujan,Deportivo Armenio,2,1
Argentina-Primera_C,CA Ferrocarril Midland,Dock Sud,1,2
Argentina-Primera_C,Sportivo Italiano,Justo Jose de Urquiza,0,2
Argentina-Primera_C,Sportivo Barracas,Canuelas,2,2
International-CECAFA_Senior_Challenge_Cup_Grp__A,Zanzibar,Rwanda,3,1
International-CECAFA_Senior_Challenge_Cup_Grp__A,Kenya,Libya,0,0
International-CECAFA_Senior_Challenge_Cup_Grp__B,South Sudan,Ethiopia,0,3
Chile-Primera_Division_Torneo_de_Transicion,Universidad Catolica,Palestino,4,1
Chile-Primera_Division_Torneo_de_Transicion,Santiago Wanderers,Deportes Temuco,1,1
Denmark-Reserve_League_First_Stage_Grp__3,Silkeborg Reserves,FC Midtjylland Reserves,1,3
DR_Congo-Super_League_Zone_West,FC MK,Nord Sport,2,0
International-Champions_League_Grp__E,Maribor,Sevilla,1,1
International-Champions_League_Grp__E,Liverpool,Spartak Moscow,7,0
International-Champions_League_Grp__F,Feyenoord,SSC Napoli,2,1
International-Champions_League_Grp__F,Shakhtar Donetsk,Manchester City,2,1
International-Champions_League_Grp__G,RasenBallsport Leipzig,Besiktas,1,2
International-Champions_League_Grp__G,FC Porto,Monaco,5,2
International-Champions_League_Grp__H,Tottenham Hotspur,APOEL Nicosia,3,0
International-Champions_League_Grp__H,Real Madrid,Borussia Dortmund,3,2
International-Friendlies,Solomon Islands,Fiji,0,0
International-Friendlies,Vanuatu,Tonga,5,0
International-Friendlies,Kyrgyzstan,Indonesia,1,0
International-Friendlies,Mongolia,Brunei,
International-FIFA_Club_World_Cup,Al-Jazira,Auckland City FC,1,0
Denmark-DBU_Pokalen,AaB,FC Helsingoer,2,1
Denmark-DBU_Pokalen,Silkeborg,Lyngby,3,1
Egypt-Premier_League,Al Ahly,Alassiouty,1,0
England-EFL_Trophy_Final_Stage,Peterborough United,Southend United,2,0
England-EFL_Trophy_Final_Stage,Blackpool,Mansfield Town,5,4
England-EFL_Trophy_Final_Stage,Milton Keynes Dons,Chelsea Academy,0,4
Portugal-Cup,Maritimo,Cova da Piedade,2,4
Argentina-Federal_A_Zona_1,Club Rivadavia,CA Alvarado,0,1
Argentina-Federal_A_Zona_1,Sansinena BB,Deportivo Madryn,3,0
Argentina-Federal_A_Zona_2,Huracan Las Heras,Union Villa Krause,1,0
Argentina-Federal_A_Zona_2,Union Aconquija,Deportivo Maipu,1,1
Argentina-Federal_A_Zona_4,Sportivo Patria,Guarani Antonio Franco,2,1
Argentina-Primera_B_Metropolitana,Club Atletico Estudiantes,Acassuso,0,0
Argentina-Primera_C,Central Cordoba de Rosario,Laferrere,1,0
Argentina-Primera_C,Berazategui,Excursionistas,1,1
Argentina-Primera_C,CA Defensores Unidos,Leandro N. Alem,1,2
Argentina-Primera_C,El Porvenir,Deportivo Merlo,2,3
Argentina-Primera_C,Defensores de Cambaceres,Argentino de Quilmes,0,1
Bolivia-Primera_Division___Clausura_Adecuacion,Guabira,Club Petrolero,2,1
Botswana-Premier_League,Black Forest,Sankoyo Bush Bucks,1,1
International-CECAFA_Senior_Challenge_Cup_Grp__B,South Sudan,Zimbabwe,
Chile-Primera_Division_Qualification,Union La Calera,San Marcos,2,0
Colombia-Primera_B_Championship_Final,Leones,Chico FC,4,6
Cyprus-Cup_Final_Stage,Ayia Napa,AEL Limassol,2,1
Denmark-Reserve_League_First_Stage_Grp__1,FC Helsingoer Reserves,FC Koebenhavn Reserves,2,2
DR_Congo-Super_League_Zone_East,Mont Bleu,Etoile du Kivu,3,2
DR_Congo-Super_League_Zone_South_Central,Sanga Balende,Ocean Pacifique,3,1
International-Europa_League_Grp__A,Slavia Prague,FC Astana,0,1
International-Europa_League_Grp__A,Villarreal,Maccabi Tel Aviv,0,1
International-Europa_League_Grp__B,Young Boys,Skenderbeu,2,1
International-Europa_League_Grp__B,Dynamo Kyiv,Partizan Beograd,4,1
International-Europa_League_Grp__C,Hoffenheim,Ludogorets Razgrad,1,1
International-Europa_League_Grp__C,Istanbul Basaksehir,Braga,2,1
International-Europa_League_Grp__D,Austria Wien,AEK Athens,0,0
International-Europa_League_Grp__D,Rijeka,AC Milan,2,0
International-Europa_League_Grp__E,Apollon Limassol,Everton,0,3
International-Europa_League_Grp__E,Atalanta,Lyon,1,0
International-Europa_League_Grp__F,FC Koebenhavn,FC Sheriff,2,0
International-Europa_League_Grp__F,Zlin,Lokomotiv Moscow,0,2
International-Europa_League_Grp__G,Hapoel Beer Sheva,Viktoria Plzen,0,2
International-Europa_League_Grp__G,FC FCSB,Lugano,1,2
International-Europa_League_Grp__H,FK Crvena Zvezda,FC Cologne,1,0
International-Europa_League_Grp__H,Arsenal,BATE Borisov,6,0
International-Europa_League_Grp__I,Marseille,Salzburg,0,0
International-Europa_League_Grp__I,Vitoria de Guimaraes,Konyaspor,1,1
International-Europa_League_Grp__J,Zorya,Athletic Bilbao,0,2
International-Europa_League_Grp__J,Hertha Berlin,Oestersunds FK,1,1
International-Europa_League_Grp__K,Zulte-Waregem,Lazio,3,2
International-Europa_League_Grp__K,Vitesse,Nice,1,0
International-Europa_League_Grp__L,Real Sociedad,Zenit St. Petersburg,1,3
International-Europa_League_Grp__L,FK Vardar Skopje,Rosenborg,1,1
International-Copa_Sudamericana,Independiente,Flamengo,2,1
Spain-Segunda_B_Grp__IV,Cordoba B,Villanovense,2,0
Algeria-Ligue_1,MC Alger,USM El Harrach,2,0
Argentina-Federal_A_Zona_1,Deportivo Roca,Independiente de Neuquen,4,0
Argentina-Federal_A_Zona_1,Ferro Carril Oeste General Pico,Villa Mitre,0,1
Argentina-Federal_A_Zona_2,Gimnasia Mendoza,Gutierrez SC,0,0
Argentina-Federal_A_Zona_2,Desamparados,San Lorenzo de Alem,2,0
Argentina-Federal_A_Zona_2,Juventud Unida Universitario,Estudiantes de Rio Cuarto,0,1
Argentina-Federal_A_Zona_4,Gimnasia y Tiro,CA Chaco For Ever,1,3
Argentina-Federal_A_Zona_4,Sarmiento de Resistencia,Juventud Antoniana,2,0
Argentina-Federal_A_Zona_4,Crucero del Norte,Deportivo San Jorge Tucuman,1,2
Argentina-Federal_A_Zona_4,Altos Hornos Zapla,Deportivo Mandiyu,2,1
Bolivia-Primera_Division___Clausura_Adecuacion,Universitario,Nacional Potosi,2,0
Bolivia-Primera_Division___Clausura_Adecuacion,Sport Boys Warnes,Blooming,1,1
Botswana-Premier_League,Uniao Flamengo Santos,Tafic,1,1
International-CECAFA_Senior_Challenge_Cup_Grp__A,Tanzania,Zanzibar,1,2
France-Ligue_1,Bordeaux,Strasbourg,0,3
Germany-1__Bundesliga,VfB Stuttgart,Bayer Leverkusen,0,2
Netherlands-Eredivisie,Willem II,NAC Breda,1,1
Portugal-Primeira_Liga,Rio Ave,Moreirense,2,1
Russia-Premier_League,Ural,Arsenal Tula,1,1
Spain-Primera_Division,Alaves,Las Palmas,2,0
Argentina-Superliga,Patronato de Parana,Olimpo,1,0
Argentina-Superliga,Temperley,Tigre,2,1
Australia-A_League,Melbourne Victory,Adelaide United,1,2
Belgium-First_Division_A,Waasland-Beveren,Standard Liege,3,1
Bulgaria-First_Professional_League,Septemvri Sofia,Cherno More Varna,2,1
Croatia-1__Division,Inter Zapresic,Cibalia,3,2
Denmark-Superligaen,AC Horsens,SoenderjyskE,2,1
England-Championship,Sheffield United,Bristol City,1,2
International-Friendlies,Tonga,New Caledonia,2,4
Germany-2__Bundesliga,Eintracht Braunschweig,Holstein Kiel,0,0
Germany-2__Bundesliga,Erzgebirge Aue,Darmstadt,1,0
Italy-Serie_B,Ternana,Parma Calcio 1913,1,1
Italy-Serie_B,Novara,Cremonese,1,1
Italy-Serie_B,Spezia,Foggia,1,0
Italy-Serie_B,Cesena,Pescara,4,2
Mexico-Liga_MX_Apertura_Playoff,Tigres,Monterrey,1,1
Netherlands-Eerste_Divisie,Fortuna Sittard,RKC Waalwijk,6,0
Netherlands-Eerste_Divisie,FC Dordrecht,MVV Maastricht,2,4
Netherlands-Eerste_Divisie,Almere City FC,De Graafschap,2,1
Netherlands-Eerste_Divisie,FC Volendam,Jong FC Utrecht,2,1
Netherlands-Eerste_Divisie,Telstar,FC Emmen,0,0
Poland-Ekstraklasa,Gornik Zabrze,Lechia Gdansk,1,1
Poland-Ekstraklasa,Sandecja Nowy Sacz,Jagiellonia Bialystok,0,1
Romania-Liga_I,Juventus Bucuresti,Astra Giurgiu,0,1
Scotland-Premiership,Dundee FC,Aberdeen,0,1
Spain-Segunda_Division,Barcelona B,Sporting Gijon,2,1
Spain-Segunda_Division,Granada,Almeria,3,2
Turkey-Super_Lig,Bursaspor,Fenerbahce,0,1
Belgium-First_Division_B_2nd_Stage,Roeselare,Cercle Brugge,0,3
France-Ligue_2,SC Bastia,Lens,
France-Ligue_2,Niort,Reims,1,2
France-Ligue_2,Valenciennes,Quevilly,1,1
France-Ligue_2,Brest,Bourg en Bresse Peronnas,3,0
France-Ligue_2,Paris FC,Lens,2,2
England-Premier_League,Huddersfield Town,Brighton &amp; Hove Albion,2,0
England-Premier_League,Newcastle United,Leicester City,2,3
England-Premier_League,Burnley,Watford,1,0
England-Premier_League,Swansea City,West Bromwich Albion,1,0
England-Premier_League,West Ham United,Chelsea,1,0
England-Premier_League,Crystal Palace,AFC Bournemouth,2,2
England-Premier_League,Tottenham Hotspur,Stoke City,5,1
France-Ligue_1,Toulouse,Caen,2,0
France-Ligue_1,Metz,Rennes,1,1
France-Ligue_1,Angers,Montpellier,1,1
France-Ligue_1,Paris Saint Germain,Lille,3,1
France-Ligue_1,Monaco,Troyes,3,2
France-Ligue_1,Guingamp,Dijon,4,0
Germany-1__Bundesliga,Hamburger SV,Wolfsburg,0,0
Germany-1__Bundesliga,RasenBallsport Leipzig,Mainz 05,2,2
Germany-1__Bundesliga,Eintracht Frankfurt,Bayern Munich,0,1
Germany-1__Bundesliga,Borussia Moenchengladbach,Schalke 04,1,1
Germany-1__Bundesliga,Borussia Dortmund,Werder Bremen,1,2
Italy-Serie_A,Juventus,Inter,0,0
Italy-Serie_A,Cagliari,Sampdoria,2,2
Netherlands-Eredivisie,AZ Alkmaar,Heracles,5,0
Netherlands-Eredivisie,FC Twente,ADO Den Haag,2,3
Netherlands-Eredivisie,Excelsior,PEC Zwolle,1,2
Netherlands-Eredivisie,SC Heerenveen,VVV-Venlo,2,2
Portugal-Primeira_Liga,Aves,Tondela,0,1
Portugal-Primeira_Liga,Boavista,Sporting CP,1,3
Portugal-Primeira_Liga,Benfica,Estoril,3,1
Russia-Premier_League,Dinamo Moscow,Anzhi Makhachkala,2,0
Russia-Premier_League,Rubin Kazan,SKA-Khabarovsk,3,1
Spain-Primera_Division,Getafe,Eibar,0,0
Spain-Primera_Division,Valencia,Celta Vigo,2,1
Spain-Primera_Division,Deportivo La Coruna,Leganes,1,0
Spain-Primera_Division,Real Madrid,Sevilla,5,0
Argentina-Superliga,Belgrano,Huracan,1,0
Argentina-Superliga,Banfield,Argentinos Juniors,2,3
Australia-A_League,Western Sydney Wanderers FC,Sydney FC,0,5
Australia-A_League,Perth Glory,Newcastle Jets,1,2
Australia-A_League,Brisbane Roar FC,Wellington Phoenix,0,0
Austria-Bundesliga,Rapid Wien,Mattersburg,2,2
Austria-Bundesliga,Sturm Graz,SKN St. Poelten,3,2
England-Premier_League,Liverpool,Everton,1,1
England-Premier_League,Southampton,Arsenal,1,1
England-Premier_League,Manchester United,Manchester City,1,2
France-Ligue_1,Nantes,Nice,1,2
France-Ligue_1,Marseille,Saint-Etienne,3,0
France-Ligue_1,Amiens,Lyon,1,2
Germany-1__Bundesliga,Augsburg,Hertha Berlin,1,1
Germany-1__Bundesliga,Hannover 96,Hoffenheim,2,0
Germany-1__Bundesliga,FC Cologne,Freiburg,3,4
Italy-Serie_A,Udinese,Benevento,2,0
Italy-Serie_A,AC Milan,Bologna,2,1
Italy-Serie_A,SSC Napoli,Fiorentina,0,0
Italy-Serie_A,Sassuolo,Crotone,2,1
Italy-Serie_A,ChievoVerona,Roma,0,0
Italy-Serie_A,SPAL 2013,Hellas Verona,2,2
Netherlands-Eredivisie,Ajax,PSV Eindhoven,3,0
Netherlands-Eredivisie,Roda JC Kerkrade,FC Groningen,2,2
Portugal-Primeira_Liga,Vitoria de Setubal,FC Porto,0,5
Portugal-Primeira_Liga,Portimonense,Chaves,0,1
Portugal-Primeira_Liga,Belenenses,Pacos de Ferreira,1,1
Russia-Premier_League,Spartak Moscow,CSKA Moscow,3,0
Russia-Premier_League,Amkar,FC Krasnodar,1,3
Russia-Premier_League,FC Rostov,FC Ufa,1,0
Spain-Primera_Division,Real Betis,Atletico Madrid,0,1
Spain-Primera_Division,Levante,Athletic Bilbao,1,2
Spain-Primera_Division,Real Sociedad,Malaga,0,2
Spain-Primera_Division,Villarreal,Barcelona,0,2
Argentina-Superliga,Arsenal Sarandi,Independiente,1,2
Argentina-Superliga,Racing Club,Gimnasia LP,3,1
Argentina-Superliga,Rosario Central,Newells Old Boys,1,0
Argentina-Superliga,Colon,Talleres,0,2
Australia-A_League,Melbourne City FC,Central Coast Mariners,1,0
Austria-Bundesliga,Wolfsberger AC,Salzburg,0,0
Austria-Bundesliga,Altach,Austria Wien,1,0
Belgium-First_Division_A,Anderlecht,Sporting Charleroi,1,3
Belgium-First_Division_A,St.Truiden,Zulte-Waregem,1,1
Belgium-First_Division_A,Club Brugge,Lokeren,3,1
Bulgaria-First_Professional_League,Dunav Ruse,Lokomotiv Plovdiv,2,2
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Beroe,6,0
Bulgaria-First_Professional_League,Vereya,Vitosha Bistritsa,1,1
Italy-Serie_A,Lazio,Torino,1,3
Portugal-Primeira_Liga,Maritimo,Braga,1,0
Portugal-Primeira_Liga,Vitoria de Guimaraes,Feirense,1,0
Russia-Premier_League,FK Akhmat,Zenit St. Petersburg,0,0
Russia-Premier_League,Tosno,Lokomotiv Moscow,1,3
Spain-Primera_Division,Espanyol,Girona,0,1
Argentina-Superliga,San Martin San Juan,Defensa y Justicia,1,0
Argentina-Superliga,Estudiantes,Boca Juniors,0,1
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Ludogorets Razgrad,0,2
Denmark-Superligaen,Randers FC,FC Midtjylland,0,4
England-Championship,Reading,Cardiff City,2,2
Germany-2__Bundesliga,Fortuna Duesseldorf,Nuernberg,0,2
Greece-Super_League,AEK Athens,AOK Kerkyra,3,1
Israel-Ligat_HaAl,Maccabi Petach Tikva,Maccabi Tel Aviv,0,0
Mexico-Liga_MX_Apertura_Playoff,Monterrey,Tigres,1,2
Romania-Liga_I,Sepsi OSK,CSMS Iasi,2,1
Romania-Liga_I,Dinamo Bucuresti,FC Voluntari,2,0
Turkey-Super_Lig,Konyaspor,Karabukspor,2,0
France-Ligue_2,Nimes,Clermont Foot,3,1
Turkey-1__Lig,Eskisehirspor,Gaziantepspor,7,0
Argentina-Primera_B_Nacional,Club Atletico Mitre,Brown de Adrogue,1,0
Argentina-Primera_B_Nacional,Atletico Rafaela,Flandria,4,1
Argentina-Primera_B_Nacional,Deportivo Riestra,Santamarina,1,0
Argentina-Federal_A_Zona_1,Villa Mitre,Deportivo Roca,1,2
Argentina-Federal_A_Zona_1,CA Alvarado,Ferro Carril Oeste General Pico,1,0
Argentina-Federal_A_Zona_1,Club Cipolletti,Sansinena BB,3,0
Argentina-Federal_A_Zona_2,Deportivo Maipu,Desamparados,2,1
Argentina-Federal_A_Zona_3,CD Libertad,Atletico Parana,0,1
Argentina-Federal_A_Zona_4,Deportivo Mandiyu,Sarmiento de Resistencia,2,0
Argentina-Primera_B_Metropolitana,San Telmo,Atlanta,0,2
Argentina-Primera_C,Argentino de Quilmes,CA Ferrocarril Midland,1,1
Argentina-Primera_C,Leandro N. Alem,Central Cordoba de Rosario,0,0
Argentina-Primera_C,Defensores de Cambaceres,Sportivo Barracas,4,0
Argentina-Primera_C,Laferrere,Ituzaingo,2,3
International-CECAFA_Senior_Challenge_Cup_Grp__A,Libya,Zanzibar,1,0
International-CECAFA_Senior_Challenge_Cup_Grp__A,Kenya,Tanzania,1,0
International-CECAFA_Senior_Challenge_Cup_Grp__B,South Sudan,Burundi,0,0
Colombia-Primera_A_Clausura_Final_Stage,Millonarios,America de Cali,0,0
Costa_Rica-Primera_Division_Apertura_Final_Stage,Municipal Perez Zeledon,Deportivo Saprissa,3,2
Cyprus-1__Division,AEL Limassol,APOEL Nicosia,0,0
England-Premier_League,Huddersfield Town,Chelsea,1,3
England-Premier_League,Burnley,Stoke City,1,0
England-Premier_League,Crystal Palace,Watford,2,1
England-FA_Cup,Yeovil Town,Port Vale,3,2
England-FA_Cup,Peterborough United,Woking,5,2
England-FA_Cup,Wigan Athletic,AFC Fylde,3,2
England-FA_Cup,Exeter City,Forest Green Rovers,2,1
Germany-1__Bundesliga,Freiburg,Borussia Moenchengladbach,1,0
Germany-1__Bundesliga,Hamburger SV,Eintracht Frankfurt,1,2
Germany-1__Bundesliga,Mainz 05,Borussia Dortmund,0,2
Germany-1__Bundesliga,Wolfsburg,RasenBallsport Leipzig,1,1
Italy-Serie_A,Genoa,Atalanta,1,2
Netherlands-Eredivisie,NAC Breda,FC Twente,1,2
Netherlands-Eredivisie,PEC Zwolle,AZ Alkmaar,1,1
Argentina-Superliga,Chacarita Juniors,Lanus,3,0
International-Friendlies,New Caledonia,Solomon Islands,0,1
International-Friendlies,Tuvalu,Vanuatu,0,10
International-Friendlies,Fiji,Tonga,4,0
Italy-Coppa_Italia,Inter,Pordenone Calcio,5,4
Netherlands-Eerste_Divisie,Go Ahead Eagles,Jong PSV,1,1
Poland-Ekstraklasa,Jagiellonia Bialystok,Korona Kielce,5,1
Poland-Ekstraklasa,Arka Gdynia,Gornik Zabrze,1,0
Poland-Ekstraklasa,Piast Gliwice,Legia Warszawa,0,1
Poland-Ekstraklasa,Termalica Nieciecza,Slask Wroclaw,2,1
Scotland-Premiership,Hearts,Dundee FC,2,0
Scotland-Premiership,Ross County,Kilmarnock,2,2
Turkey-Cup,Manisaspor,Besiktas,1,1
Turkey-Cup,Sivas Belediye Spor,Galatasaray,2,1
Turkey-Cup,Bursaspor,Adanaspor,2,0
Turkey-Cup,Trabzonspor,Erzurum BB,5,1
Turkey-Cup,Boluspor,Kasimpasa,4,1
Turkey-Cup,Antalyaspor,Orhangazispor,2,3
International-FIFA_Club_World_Cup,Wydad Casablanca,Urawa Red Diamonds,2,3
International-FIFA_Club_World_Cup,Gremio,Pachuca,1,0
Belgium-Cup,Kortrijk,Gent,4,1
Belgium-Cup,Oostende,Standard Liege,2,3
Bulgaria-Cup,Botev Plovdiv,Litex Lovech,5,0
International-East_Asian_Championship_Final_Stage,Japan,China,2,1
International-East_Asian_Championship_Final_Stage,North Korea,South Korea,0,1
France-Ligue_2,Orleans,GFC Ajaccio,2,0
England-Premier_League,Newcastle United,Everton,0,1
England-Premier_League,West Ham United,Arsenal,0,0
England-Premier_League,Tottenham Hotspur,Brighton &amp; Hove Albion,2,0
England-Premier_League,Manchester United,AFC Bournemouth,1,0
England-Premier_League,Southampton,Leicester City,1,4
England-Premier_League,Swansea City,Manchester City,0,4
England-Premier_League,Liverpool,West Bromwich Albion,0,0
England-FA_Cup,Crewe Alexandra,Blackburn Rovers,0,1
Germany-1__Bundesliga,Schalke 04,Augsburg,3,2
Germany-1__Bundesliga,Bayern Munich,FC Cologne,1,0
Germany-1__Bundesliga,Bayer Leverkusen,Werder Bremen,1,0
Germany-1__Bundesliga,Hoffenheim,VfB Stuttgart,1,0
Germany-1__Bundesliga,Hertha Berlin,Hannover 96,3,1
Netherlands-Eredivisie,Vitesse,Willem II,2,2
Netherlands-Eredivisie,Feyenoord,SC Heerenveen,1,1
Netherlands-Eredivisie,FC Groningen,PSV Eindhoven,3,3
Netherlands-Eredivisie,ADO Den Haag,Roda JC Kerkrade,3,2
Netherlands-Eredivisie,VVV-Venlo,FC Utrecht,0,1
Italy-Coppa_Italia,AC Milan,Hellas Verona,3,0
Italy-Coppa_Italia,Fiorentina,Sampdoria,3,2
Poland-Ekstraklasa,Lechia Gdansk,Pogon Szczecin,1,3
Poland-Ekstraklasa,Wisla Plock,Sandecja Nowy Sacz,2,2
Poland-Ekstraklasa,Zaglebie Lubin,Lech Poznan,0,0
Poland-Ekstraklasa,Cracovia,Wisla Krakow,1,4
Scotland-Premiership,St.Johnstone,Aberdeen,0,3
Scotland-Premiership,Hibernian,Rangers,1,2
Scotland-Premiership,Partick Thistle,Motherwell,3,2
Scotland-Premiership,Celtic,Hamilton Academical,3,1
Turkey-Cup,Genclerbirligi,Karsspor,2,1
Turkey-Cup,Yeni Malatyaspor,Osmanlispor FK,1,1
Turkey-Cup,Alanyaspor,Giresunspor,2,2
Turkey-Cup,Adana Demirspor,Fenerbahce,1,4
Turkey-Cup,Akhisar Belediye Genclik Ve Spor,Ankara Demirspor,1,1
Turkey-Cup,Bucaspor,Sivasspor,1,0
International-FIFA_Club_World_Cup,Al-Jazira,Real Madrid,1,2
Belgium-Cup,Genk,Waasland-Beveren,7,5
Bulgaria-Cup,Etar,Slavia Sofia,1,3
Egypt-Premier_League,Al Masry,El Dakhleya,1,1
Egypt-Premier_League,El Geish,El Raja Marsa Matruh,2,1
Egypt-Premier_League,ENPPI,El Entag El Harby,2,0
England-FA_Cup,Hereford,Fleetwood Town,0,2
Netherlands-Eredivisie,Heracles,Sparta Rotterdam,3,2
Netherlands-Eredivisie,Ajax,Excelsior,3,1
International-Friendlies,Tuvalu,Tonga,4,3
International-Friendlies,Qatar,Liechtenstein,1,2
Italy-Coppa_Italia,Lazio,Cittadella,4,1
Turkey-Cup,Istanbulspor,Karabukspor,1,0
Turkey-Cup,Konyaspor,Batman Petrolspor,2,0
Turkey-Cup,Istanbul Basaksehir,Kahramanmarasspor,1,0
Turkey-Cup,Eyupspor,Kayserispor,0,2
Bulgaria-Cup,PFC CSKA-Sofia,Ludogorets Razgrad,2,1
International-Copa_Sudamericana,Flamengo,Independiente,1,1
Egypt-Premier_League,El Zamalek,Ismaily SC,0,1
Egypt-Premier_League,Wadi Degla FC,Al Mokawloon Al Arab,2,0
Egypt-Premier_League,Misr El-Maqasa,Al Nasr,1,4
Portugal-Cup,FC Porto,Vitoria de Guimaraes,4,0
Wales-Premier_League,Newtown,Llandudno FC,2,1
Andorra-1__Division,Encamp,Lusitanos,0,6
Botswana-Premier_League,Botswana Defence Force XI,Orapa United FC,1,0
Botswana-Premier_League,Township Rollers,Sankoyo Bush Bucks,1,0
International-CECAFA_Senior_Challenge_Cup_Final_Stage,Kenya,Burundi,1,0
Chile-Primera_Division_Copa_Libertadores_Playoff,Universidad de Concepcion,Union Espanola,1,0
Chile-Primera_Division_Qualification,Union La Calera,Santiago Wanderers,0,1
Colombia-Primera_A_Clausura_Final_Stage,Millonarios,Santa Fe,1,0
Costa_Rica-Primera_Division_Apertura_Final_Stage,Santos de Guapiles,Municipal Perez Zeledon,1,1
Costa_Rica-Primera_Division_Apertura_Final_Stage,Deportivo Saprissa,Club Sport Herediano,1,0
Denmark-Ligaen_U17,FC Nordsjaelland U17,FC Koebenhavn U17,3,1
Denmark-Ligaen_U19,Vejle U19,FC Koebenhavn U19,1,4
DR_Congo-Super_League_Zone_South_Central,Saint-Eloi Lupopo,TP Mazembe,0,0
Ecuador-Serie_A___Final_Stage,Emelec,Delfin,4,2
Ecuador-Serie_A_Copa_Sudamericana_Playoff,Tecnico Universitario,LDU de Quito,1,2
Germany-Regionalliga_Southwest,VfB Stuttgart II,Hessen Kassel,1,0
India-I_League,Mohun Bagan,Shillong Lajong,1,1
India-Indian_Super_League,FC Pune City,Bengaluru FC,1,3
Iran-Azadegan_League,Malavan,Mes Rafsanjan,1,2
Iraq-Premier_League,Naft Al Junoob,Al Naft,1,1
Iraq-Premier_League,Al Hussein,Al Shorta,0,0
Iraq-Premier_League,Karbalaa,Al Talaba,0,3
Iraq-Premier_League,Naft Al Wasat,Al Hedood,2,1
Israel-Toto_Cup,Hapoel Beer Sheva,Maccabi Tel Aviv,0,1
France-Ligue_1,Saint-Etienne,Monaco,0,4
Germany-1__Bundesliga,Borussia Moenchengladbach,Hamburger SV,3,1
Portugal-Primeira_Liga,Pacos de Ferreira,Boavista,1,2
Spain-Primera_Division,Sevilla,Levante,0,0
Australia-A_League,Sydney FC,Melbourne City FC,3,1
Belgium-First_Division_A,Royal Excel Mouscron,Oostende,1,0
England-Championship,Sheffield Wednesday,Wolverhampton Wanderers,0,1
International-Friendlies,Solomon Islands,Vanuatu,2,3
International-Friendlies,Fiji,New Caledonia,4,1
Germany-2__Bundesliga,Eintracht Braunschweig,Fortuna Duesseldorf,0,1
Germany-2__Bundesliga,Union Berlin,Ingolstadt,1,2
Italy-Serie_B,Foggia,Venezia,2,2
Netherlands-Eerste_Divisie,De Graafschap,FC Oss,1,1
Netherlands-Eerste_Divisie,RKC Waalwijk,FC Volendam,1,3
Netherlands-Eerste_Divisie,FC Eindhoven,Go Ahead Eagles,3,2
Netherlands-Eerste_Divisie,Cambuur,FC Dordrecht,3,0
Netherlands-Eerste_Divisie,NEC Nijmegen,Helmond Sport,1,1
Netherlands-Eerste_Divisie,Jong PSV,Almere City FC,3,2
Netherlands-Eerste_Divisie,FC Den Bosch,Fortuna Sittard,2,4
Netherlands-Eerste_Divisie,Jong FC Utrecht,Telstar,0,1
Netherlands-Eerste_Divisie,FC Emmen,Jong Ajax,2,2
Netherlands-Eerste_Divisie,MVV Maastricht,Jong AZ Alkmaar,3,0
Poland-Ekstraklasa,Slask Wroclaw,Jagiellonia Bialystok,1,0
Poland-Ekstraklasa,Korona Kielce,Piast Gliwice,1,1
Romania-Liga_I,Astra Giurgiu,Botosani,2,1
Spain-Segunda_Division,Cadiz,Barcelona B,3,1
Belgium-First_Division_B_2nd_Stage,Oud-Heverlee,Lierse,2,1
Bulgaria-Cup,Dunav Ruse,Levski Sofia,0,2
Egypt-Premier_League,Smouha SC,Alassiouty,1,3
Egypt-Premier_League,Tanta,Al Ahly,1,1
Egypt-Premier_League,Petrojet,Al-Ittihad Al-Sakandary,2,0
England-League_2,Swindon Town,Colchester United,2,3
France-Ligue_2,Quevilly,Brest,1,4
France-Ligue_2,AC Ajaccio,Auxerre,3,1
France-Ligue_2,Nancy,Paris FC,0,1
France-Ligue_2,Le Havre,Niort,2,1
France-Ligue_2,Chateauroux,Orleans,0,0
France-Ligue_2,Bourg en Bresse Peronnas,Lorient,2,2
France-Ligue_2,Nancy,SC Bastia,
France-Ligue_2,Clermont Foot,Sochaux,0,2
England-Premier_League,Watford,Huddersfield Town,1,4
England-Premier_League,Brighton &amp; Hove Albion,Burnley,0,0
England-Premier_League,Manchester City,Tottenham Hotspur,4,1
England-Premier_League,Stoke City,West Ham United,0,3
England-Premier_League,Chelsea,Southampton,1,0
England-Premier_League,Leicester City,Crystal Palace,0,3
England-Premier_League,Arsenal,Newcastle United,1,0
France-Ligue_1,Strasbourg,Toulouse,2,1
France-Ligue_1,Dijon,Lille,3,0
France-Ligue_1,Troyes,Amiens,1,0
France-Ligue_1,Montpellier,Metz,1,3
France-Ligue_1,Caen,Guingamp,0,0
France-Ligue_1,Rennes,Paris Saint Germain,1,4
Germany-1__Bundesliga,FC Cologne,Wolfsburg,1,0
Germany-1__Bundesliga,Augsburg,Freiburg,3,3
Germany-1__Bundesliga,Borussia Dortmund,Hoffenheim,2,1
Germany-1__Bundesliga,Werder Bremen,Mainz 05,2,2
Germany-1__Bundesliga,VfB Stuttgart,Bayern Munich,0,1
Germany-1__Bundesliga,Eintracht Frankfurt,Schalke 04,2,2
Italy-Serie_A,Roma,Cagliari,1,0
Italy-Serie_A,Torino,SSC Napoli,1,3
Italy-Serie_A,Inter,Udinese,1,3
Netherlands-Eredivisie,FC Twente,Vitesse,1,1
Netherlands-Eredivisie,Willem II,PEC Zwolle,2,3
Netherlands-Eredivisie,Roda JC Kerkrade,VVV-Venlo,0,1
Netherlands-Eredivisie,SC Heerenveen,NAC Breda,1,0
Netherlands-Eredivisie,PSV Eindhoven,ADO Den Haag,3,0
Portugal-Primeira_Liga,Estoril,Aves,3,2
Portugal-Primeira_Liga,Braga,Belenenses,4,0
Spain-Primera_Division,Athletic Bilbao,Real Sociedad,0,0
Spain-Primera_Division,Eibar,Valencia,2,1
Spain-Primera_Division,Atletico Madrid,Alaves,1,0
Australia-A_League,Central Coast Mariners,Western Sydney Wanderers FC,0,2
Australia-A_League,Perth Glory,Wellington Phoenix,1,0
Australia-A_League,Newcastle Jets,Adelaide United,2,1
Austria-Bundesliga,Mattersburg,Wolfsberger AC,5,1
Austria-Bundesliga,Salzburg,LASK,0,0
Austria-Bundesliga,SKN St. Poelten,Rapid Wien,0,5
Austria-Bundesliga,Admira Moedling,Altach,3,1
Belgium-First_Division_A,Kortrijk,KV Mechelen,2,0
England-Premier_League,AFC Bournemouth,Liverpool,0,4
England-Premier_League,West Bromwich Albion,Manchester United,1,2
France-Ligue_1,Nice,Bordeaux,1,0
France-Ligue_1,Lyon,Marseille,2,0
France-Ligue_1,Nantes,Angers,1,0
Germany-1__Bundesliga,Hannover 96,Bayer Leverkusen,4,4
Germany-1__Bundesliga,RasenBallsport Leipzig,Hertha Berlin,2,3
Italy-Serie_A,Sampdoria,Sassuolo,0,1
Italy-Serie_A,Crotone,ChievoVerona,1,0
Italy-Serie_A,Benevento,SPAL 2013,1,2
Italy-Serie_A,Hellas Verona,AC Milan,3,0
Italy-Serie_A,Atalanta,Lazio,3,3
Italy-Serie_A,Fiorentina,Genoa,0,0
Italy-Serie_A,Bologna,Juventus,0,3
Netherlands-Eredivisie,FC Utrecht,Heracles,1,1
Netherlands-Eredivisie,Excelsior,FC Groningen,2,0
Netherlands-Eredivisie,AZ Alkmaar,Ajax,1,2
Netherlands-Eredivisie,Sparta Rotterdam,Feyenoord,0,7
Portugal-Primeira_Liga,Sporting CP,Portimonense,2,0
Portugal-Primeira_Liga,Feirense,Vitoria de Setubal,1,0
Portugal-Primeira_Liga,Tondela,Benfica,1,5
Portugal-Primeira_Liga,Chaves,Rio Ave,1,1
Spain-Primera_Division,Barcelona,Deportivo La Coruna,4,0
Spain-Primera_Division,Las Palmas,Espanyol,2,2
Spain-Primera_Division,Celta Vigo,Villarreal,0,1
Spain-Primera_Division,Girona,Getafe,1,0
Australia-A_League,Brisbane Roar FC,Melbourne Victory,1,2
Austria-Bundesliga,Austria Wien,Sturm Graz,1,0
Belgium-First_Division_A,Club Brugge,Anderlecht,5,0
Belgium-First_Division_A,Zulte-Waregem,Royal Antwerp,1,2
Belgium-First_Division_A,Sporting Charleroi,Genk,1,1
Croatia-1__Division,Rijeka,Rudes,3,0
Croatia-1__Division,Hajduk Split,Inter Zapresic,5,0
International-Friendlies,U.A.E.,Iraq,1,0
Germany-2__Bundesliga,Sandhausen,Holstein Kiel,3,1
Germany-2__Bundesliga,Duisburg,Dynamo Dresden,2,0
Germany-2__Bundesliga,Greuther Fuerth,Darmstadt,1,1
Greece-Super_League,Lamia,AE Larissa,0,2
Greece-Super_League,Xanthi,Panathinaikos,1,1
Greece-Super_League,Asteras Tripolis,Panetolikos,0,0
England-Premier_League,Everton,Swansea City,3,1
Portugal-Primeira_Liga,Moreirense,Vitoria de Guimaraes,2,1
Portugal-Primeira_Liga,FC Porto,Maritimo,3,1
Spain-Primera_Division,Malaga,Real Betis,0,2
Croatia-1__Division,Slaven,NK Lokomotiva,2,2
International-Friendlies,Bahrain,Kuwait,0,0
Germany-2__Bundesliga,St. Pauli,Bochum,2,1
Greece-Super_League,Levadiakos,Panionios,2,1
Israel-Ligat_HaAl,Beitar Jerusalem,Maccabi Tel Aviv,1,2
Netherlands-Eerste_Divisie,Jong Ajax,FC Den Bosch,1,0
Netherlands-Eerste_Divisie,Helmond Sport,FC Eindhoven,0,0
Poland-Ekstraklasa,Gornik Zabrze,Cracovia,0,4
Romania-Liga_I,FC Voluntari,Sepsi OSK,3,0
Romania-Liga_I,ACS Poli Timisoara,Dinamo Bucuresti,0,0
Turkey-Super_Lig,Goztepe,Konyaspor,1,0
Turkey-Super_Lig,Fenerbahce,Karabukspor,2,0
Egypt-Premier_League,El Dakhleya,ENPPI,1,2
Egypt-Premier_League,Al Nasr,Al Masry,2,3
France-Ligue_2,Lens,Tours,2,0
Italy-Serie_C_Grp__A,Livorno,Piacenza,2,2
Turkey-1__Lig,Adanaspor,Istanbulspor,0,0
Colombia-Primera_A_Clausura_Final_Stage,Santa Fe,Millonarios,2,2
Cyprus-1__Division,Alki Oroklinis,Pafos FC,2,1
England-Southern_Premier_Division,Dorchester Town,Farnborough,4,0
England-FA_Trophy,Solihull Moors,Tranmere Rovers,2,0
England-Premier_League_2_Division_1,Manchester United U23,Leicester U23,1,1
England-Premier_League_2_Division_2,Brighton &amp; Hove Albion U23,Norwich U23,1,1
England-Premier_League_2_Division_2,Reading U23,Southampton U23,1,1
England-Premier_League_2_Division_2,West Bromwich Albion U23,Aston Villa U23,1,4
India-I_League,Minerva Punjab,Indian Arrows,1,0
India-I_League,Aizawl,Shillong Lajong,0,1
Iran-Hazfi_Cup,Khoneh Be Khoneh,Gostaresh Foolad FC,2,0
Israel-Leumit_League,Hapoel Hadera Eran,Hapoel Marmorek,0,3
Jamaica-Premier_League,Montego Bay United FC,Harbour View,3,2
Malta-Premier_League,Gzira United,Lija,3,2
Morocco-Botola_Pro,Wydad Casablanca,Ittihad Tanger,0,1
Scotland-Development_League,Hearts U20,Ross County U20,4,1
Turkey-3__Lig_Grp__3,Elaziz Belediyespor,Kizilcabolukspor,3,4
Uruguay-Primera_Division_Relegation_Playoff,Sud America,El Tanque Sisley,3,5
England-FA_Cup,Carlisle United,Gillingham,3,1
Spain-Primera_Division,Levante,Leganes,0,0
England-EFL_Cup,Leicester City,Manchester City,4,5
England-EFL_Cup,Arsenal,West Ham United,1,0
Germany-DFB_Pokal,Paderborn,Ingolstadt,1,0
Germany-DFB_Pokal,Schalke 04,FC Cologne,1,0
Germany-DFB_Pokal,Mainz 05,VfB Stuttgart,3,1
Germany-DFB_Pokal,Nuernberg,Wolfsburg,0,2
Italy-Coppa_Italia,SSC Napoli,Udinese,1,0
Netherlands-KNVB_Cup,PEC Zwolle,NEC Nijmegen,2,0
Netherlands-KNVB_Cup,Cambuur,GVVV Veenendaal,3,0
Netherlands-KNVB_Cup,Willem II,RKC Waalwijk,3,0
Spain-Segunda_Division,Valladolid,Zaragoza,3,2
Spain-Segunda_Division,Barcelona B,Albacete,0,1
Egypt-Premier_League,El Entag El Harby,Tanta,1,0
Egypt-Premier_League,Ismaily SC,El Geish,1,1
Egypt-Premier_League,Al Mokawloon Al Arab,Petrojet,2,0
Egypt-Premier_League,El Raja Marsa Matruh,Misr El-Maqasa,1,1
Greece-Cup_Final_Stage,Trikala,PAOK Thessaloniki FC,1,5
Scotland-Championship,Livingston,Falkirk,0,0
Scotland-League_One,Stranraer,Albion Rovers,2,2
Wales-Premier_League,TNS,Connah's Quay,3,0
Wales-Premier_League,Prestatyn Town FC,Cefn Druids AFC,1,2
England-National_League_North,North Ferriby United,Curzon,0,1
England-Isthmian_Premier_Division,Leiston,Merstham,3,1
England-Isthmian_Premier_Division,Staines Town,Harlow Town,4,1
England-Isthmian_Premier_Division,Billericay,Metropolitan Police FC,3,0
England-Isthmian_Premier_Division,Margate,Brightlingsea Regent,4,2
England-Isthmian_Premier_Division,Dorking Wanderers,Hendon,0,3
England-Isthmian_Premier_Division,Needham Market,Leatherhead,0,0
England-Southern_Premier_Division,Merthyr Town,Basingstoke,1,1
England-Southern_Premier_Division,Bishop's Stortford,Hitchin Town,0,3
England-Southern_Premier_Division,Kettering Town FC,Hereford,1,3
England-FA_Trophy,Brackley Town,Braintree Town,2,0
England-FA_Trophy,Altrincham,Warrington Town,1,2
England-FA_Trophy,Heybridge Swifts,Hampton &amp; Richmond,3,2
England-FA_Trophy,Chesham United,Weston Super Mare,0,2
England-FA_Trophy,Boreham Wood,Dartford,5,3
England-FA_Trophy,Blyth Spartans,Telford,1,0
England-Premier_League_2_Division_1,Tottenham U23,Sunderland U23,0,0
France-Ligue_1,Lille,Nice,1,1
France-Ligue_1,Monaco,Rennes,2,1
France-Ligue_1,Bordeaux,Montpellier,0,2
France-Ligue_1,Marseille,Troyes,3,1
France-Ligue_1,Paris Saint Germain,Caen,3,1
France-Ligue_1,Amiens,Nantes,0,1
France-Ligue_1,Guingamp,Saint-Etienne,2,1
France-Ligue_1,Metz,Strasbourg,3,0
France-Ligue_1,Toulouse,Lyon,1,2
France-Ligue_1,Angers,Dijon,2,1
Spain-Primera_Division,Getafe,Las Palmas,2,0
Spain-Primera_Division,Real Sociedad,Sevilla,3,1
Belgium-First_Division_A,KV Mechelen,Club Brugge,0,3
England-EFL_Cup,Bristol City,Manchester United,2,1
England-EFL_Cup,Chelsea,AFC Bournemouth,2,1
Germany-DFB_Pokal,Borussia Moenchengladbach,Bayer Leverkusen,0,1
Germany-DFB_Pokal,FC Heidenheim,Eintracht Frankfurt,1,2
Germany-DFB_Pokal,Werder Bremen,Freiburg,3,2
Germany-DFB_Pokal,Bayern Munich,Borussia Dortmund,2,1
Italy-Serie_B,Venezia,Cremonese,1,1
Italy-Coppa_Italia,Juventus,Genoa,2,0
Italy-Coppa_Italia,Roma,Torino,1,2
Italy-Coppa_Italia,Atalanta,Sassuolo,2,1
Netherlands-KNVB_Cup,FC Twente,Ajax,7,6
Netherlands-KNVB_Cup,Fortuna Sittard,AZ Alkmaar,2,4
Netherlands-KNVB_Cup,PSV Eindhoven,VVV-Venlo,4,1
Scotland-Premiership,Celtic,Partick Thistle,2,0
Spain-Segunda_Division,Lorca FC,Osasuna,0,1
Spain-Segunda_Division,Cordoba,Reus,5,0
Spain-Segunda_Division,Granada,Sporting Gijon,2,1
Egypt-Premier_League,Al-Ittihad Al-Sakandary,El Zamalek,0,2
Egypt-Premier_League,Alassiouty,Wadi Degla FC,0,2
Egypt-Premier_League,Al Ahly,Smouha SC,2,1
International-Friendlies_U21,Qatar U21,Greece U21,0,0
Greece-Cup_Final_Stage,Platanias,Olympiacos,0,2
Greece-Cup_Final_Stage,Asteras Tripolis,Atromitos,0,1
Greece-Cup_Final_Stage,Panetolikos,AEK Athens,0,4
Italy-Serie_C_Grp__A,Cuneo,Robur Siena,2,0
Wales-Premier_League,Llandudno FC,Cardiff Met University,0,0
Bolivia-Primera_Division_Qualification,Universitario,Club Petrolero,1,0
Spain-Primera_Division,Eibar,Girona,4,1
Spain-Primera_Division,Alaves,Malaga,1,0
Australia-A_League,Brisbane Roar FC,Perth Glory,1,2
Belgium-First_Division_A,Royal Antwerp,Lokeren,1,2
Belgium-First_Division_A,Gent,Sporting Charleroi,1,0
Italy-Serie_B,Frosinone,Entella,4,3
Italy-Serie_B,Spezia,Avellino,1,0
Italy-Serie_B,Cittadella,Carpi,0,1
Italy-Serie_B,Novara,Perugia,1,1
Italy-Serie_B,Ascoli Picchio FC 1898,Pescara,1,1
Italy-Serie_B,Ternana,Pro Vercelli,4,3
Italy-Serie_B,Empoli,Brescia,1,1
Italy-Serie_B,Salernitana,Foggia,0,3
Italy-Serie_B,Bari,Parma Calcio 1913,0,0
Italy-Serie_B,Cesena,Palermo,1,1
Netherlands-KNVB_Cup,VVSB,Roda JC Kerkrade,0,1
Netherlands-KNVB_Cup,Feyenoord,Heracles,3,1
Spain-Segunda_Division,Tenerife,Cadiz,1,1
Spain-Segunda_Division,Numancia,Sevilla Atletico,3,0
Greece-Cup_Final_Stage,Levadiakos,PAS Giannina,1,0
Greece-Cup_Final_Stage,Lamia,Panathinaikos,4,1
Greece-Cup_Final_Stage,Panionios,OFI Crete,2,0
Greece-Cup_Final_Stage,AE Larissa,Xanthi,3,0
Portugal-Segunda_Liga,Real SC,Santa Clara,1,1
Portugal-Segunda_Liga,Benfica B,Braga B,1,0
Portugal-Segunda_Liga,Oliveirense,Leixoes,1,1
Portugal-Segunda_Liga,Sporting CP B,Vitoria de Guimaraes B,1,2
Portugal-Segunda_Liga,Famalicao,FC Porto B,0,3
Portugal-Segunda_Liga,Sporting Covilha,Gil Vicente,3,0
Portugal-Segunda_Liga,Academico Viseu,Penafiel,1,4
Spain-Segunda_B_Grp__III,Valencia B,Deportivo Aragon,1,1
Bolivia-Nacional_B_Final_Stage,Deportivo Kala,Royal Pari,1,4
Brazil-Carioca_Preliminary_Stage,America RJ,Bonsucesso FC,0,1
Chile-Primera_Division_Copa_Libertadores_Playoff,Union Espanola,Universidad de Concepcion,1,2
Chile-Primera_Division_Qualification,Santiago Wanderers,Union La Calera,4,6
Costa_Rica-Primera_Division_Apertura_Championship_Final,Municipal Perez Zeledon,Club Sport Herediano,1,0
Cyprus-1__Division,Nea Salamis,Doxa Katokopia,0,1
Cyprus-1__Division,Omonia Nicosia,Pafos FC,3,0
Cyprus-1__Division,Ermis Aradippou,Apollon Limassol,0,6
Cyprus-1__Division,Aris Limassol,Alki Oroklinis,0,0
England-Premier_League,Arsenal,Liverpool,3,3
Italy-Serie_A,ChievoVerona,Bologna,2,3
Italy-Serie_A,Cagliari,Fiorentina,0,1
Netherlands-Eredivisie,ADO Den Haag,PEC Zwolle,4,0
Spain-Primera_Division,Espanyol,Atletico Madrid,1,0
Spain-Primera_Division,Real Betis,Athletic Bilbao,0,2
Australia-A_League,Newcastle Jets,Western Sydney Wanderers FC,4,0
Belgium-First_Division_A,Anderlecht,Eupen,1,0
Belgium-First_Division_A,Waasland-Beveren,Oostende,1,3
England-Championship,Norwich City,Brentford,1,2
Netherlands-Eerste_Divisie,Telstar,De Graafschap,3,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,NEC Nijmegen,2,7
Netherlands-Eerste_Divisie,FC Dordrecht,Jong PSV,2,3
Netherlands-Eerste_Divisie,FC Oss,MVV Maastricht,1,0
Netherlands-Eerste_Divisie,Helmond Sport,Cambuur,3,0
Netherlands-Eerste_Divisie,Go Ahead Eagles,RKC Waalwijk,0,0
Netherlands-Eerste_Divisie,Almere City FC,FC Eindhoven,5,1
Netherlands-Eerste_Divisie,FC Emmen,FC Den Bosch,2,2
Netherlands-Eerste_Divisie,Jong Ajax,FC Volendam,7,0
N__Ireland-Premiership,Warrenpoint Town,Coleraine,0,2
N__Ireland-Premiership,Crusaders,Ballymena United,2,1
Spain-Segunda_Division,Alcorcon,Almeria,2,0
Spain-Segunda_Division,Lugo,Rayo Vallecano,1,2
Turkey-Super_Lig,Antalyaspor,Alanyaspor,3,1
Egypt-Premier_League,ENPPI,Al Masry,2,1
England-League_1,Fleetwood Town,Gillingham,0,2
England-League_2,Coventry City,Wycombe Wanderers,3,2
International-Gulf_Cup_Grp__A,Kuwait,Saudi Arabia,1,2
International-Gulf_Cup_Grp__A,U.A.E.,Oman,1,0
Italy-Serie_C_Grp__B,FeralpiSalo,Reggiana,3,2
Italy-Serie_C_Grp__B,Pordenone Calcio,Santarcangelo,0,1
Italy-Serie_C_Grp__B,Fermana,Ravenna,0,0
Italy-Serie_C_Grp__B,Calcio Padova,Renate,2,1
Italy-Serie_C_Grp__B,Teramo,Mestre,2,0
Italy-Serie_C_Grp__B,Gubbio,Vicenza,1,1
Italy-Serie_C_Grp__B,Bassano Virtus,Alma Juventus Fano,1,0
Italy-Serie_C_Grp__B,AlbinoLeffe,Sudtirol,1,1
Italy-Serie_C_Grp__C,Akragas,Matera,1,1
Portugal-Segunda_Liga,Nacional,Arouca,2,2
Portugal-Segunda_Liga,Cova da Piedade,Academica,2,1
England-Premier_League,Burnley,Tottenham Hotspur,0,3
England-Premier_League,West Ham United,Newcastle United,2,3
England-Premier_League,Brighton &amp; Hove Albion,Watford,1,0
England-Premier_League,Stoke City,West Bromwich Albion,3,1
England-Premier_League,Leicester City,Manchester United,2,2
England-Premier_League,Manchester City,AFC Bournemouth,4,0
England-Premier_League,Everton,Chelsea,0,0
England-Premier_League,Swansea City,Crystal Palace,1,1
England-Premier_League,Southampton,Huddersfield Town,1,1
Italy-Serie_A,SSC Napoli,Sampdoria,3,2
Italy-Serie_A,Udinese,Hellas Verona,4,0
Italy-Serie_A,AC Milan,Atalanta,0,2
Italy-Serie_A,Sassuolo,Inter,1,0
Italy-Serie_A,Lazio,Crotone,4,0
Italy-Serie_A,Juventus,Roma,1,0
Italy-Serie_A,Genoa,Benevento,1,0
Italy-Serie_A,SPAL 2013,Torino,2,2
Netherlands-Eredivisie,Excelsior,FC Twente,0,0
Netherlands-Eredivisie,AZ Alkmaar,SC Heerenveen,3,1
Netherlands-Eredivisie,PSV Eindhoven,Vitesse,2,1
Netherlands-Eredivisie,NAC Breda,FC Utrecht,3,1
Portugal-Primeira_Liga,Vitoria de Guimaraes,Tondela,0,1
Spain-Primera_Division,Valencia,Villarreal,0,1
Spain-Primera_Division,Real Madrid,Barcelona,0,3
Spain-Primera_Division,Deportivo La Coruna,Celta Vigo,1,3
Australia-A_League,Wellington Phoenix,Sydney FC,1,4
Australia-A_League,Melbourne City FC,Melbourne Victory,0,1
Belgium-First_Division_A,Genk,Kortrijk,2,3
Belgium-First_Division_A,Standard Liege,St.Truiden,1,1
Belgium-First_Division_A,Royal Excel Mouscron,Zulte-Waregem,2,1
England-Championship,Preston North End,Nottingham Forest,1,1
England-Championship,Sheffield Wednesday,Middlesbrough,1,2
England-Championship,Fulham,Barnsley,2,1
England-Championship,Queens Park Rangers,Bristol City,1,1
England-Championship,Aston Villa,Sheffield United,2,2
England-Championship,Sunderland,Birmingham City,1,1
England-Championship,Bolton Wanderers,Cardiff City,2,0
England-Championship,Leeds United,Hull City,1,0
England-Championship,Reading,Burton Albion,1,2
England-Championship,Wolverhampton Wanderers,Ipswich Town,1,0
Netherlands-Eredivisie,FC Groningen,Sparta Rotterdam,4,0
Netherlands-Eredivisie,Ajax,Willem II,3,1
Netherlands-Eredivisie,VVV-Venlo,Heracles,3,1
Netherlands-Eredivisie,Feyenoord,Roda JC Kerkrade,5,1
Israel-Ligat_HaAl,FC Ashdod,Beitar Jerusalem,1,3
Israel-Ligat_HaAl,Hapoel Raanana,Bnei Sakhnin,1,1
Turkey-Super_Lig,Kayserispor,Yeni Malatyaspor,0,1
Turkey-Super_Lig,Galatasaray,Goztepe,3,1
Turkey-Super_Lig,Kasimpasa,Istanbul Basaksehir,1,2
Turkey-Super_Lig,Karabukspor,Trabzonspor,1,1
Egypt-Premier_League,Smouha SC,El Entag El Harby,2,1
Egypt-Premier_League,Petrojet,Alassiouty,1,2
Turkey-1__Lig,Manisaspor,Balikesirspor,3,1
Turkey-1__Lig,Denizlispor,Boluspor,1,1
Turkey-1__Lig,Umraniyespor,Samsunspor,4,2
Turkey-1__Lig,Erzurum BB,Altinordu,2,1
Costa_Rica-Primera_Division_Apertura_Championship_Final,Club Sport Herediano,Municipal Perez Zeledon,0,0
DR_Congo-Super_League_Zone_South_Central,J.S. Bazano,Ecofoot Katumbi,0,0
Iran-Persian_Gulf_Pro_League,Foolad Khuzestan,Persepolis,1,1
Iran-Persian_Gulf_Pro_League,Tractor Sazi Tabriz,Esteghlal Khuzestan,3,0
Iran-Persian_Gulf_Pro_League,Esteghlal,Sanat Naft Abadan,4,0
Iran-Persian_Gulf_Pro_League,Pars Jonoubi Jam Bushehr,Gostaresh Foolad FC,0,2
Kenya-Premier_League_Qualification,Ushuru FC,Thika United,0,0
Morocco-Botola_Pro,Raja Casablanca,Chabab Rif Al Hoceima,1,1
Morocco-Botola_Pro,OCK Khouribga,RSB Berkane,1,0
Morocco-Botola_Pro,KACM,MAT Tetouan,0,0
Morocco-Elite_2,USM Oujda,Club Jeunesse Ben Guerir,0,1
Morocco-Elite_2,JSK Chabab Kasba Tadla,JSM Laayoune,2,2
Morocco-Elite_2,IZK,MCO Oujda,2,2
Saudi_Arabia-Premier_League,Al Ittihad,Al Feiha,0,1
Saudi_Arabia-Premier_League,Al Hilal,Al-Taawon,1,0
Tunisia-Ligue_I,CA Bizertin,Stade Tunisien,3,1
Tunisia-Ligue_I,Etoile du Sahel,Stade Gabesien,2,0
International-Friendlies,Jordan,Libya,1,1
Israel-Ligat_HaAl,Hapoel Beer Sheva,Maccabi Haifa,2,0
Turkey-Super_Lig,Osmanlispor FK,Akhisar Belediye Genclik Ve Spor,3,2
Egypt-Premier_League,Wadi Degla FC,Al Ahly,1,1
Egypt-Premier_League,El Geish,Al-Ittihad Al-Sakandary,0,0
International-Gulf_Cup_Grp__A,Kuwait,Oman,0,1
International-Gulf_Cup_Grp__A,U.A.E.,Saudi Arabia,0,0
Israel-Leumit_League,Hapoel Katamon Jerusalem,Hapoel Ramat Gan,0,1
Israel-Leumit_League,Hapoel Afula,Beitar Tel Aviv Ramla,1,1
Israel-Leumit_League,Hapoel Tel Aviv,Hapoel Petah Tikva,0,1
Morocco-Botola_Pro,Hassania Agadir,Wydad Casablanca,1,0
Morocco-Elite_2,Union Sidi Kacem,MAS Fes,2,0
England-Premier_League,Chelsea,Brighton &amp; Hove Albion,2,0
England-Premier_League,Watford,Leicester City,2,1
England-Premier_League,Tottenham Hotspur,Southampton,5,2
England-Premier_League,Huddersfield Town,Stoke City,1,1
England-Premier_League,West Bromwich Albion,Everton,0,0
England-Premier_League,AFC Bournemouth,West Ham United,3,3
England-Premier_League,Liverpool,Swansea City,5,0
England-Premier_League,Manchester United,Burnley,2,2
Australia-A_League,Adelaide United,Central Coast Mariners,1,0
Belgium-First_Division_A,Club Brugge,Royal Excel Mouscron,4,2
Belgium-First_Division_A,Anderlecht,Gent,1,0
Belgium-First_Division_A,Eupen,Waasland-Beveren,1,0
Belgium-First_Division_A,Zulte-Waregem,Sporting Charleroi,0,4
Belgium-First_Division_A,Lokeren,KV Mechelen,2,0
England-Championship,Burton Albion,Leeds United,1,2
England-Championship,Ipswich Town,Queens Park Rangers,0,0
England-Championship,Birmingham City,Norwich City,0,2
England-Championship,Sheffield United,Sunderland,3,0
England-Championship,Millwall,Wolverhampton Wanderers,2,2
England-Championship,Cardiff City,Fulham,2,4
England-Championship,Middlesbrough,Bolton Wanderers,2,0
England-Championship,Bristol City,Reading,2,0
England-Championship,Hull City,Derby County,0,0
England-Championship,Brentford,Aston Villa,2,1
England-Championship,Barnsley,Preston North End,0,0
England-Championship,Nottingham Forest,Sheffield Wednesday,0,3
Italy-Coppa_Italia,Lazio,Fiorentina,1,0
N__Ireland-Premiership,Ballinamallard United,Dungannon Swifts,0,1
N__Ireland-Premiership,Coleraine,Ballymena United,1,1
N__Ireland-Premiership,Glentoran,Linfield,2,1
N__Ireland-Premiership,Ards,Carrick Rangers,1,0
N__Ireland-Premiership,Crusaders,Cliftonville,2,0
N__Ireland-Premiership,Glenavon,Warrenpoint Town,1,0
Scotland-Premiership,Dundee FC,Celtic,0,2
Turkey-Cup,Galatasaray,Bucaspor,3,0
Turkey-Cup,Genclerbirligi,Bursaspor,1,0
Egypt-Premier_League,El Zamalek,Al Mokawloon Al Arab,1,0
England-League_1,Southend United,Charlton Athletic,3,1
England-League_1,Blackpool,Scunthorpe United,2,3
England-League_1,Wigan Athletic,Shrewsbury Town,0,0
England-Premier_League,Newcastle United,Manchester City,0,1
Belgium-First_Division_A,St.Truiden,Royal Antwerp,0,3
Belgium-First_Division_A,Kortrijk,Standard Liege,2,1
Italy-Serie_B,Parma Calcio 1913,Spezia,0,0
Italy-Coppa_Italia,AC Milan,Inter,1,0
Scotland-Premiership,Rangers,Motherwell,2,0
Scotland-Premiership,Aberdeen,Partick Thistle,1,0
Scotland-Premiership,Ross County,St.Johnstone,1,1
Scotland-Premiership,Hearts,Hibernian,0,0
Turkey-Cup,Fenerbahce,Istanbulspor,2,0
Turkey-Cup,Kayserispor,Antalyaspor,3,1
Turkey-Cup,Giresunspor,Istanbul Basaksehir,3,1
Turkey-Cup,Konyaspor,Trabzonspor,1,0
Egypt-Premier_League,Ismaily SC,El Raja Marsa Matruh,5,0
Egypt-Premier_League,ENPPI,Al Nasr,1,1
Brazil-Carioca_Preliminary_Stage,Bonsucesso FC,Macae,0,1
DR_Congo-Super_League_Zone_South_Central,Sanga Balende,FC Lubumbashi Sport,0,0
DR_Congo-Super_League_Zone_South_Central,Ecofoot Katumbi,Dibumba,1,0
DR_Congo-Super_League_Zone_South_Central,Tshinkunku,Saint-Eloi Lupopo,0,1
DR_Congo-Super_League_Zone_South_Central,TP Mazembe,J.S. Bazano,3,1
DR_Congo-Super_League_Zone_West,Motema Pembe,Dragons,1,0
England-Isthmian_Premier_Division,Metropolitan Police FC,Leatherhead,1,2
India-I_League,East Bengal Club,Gokulam FC,1,0
India-I_League,Aizawl,Minerva Punjab,2,1
Ivory_Coast-Ligue_1,San Pedro,Moossou FC,1,1
Morocco-Botola_Pro,MAT Tetouan,Ittihad Tanger,0,1
Morocco-Botola_Pro,Racing de Casablanca,OCK Khouribga,2,1
Morocco-Botola_Pro,Chabab Rif Al Hoceima,KACM,1,0
Morocco-Botola_Pro,Rapide Club Oued Zem,Chabab Atlas Khenifra,1,0
Morocco-Botola_Pro,FAR Rabat,FUS Rabat,0,0
Morocco-Botola_Pro,RSB Berkane,Raja Casablanca,1,0
Saudi_Arabia-Premier_League,Al Batin,Al Shabab,0,1
Tunisia-Ligue_I,Esperance,Club Olympique de Medenine,3,1
Tunisia-Ligue_I,Etoile du Sahel,CA Bizertin,3,2
Tunisia-Ligue_I,US Monastir,CS Sfaxien,1,0
England-Premier_League,Crystal Palace,Arsenal,2,3
Italy-Serie_B,Palermo,Salernitana,3,0
Italy-Serie_B,Brescia,Ascoli Picchio FC 1898,0,1
Italy-Serie_B,Cremonese,Cesena,1,0
Italy-Serie_B,Avellino,Ternana,2,1
Italy-Serie_B,Pescara,Venezia,1,0
Italy-Serie_B,Entella,Novara,2,1
Italy-Serie_B,Perugia,Empoli,2,4
Italy-Serie_B,Carpi,Bari,0,0
Italy-Serie_B,Pro Vercelli,Cittadella,1,2
Italy-Serie_B,Foggia,Frosinone,1,2
Turkey-Cup,Besiktas,Osmanlispor FK,4,1
Turkey-Cup,Boluspor,Akhisar Belediye Genclik Ve Spor,2,1
Egypt-Premier_League,Al Masry,Tanta,6,3
International-Gulf_Cup_Grp__A,Saudi Arabia,Oman,0,2
International-Gulf_Cup_Grp__A,Kuwait,U.A.E.,0,0
Australia-National_Youth_League,Adelaide United Youth,Perth Glory Youth,2,2
Bolivia-Primera_Division_Qualification,Destroyers,Club Petrolero,1,1
Brazil-Carioca_Preliminary_Stage,Resende,America RJ,3,2
Brazil-Carioca_Preliminary_Stage,Goytacaz,AD Cabofriense,1,1
DR_Congo-Super_League_Zone_East,Virunga,Dauphins Noirs,1,2
DR_Congo-Super_League_Zone_East,Maniema Union,Bukavu Dawa,0,0
Honduras-Liga_Nacional___Apertura_Final_Stage,Real Espana,CD Motagua,2,0
Hong_Kong-Premier_League,Eastern Sports Club,Hong Kong Sapling,0,1
India-Indian_Super_League,Jamshedpur,Chennaiyin FC,0,1
Iran-Persian_Gulf_Pro_League,Esteghlal Khuzestan,Esteghlal,0,3
Ivory_Coast-Ligue_1,SO Armee,Africa Sports,1,0
Ivory_Coast-Ligue_1,ASI D'Abengourou,Bouake FC,1,0
Ivory_Coast-Ligue_1,Academia F. Amadou Diallo,Bassam,1,3
Ivory_Coast-Ligue_1,Williamsville Athletic Club,Stade d'Abidjan,1,0
Ivory_Coast-Ligue_1,Sewe Sport,AS Tanda,1,1
Jamaica-Premier_League,Montego Bay United FC,Cavalier SC,0,1
Jamaica-Premier_League,Portmore United,UWI FC,5,1
Jamaica-Premier_League,Tivoli Gardens,Reno FC,2,0
Jamaica-Premier_League,Boys Town,Arnett Gardens,1,1
Jamaica-Premier_League,Sandals South Coast,Humble Lions,1,0
Morocco-Botola_Pro,Wydad Casablanca,Olympic Club de Safi,0,1
Morocco-Botola_Pro,Difaa El Jadida,Hassania Agadir,1,0
Saudi_Arabia-Premier_League,Al Ittihad,Al-Faisaly,3,3
Saudi_Arabia-Premier_League,Al-Raed,Al Fateh FC,2,2
Italy-Serie_A,Crotone,SSC Napoli,0,1
Australia-A_League,Melbourne Victory,Newcastle Jets,2,1
England-Championship,Millwall,Queens Park Rangers,1,0
England-Championship,Cardiff City,Preston North End,0,1
N__Ireland-Premiership,Carrick Rangers,Ballinamallard United,2,2
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Misr El-Maqasa,2,2
Egypt-Premier_League,Al Ahly,Petrojet,3,0
England-League_1,Doncaster Rovers,Rochdale,2,0
England-League_1,Wigan Athletic,Charlton Athletic,0,0
England-League_2,Morecambe,Yeovil Town,4,3
International-Gulf_Cup_Grp__B,Iraq,Yemen,3,0
International-Gulf_Cup_Grp__B,Qatar,Bahrain,1,1
Italy-Serie_C_Grp__B,Renate,FeralpiSalo,2,1
Italy-Serie_C_Grp__B,Mestre,AlbinoLeffe,2,1
Italy-Serie_C_Grp__B,Sambenedettese,Fermana,3,0
Italy-Serie_C_Grp__B,Reggiana,Triestina,2,0
Italy-Serie_C_Grp__B,Ravenna,Bassano Virtus,1,2
Italy-Serie_C_Grp__B,Alma Juventus Fano,Calcio Padova,1,1
Italy-Serie_C_Grp__B,Santarcangelo,Gubbio,1,0
Italy-Serie_C_Grp__C,Trapani,Lecce,1,1
Scotland-Championship,St. Mirren,Dundee United,2,0
Wales-Premier_League,Connah's Quay,Cefn Druids AFC,1,1
Australia-National_Youth_League,Brisbane Roar FC Youth,Melbourne City FC Youth,0,3
Australia-National_Youth_League,Sydney FC Youth,Canberra United Youth,3,0
DR_Congo-Super_League_Zone_East,CS Makiso,Muungano,0,0
DR_Congo-Super_League_Zone_West,AS Vita Club,FC MK,2,0
DR_Congo-Super_League_Zone_West,Molunge,AC Rangers,0,1
India-I_League,Mohun Bagan,Indian Arrows,1,1
India-Indian_Super_League,Mumbai City FC,Delhi Dynamos FC,4,0
Iran-Persian_Gulf_Pro_League,Persepolis,Tractor Sazi Tabriz,2,0
Iran-Persian_Gulf_Pro_League,Sepahan,Padideh FC,4,0
Iran-Persian_Gulf_Pro_League,Paykan,Pars Jonoubi Jam Bushehr,1,1
Iran-Persian_Gulf_Pro_League,Meshki Pooshan,Sepidrood Rasht,2,0
Iran-Persian_Gulf_Pro_League,Sanat Naft Abadan,Saipa,3,0
Iran-Persian_Gulf_Pro_League,Gostaresh Foolad FC,Zob Ahan,0,1
Iran-Persian_Gulf_Pro_League,Naft Tehran,Foolad Khuzestan,1,2
Israel-Leumit_League,Hapoel Katamon Jerusalem,Hapoel Petah Tikva,1,1
Israel-Leumit_League,Hapoel Afula,Maccabi Herzliya,1,1
Israel-Leumit_League,Hapoel Tel Aviv,Hapoel Rishon LeZion,0,1
Israel-Leumit_League,Hapoel Marmorek,Hapoel Nazareth Illit,1,2
England-Premier_League,Chelsea,Stoke City,5,0
England-Premier_League,Liverpool,Leicester City,2,1
England-Premier_League,Manchester United,Southampton,0,0
England-Premier_League,Watford,Swansea City,1,2
England-Premier_League,Newcastle United,Brighton &amp; Hove Albion,0,0
England-Premier_League,AFC Bournemouth,Everton,2,1
England-Premier_League,Huddersfield Town,Burnley,0,0
Italy-Serie_A,Roma,Sassuolo,1,1
Italy-Serie_A,Atalanta,Cagliari,1,2
Italy-Serie_A,Sampdoria,SPAL 2013,2,0
Italy-Serie_A,Inter,Lazio,0,0
Italy-Serie_A,Fiorentina,AC Milan,1,1
Italy-Serie_A,Bologna,Udinese,1,2
Italy-Serie_A,Torino,Genoa,0,0
Italy-Serie_A,Benevento,ChievoVerona,1,0
Italy-Serie_A,Hellas Verona,Juventus,1,3
Australia-A_League,Sydney FC,Perth Glory,6,0
Australia-A_League,Adelaide United,Brisbane Roar FC,1,2
England-Championship,Sheffield United,Bolton Wanderers,0,1
England-Championship,Brentford,Sheffield Wednesday,2,0
England-Championship,Nottingham Forest,Sunderland,0,1
England-Championship,Middlesbrough,Aston Villa,0,1
England-Championship,Barnsley,Reading,1,1
England-Championship,Birmingham City,Leeds United,1,0
England-Championship,Hull City,Fulham,2,2
England-Championship,Bristol City,Wolverhampton Wanderers,1,2
England-Championship,Ipswich Town,Derby County,1,2
England-Championship,Burton Albion,Norwich City,0,0
Israel-Ligat_HaAl,Maccabi Haifa,Hapoel Ironi Akko,0,1
Israel-Ligat_HaAl,Beitar Jerusalem,Maccabi Petach Tikva,1,0
Israel-Ligat_HaAl,Maccabi Netanya,Hapoel Raanana,2,2
Israel-Ligat_HaAl,Bnei Yehuda Tel Aviv,Hapoel Haifa,0,1
N__Ireland-Premiership,Warrenpoint Town,Ards,3,3
N__Ireland-Premiership,Cliftonville,Coleraine,0,0
N__Ireland-Premiership,Dungannon Swifts,Glentoran,0,0
N__Ireland-Premiership,Ballymena United,Glenavon,3,1
N__Ireland-Premiership,Linfield,Crusaders,1,2
Scotland-Premiership,Celtic,Rangers,0,0
Scotland-Premiership,Hibernian,Kilmarnock,1,1
Scotland-Premiership,Aberdeen,Hearts,0,0
England-Premier_League,Leicester City,Huddersfield Town,3,0
England-Premier_League,Stoke City,Newcastle United,0,1
England-Premier_League,Brighton &amp; Hove Albion,AFC Bournemouth,2,2
England-Premier_League,Everton,Manchester United,0,2
England-Premier_League,Burnley,Liverpool,1,2
Australia-A_League,Western Sydney Wanderers FC,Melbourne City FC,2,1
England-Championship,Sheffield Wednesday,Burton Albion,0,3
England-Championship,Leeds United,Nottingham Forest,0,0
England-Championship,Norwich City,Millwall,2,1
England-Championship,Sunderland,Barnsley,0,1
England-Championship,Derby County,Sheffield United,1,1
England-Championship,Aston Villa,Bristol City,5,0
England-Championship,Queens Park Rangers,Cardiff City,2,1
England-Championship,Preston North End,Middlesbrough,2,3
England-Championship,Bolton Wanderers,Hull City,1,0
Israel-Ligat_HaAl,Bnei Sakhnin,Maccabi Tel Aviv,0,1
N__Ireland-Premiership,Ballinamallard United,Crusaders,0,3
England-League_1,Scunthorpe United,Bury,1,0
England-League_1,Charlton Athletic,Gillingham,1,2
England-League_1,Shrewsbury Town,Oldham Athletic,1,0
England-League_1,Oxford United,Milton Keynes Dons,3,1
England-League_1,Rochdale,Blackpool,1,2
England-League_1,AFC Wimbledon,Southend United,2,0
England-League_1,Peterborough United,Doncaster Rovers,1,1
England-League_1,Plymouth Argyle,Walsall,1,0
England-League_1,Bristol Rovers,Portsmouth,2,1
England-League_1,Fleetwood Town,Bradford City,1,2
England-League_1,Rotherham United,Blackburn Rovers,1,1
England-League_1,Northampton Town,Wigan Athletic,0,1
England-League_2,Coventry City,Chesterfield,1,0
England-League_2,Accrington Stanley,Morecambe,1
England-League_2,Luton Town,Lincoln City,4,2
England-League_2,Colchester United,Cambridge United,0,0
England-League_2,Notts County,Port Vale,1,0
England-League_2,Mansfield Town,Carlisle United,3,1
England-League_2,Newport County,Exeter City,2,1
England-League_2,Yeovil Town,Crawley Town,1,2
England-League_2,Crewe Alexandra,Grimsby Town,2,0
England-League_2,Stevenage,Cheltenham Town,4,1
England-League_2,Barnet,Swindon Town,1,2
England-Premier_League,Manchester City,Watford,3,1
England-Premier_League,Southampton,Crystal Palace,1,2
England-Premier_League,West Ham United,West Bromwich Albion,2,1
England-Premier_League,Swansea City,Tottenham Hotspur,0,2
England-Championship,Fulham,Ipswich Town,4,1
England-Championship,Wolverhampton Wanderers,Brentford,3,0
England-Championship,Reading,Birmingham City,0,2
Italy-Coppa_Italia,SSC Napoli,Atalanta,1,2
N__Ireland-Premiership,Glentoran,Warrenpoint Town,1
N__Ireland-Premiership,Cliftonville,Ballymena United,1
N__Ireland-Premiership,Ards,Glenavon,2
Egypt-Premier_League,Al Nasr,Al Ahly,0,4
International-Gulf_Cup_Final_Stage,Oman,Bahrain,1,0
International-Gulf_Cup_Final_Stage,Iraq,U.A.E.,2,4
Scotland-Championship,Dundee United,Brechin City,4,1
Scotland-Championship,Queen of South,Dumbarton,0,0
Scotland-Championship,Dunfermline Athletic,Falkirk,2,0
Scotland-Championship,Inverness CT,Livingston,1,1
Scotland-Championship,Greenock Morton,St. Mirren,1,1
Scotland-League_One,Alloa Athletic,Queen's Park,2,2
Scotland-League_One,Albion Rovers,Airdrieonians,2,2
Scotland-League_One,East Fife,Raith Rovers,2,3
Scotland-League_One,Stranraer,Ayr United,1,5
Scotland-League_One,Forfar Athletic,Arbroath,0,1
Wales-Premier_League,Bala Town,TNS,0,3
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Agua Santa U20,Espirito Santo U20,2,2
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Vasco da Gama U20,Juventus SP U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__27,Taubate U20,Moto Club MA U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__4,Santos SP U20,America RN U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__4,Novorizontino U20,Alianca U20,3,0
Cyprus-1__Division,Ethnikos Achnas,Ermis Aradippou,0,0
Cyprus-1__Division,Doxa Katokopia,Anorthosis,0,0
Cyprus-1__Division,Alki Oroklinis,Omonia Nicosia,0,3
India-I_League,Mohun Bagan,Chennai City FC,1,2
India-I_League,Indian Arrows,East Bengal Club,0,2
Scotland-League_Two,Peterhead,Elgin City,7,0
Scotland-League_Two,Montrose,Cowdenbeath,1,1
Scotland-League_Two,Stenhousemuir,Stirling Albion,2,1
Scotland-League_Two,Edinburgh City,Berwick Rangers,3,0
Scotland-League_Two,Clyde,Annan Athletic,0,0
England-Premier_League,Arsenal,Chelsea,2,2
Portugal-Primeira_Liga,Rio Ave,Pacos de Ferreira,4,2
Portugal-Primeira_Liga,Aves,Moreirense,1,2
Portugal-Primeira_Liga,Benfica,Sporting CP,1,1
Portugal-Primeira_Liga,Maritimo,Chaves,1,2
Portugal-Primeira_Liga,Boavista,Braga,1,3
Portugal-Primeira_Liga,Feirense,FC Porto,1,2
Australia-A_League,Sydney FC,Newcastle Jets,2,2
Italy-Coppa_Italia,Juventus,Torino,2,0
Spain-Copa_del_Rey,Las Palmas,Valencia,1,1
Spain-Copa_del_Rey,SD Formentera,Alaves,1,3
Spain-Copa_del_Rey,Cadiz,Sevilla,0,2
Spain-Copa_del_Rey,Lleida Esportiu,Atletico Madrid,0,4
Egypt-Premier_League,El Geish,El Zamalek,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__1,Fernandopolis U20,Madureira RJ U20,1,2
Brazil-Sao_Paulo_Youth_Cup_Grp__1,Criciuma U20,Guarani U20,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__10,Botafogo SP U20,Sergipe U20,2,1
Brazil-Sao_Paulo_Youth_Cup_Grp__10,Sao Paulo U20,Cruzeiro DF U20,6,2
Brazil-Sao_Paulo_Youth_Cup_Grp__11,Comercial SP U20,Rio Branco SP U20,2,1
Brazil-Sao_Paulo_Youth_Cup_Grp__11,Parana Clube U20,Juventude U20,2,1
Brazil-Sao_Paulo_Youth_Cup_Grp__13,Capivariano U20,River AC U20,0,3
Brazil-Sao_Paulo_Youth_Cup_Grp__14,Paysandu U20,Londrina EC U20,1,2
Brazil-Sao_Paulo_Youth_Cup_Grp__14,Desportivo Brasil U20,Uniao Rondonopolis U20,3,1
Brazil-Sao_Paulo_Youth_Cup_Grp__15,Vitoria BA U20,Atibaia U20,5,2
Brazil-Sao_Paulo_Youth_Cup_Grp__15,Primavera SP U20,Globo FC U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__16,Vila Nova U20,XV de Piracicaba U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__16,Ituano U20,Santa Cruz AL U20,4,0
Brazil-Sao_Paulo_Youth_Cup_Grp__2,Votuporanguense U20,Timon U20,3,1
Brazil-Sao_Paulo_Youth_Cup_Grp__2,Atletico PR U20,Rio Preto U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__21,Oeste FC U20,CE Aimore U20,2,2
Brazil-Sao_Paulo_Youth_Cup_Grp__22,Coritiba U20,Comercial MS U20,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__22,Elosport U20,Atlantico EC U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__25,Ceara U20,Sao Caetano U20,3,2
Brazil-Sao_Paulo_Youth_Cup_Grp__25,Sao Bernardo U20,Rio Branco AC U20,3,1
Brazil-Sao_Paulo_Youth_Cup_Grp__27,Palmeiras U20,Luverdense U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__28,Bahia U20,Sao Bento U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__28,Manthiqueira U20,Botafogo PB U20,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__29,Goias U20,Guarulhos U20,4,0
Brazil-Sao_Paulo_Youth_Cup_Grp__29,Flamengo SP U20,SS Sete de Setembro U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__3,Jose Bonifacio U20,America PE U20,2,3
England-Premier_League,Tottenham Hotspur,West Ham United,1,1
Portugal-Primeira_Liga,Portimonense,Belenenses,0,0
Portugal-Primeira_Liga,Vitoria de Setubal,Estoril,2,2
Spain-Copa_del_Rey,Espanyol,Levante,1,2
Spain-Copa_del_Rey,Leganes,Villarreal,1,0
Spain-Copa_del_Rey,Celta Vigo,Barcelona,1,1
Spain-Copa_del_Rey,Numancia,Real Madrid,0,3
International-Club_Friendlies,Malaga,Hamburger SV,1,2
Egypt-Premier_League,Misr El-Maqasa,Al Mokawloon Al Arab,0,2
Egypt-Premier_League,El Raja Marsa Matruh,Al-Ittihad Al-Sakandary,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__12,Inter de Bebedouro U20,Nova Iguacu U20,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__12,Cruzeiro U20,Batatais U20,2,1
Brazil-Sao_Paulo_Youth_Cup_Grp__13,Botafogo RJ U20,Velo Clube U20,3,1
Brazil-Sao_Paulo_Youth_Cup_Grp__13,Botafogo RJ U20,Confianca SE U20,
Brazil-Sao_Paulo_Youth_Cup_Grp__17,Ferroviaria U20,Pinheiro MA U20,6,1
Brazil-Sao_Paulo_Youth_Cup_Grp__18,Sport U20,Confianca SE U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__18,Sport U20,Linense U20,
Brazil-Sao_Paulo_Youth_Cup_Grp__18,Sao Carlos U20,Sao Raimundo RR U20,4,2
Brazil-Sao_Paulo_Youth_Cup_Grp__19,Itapirense U20,Estanciano EC U20,3,2
Brazil-Sao_Paulo_Youth_Cup_Grp__20,Paulista FC U20,EC Sao Jose U20,0,1
Brazil-Sao_Paulo_Youth_Cup_Grp__20,Avai U20,Red Bull Brasil U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__21,Flamengo U20,Ji-Parana FC U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__23,Atletico MG U20,Uniao Barbarense U20,4,0
Brazil-Sao_Paulo_Youth_Cup_Grp__23,Audax Sao Paulo U20,Rio Branco ES U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__23,Atletico MG U20,Fast Clube U20,
Brazil-Sao_Paulo_Youth_Cup_Grp__24,Joinville U20,Real FC U20,4,2
Brazil-Sao_Paulo_Youth_Cup_Grp__24,Taboao da Serra U20,Sao Paulo Crystal U20,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__6,Osvaldo Cruz U20,Capital TO U20,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__6,Internacional U20,Boavista U20,2,0
India-Indian_Super_League,Kerala Blasters FC,FC Pune City,1,1
Iran-Persian_Gulf_Pro_League,Foolad Khuzestan,Meshki Pooshan,1,1
Iran-Persian_Gulf_Pro_League,Pars Jonoubi Jam Bushehr,Sepahan,0,0
Jamaica-Premier_League,Cavalier SC,Sandals South Coast,2,1
Jamaica-Premier_League,Reno FC,Portmore United,0,0
Jamaica-Premier_League,UWI FC,Montego Bay United FC,1,1
Jamaica-Premier_League,Humble Lions,Waterhouse FC,0,0
Morocco-Botola_Pro,RSB Berkane,Wydad Casablanca,2,1
England-FA_Cup,Manchester United,Derby County,2,0
England-FA_Cup,Liverpool,Everton,2,1
Italy-Serie_A,Fiorentina,Inter,1,1
Italy-Serie_A,ChievoVerona,Udinese,1,1
Australia-A_League,Brisbane Roar FC,Western Sydney Wanderers FC,0,2
Australia-A_League,Perth Glory,Adelaide United,0,3
Belgium-First_Division_B_2nd_Stage,Cercle Brugge,Oud-Heverlee,1,0
International-Club_Friendlies,Bayer Leverkusen,Greuther Fuerth,2,1
International-Club_Friendlies,Wolfsburg,St. Pauli,3,1
Egypt-Premier_League,Wadi Degla FC,El Dakhleya,1,2
Egypt-Premier_League,Smouha SC,Al Masry,3,2
Egypt-Premier_League,Petrojet,El Entag El Harby,1,0
Egypt-Premier_League,Tanta,ENPPI,0,1
International-Gulf_Cup_Final_Stage,Oman,U.A.E.,5,4
Wales-Premier_League,Bangor City,Newtown,3,1
Wales-Premier_League,Prestatyn Town FC,TNS,1,4
Algeria-Ligue_1,USM El Harrach,ES Setif,0,0
Algeria-Ligue_1,JS Saoura,JS Kabylie,2,0
Algeria-Ligue_1,DRB Tadjenanet,Olympique de Medea,0,0
Brazil-Copa_do_Nordeste_Qualification,EC Cordino,Treze,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__17,Corinthians U20,Corumbaense U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__19,Fortaleza U20,Volta Redonda U20,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Agua Santa U20,Juventus SP U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Espirito Santo U20,Vasco da Gama U20,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__27,Taubate U20,Luverdense U20,3,0
Brazil-Sao_Paulo_Youth_Cup_Grp__30,Uniao Mogi U20,Bragantino U20,1,2
Brazil-Sao_Paulo_Youth_Cup_Grp__32,Portuguesa U20,Remo U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Grp__32,Teixeira de Freitas U20,America MG U20,0,1
Brazil-Sao_Paulo_Youth_Cup_Grp__4,Alianca U20,Santos SP U20,0,3
Brazil-Sao_Paulo_Youth_Cup_Grp__4,Novorizontino U20,America RN U20,2,0
Cyprus-2__Division,E.N.TH.O.I. Lakatamias,ASIL Lysi,1,2
Cyprus-2__Division,PAEEK,AEZ Zakakiou,1,2
DR_Congo-Super_League_Zone_West,FC MK,Motema Pembe,0,2
India-I_League,Neroca FC,Indian Arrows,2,1
India-I_League,Shillong Lajong,Chennai City FC,0,0
India-Indian_Super_League,Jamshedpur,Mumbai City FC,2,2
Iran-Persian_Gulf_Pro_League,Persepolis,Naft Tehran,0,0
Iran-Persian_Gulf_Pro_League,Saipa,Esteghlal Khuzestan,3,2
Iran-Persian_Gulf_Pro_League,Padideh FC,Sanat Naft Abadan,1,0
Iran-Persian_Gulf_Pro_League,Zob Ahan,Paykan,2,1
England-FA_Cup,Manchester City,Burnley,4,1
England-FA_Cup,Watford,Bristol City,3,0
England-FA_Cup,Newcastle United,Luton Town,3,1
England-FA_Cup,Cardiff City,Mansfield Town,0,0
England-FA_Cup,Brentford,Notts County,0,1
England-FA_Cup,Aston Villa,Peterborough United,1,3
England-FA_Cup,Middlesbrough,Sunderland,2,0
England-FA_Cup,Queens Park Rangers,Milton Keynes Dons,0,1
England-FA_Cup,Wolverhampton Wanderers,Swansea City,0,0
England-FA_Cup,Doncaster Rovers,Rochdale,0,1
England-FA_Cup,Millwall,Barnsley,4,1
England-FA_Cup,AFC Bournemouth,Wigan Athletic,2,2
England-FA_Cup,Birmingham City,Burton Albion,1,0
England-FA_Cup,Blackburn Rovers,Hull City,0,1
England-FA_Cup,Ipswich Town,Sheffield United,0,1
England-FA_Cup,Fulham,Southampton,0,1
England-FA_Cup,Bolton Wanderers,Huddersfield Town,1,2
England-FA_Cup,Stevenage,Reading,0,0
England-FA_Cup,Carlisle United,Sheffield Wednesday,0,0
England-FA_Cup,Wycombe Wanderers,Preston North End,1,5
England-FA_Cup,Yeovil Town,Bradford City,2,0
England-FA_Cup,Coventry City,Stoke City,2,1
England-FA_Cup,Fleetwood Town,Leicester City,0,0
England-FA_Cup,Norwich City,Chelsea,0,0
England-FA_Cup,Exeter City,West Bromwich Albion,0,2
Italy-Serie_A,SSC Napoli,Hellas Verona,2,0
Italy-Serie_A,AC Milan,Crotone,1,0
Italy-Serie_A,Roma,Atalanta,1,2
Italy-Serie_A,Torino,Bologna,3,0
Italy-Serie_A,Genoa,Sassuolo,1,0
Italy-Serie_A,Benevento,Sampdoria,3,2
Italy-Serie_A,SPAL 2013,Lazio,2,5
Italy-Serie_A,Cagliari,Juventus,0,1
Portugal-Primeira_Liga,Braga,Rio Ave,2,1
Spain-Primera_Division,Atletico Madrid,Getafe,2,0
Spain-Primera_Division,Valencia,Girona,2,1
Spain-Primera_Division,Sevilla,Real Betis,3,5
Spain-Primera_Division,Las Palmas,Eibar,1,2
Australia-A_League,Melbourne Victory,Central Coast Mariners,1,1
Australia-A_League,Melbourne City FC,Wellington Phoenix,2,1
England-FA_Cup,Tottenham Hotspur,AFC Wimbledon,3,0
England-FA_Cup,Newport County,Leeds United,2,1
England-FA_Cup,Shrewsbury Town,West Ham United,0,0
England-FA_Cup,Nottingham Forest,Arsenal,4,2
Portugal-Primeira_Liga,FC Porto,Vitoria de Guimaraes,4,2
Portugal-Primeira_Liga,Sporting CP,Maritimo,5,0
Portugal-Primeira_Liga,Chaves,Aves,1,1
Portugal-Primeira_Liga,Moreirense,Benfica,0,2
Spain-Primera_Division,Barcelona,Levante,3,0
Spain-Primera_Division,Villarreal,Deportivo La Coruna,1,1
Spain-Primera_Division,Athletic Bilbao,Alaves,2,0
Spain-Primera_Division,Leganes,Real Sociedad,1,0
Spain-Primera_Division,Celta Vigo,Real Madrid,2,2
France-Coupe_de_France,US Granvillaise,Bordeaux,2,1
France-Coupe_de_France,USM Senlis,Nantes,0,4
France-Coupe_de_France,FC Still,Troyes,0,1
France-Coupe_de_France,Vannes,Stade Briochin,4,6
France-Coupe_de_France,Fleury Merogis U.S,ASC Biesheim,0,1
France-Coupe_de_France,Entente SSG,Epinal,1,2
France-Coupe_de_France,Marseille,Valenciennes,1,0
France-Coupe_de_France,Strasbourg,Dijon,3,2
France-Coupe_de_France,Saint-Etienne,Nimes,2,0
France-Coupe_de_France,Sochaux,Amiens,6,0
France-Coupe_de_France,Angers,Lorient,0,2
France-Coupe_de_France,Dunkerque,Metz,2,4
France-Coupe_de_France,Rennes,Paris Saint Germain,1,6
International-Friendlies,Sweden,Estonia,1,1
Greece-Super_League,Panathinaikos,Platanias,2,0
Greece-Super_League,PAS Giannina,Asteras Tripolis,0,0
Greece-Super_League,Lamia,Xanthi,0,1
Greece-Super_League,AE Larissa,Olympiacos,0,3
Mexico-Liga_MX_Clausura,Toluca,CD Guadalajara,1,1
Mexico-Liga_MX_Clausura,Monterrey,Monarcas Morelia,1,1
Mexico-Liga_MX_Clausura,Cruz Azul,Tijuana,0,0
Mexico-Liga_MX_Clausura,Pachuca,Pumas,2,3
Mexico-Liga_MX_Clausura,Necaxa,Veracruz,0,0
Spain-Segunda_Division,Osasuna,Valladolid,4,2
Spain-Segunda_Division,Sevilla Atletico,Lorca FC,3,2
Spain-Segunda_Division,Leonesa,Numancia,2,2
Spain-Segunda_Division,Almeria,Lugo,1,0
England-FA_Cup,Brighton &amp; Hove Albion,Crystal Palace,2,1
Portugal-Primeira_Liga,Estoril,Feirense,0,2
Portugal-Primeira_Liga,Pacos de Ferreira,Portimonense,1,1
Spain-Primera_Division,Malaga,Espanyol,0,1
Australia-A_League,Brisbane Roar FC,Sydney FC,0,3
France-Coupe_de_France,Lens,Boulogne,3,2
Greece-Super_League,Apollon Smirnis,Atromitos,0,3
Israel-Ligat_HaAl,FC Ashdod,Bnei Sakhnin,1,2
Israel-Ligat_HaAl,Hapoel Haifa,Beitar Jerusalem,0,2
Israel-Ligat_HaAl,Hapoel Ironi Akko,Hapoel Ashkelon,0,1
Mexico-Liga_MX_Clausura,Queretaro FC,CF America,0,1
Mexico-Liga_MX_Clausura,Santos,Lobos de la BUAP,4,2
International-Club_Friendlies,Oostende,VfB Stuttgart,2,5
International-Club_Friendlies,Bolton Wanderers,Magdeburg,2,3
International-Club_Friendlies,Karabukspor,Keciorengucu,1,1
International-Club_Friendlies,Bursaspor,Skenderbeu,3,0
International-Club_Friendlies,Genclerbirligi,KF Kamza,4,1
International-Club_Friendlies,Borussia Dortmund,Zulte-Waregem,3,2
International-Club_Friendlies,Kayserispor,Kukesi,1,2
International-Club_Friendlies,Young Boys,FC Vaduz,6,1
Egypt-Premier_League,El Zamalek,Al Ahly,0,3
Spain-Segunda_B_Grp__I,Navalcarnero,Cerceda,2,1
Australia-National_Youth_League,Melbourne City FC Youth,Adelaide United Youth,4,3
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Juventus SP U20,Espirito Santo U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Grp__26,Agua Santa U20,Vasco da Gama U20,0,1
Brazil-Sao_Paulo_Youth_Cup_Grp__27,Taubate U20,Palmeiras U20,1,1
Brazil-Sao_Paulo_Youth_Cup_Grp__27,Luverdense U20,Moto Club MA U20,0,3
Brazil-Sao_Paulo_Youth_Cup_Grp__30,Bragantino U20,Trindade U20,0,4
Brazil-Sao_Paulo_Youth_Cup_Grp__30,Uniao Mogi U20,Gremio RS U20,0,3
Brazil-Sao_Paulo_Youth_Cup_Grp__32,Portuguesa U20,America MG U20,4,2
Brazil-Sao_Paulo_Youth_Cup_Grp__32,Remo U20,Teixeira de Freitas U20,4,1
Brazil-Sao_Paulo_Youth_Cup_Grp__4,America RN U20,Alianca U20,0,1
Costa_Rica-Primera_Division_Clausura,AD Municipal Liberia,Deportivo Saprissa,0,3
Cyprus-1__Division,Aris Limassol,Doxa Katokopia,1,0
England-Isthmian_Premier_Division,Kingstonian,Enfield Town,4,1
England-Premier_League_2_Division_1,Manchester United U23,West Ham U23,0,3
England-Premier_League_2_Division_2,Reading U23,Brighton &amp; Hove Albion U23,2,1
England-Premier_League_2_Division_2,Stoke City U23,Norwich U23,1,3
England-Premier_League_2_Division_2,Aston Villa U23,Fulham U23,1,3
Greece-Gamma_Ethniki_Grp__6,Diagoras Rodos,Loutraki,1,0
Portugal-Primeira_Liga,Belenenses,Boavista,1,1
Portugal-Primeira_Liga,Tondela,Vitoria de Setubal,1,1
Australia-A_League,Newcastle Jets,Central Coast Mariners,2,0
Australia-A_League,Perth Glory,Melbourne City FC,0,2
England-EFL_Cup,Manchester City,Bristol City,2,1
Israel-Ligat_HaAl,Hapoel Beer Sheva,Bnei Yehuda Tel Aviv,0,0
Israel-Ligat_HaAl,Maccabi Tel Aviv,Maccabi Netanya,3,0
Israel-Ligat_HaAl,Maccabi Petach Tikva,Hapoel Ironi Kiryat Shmona,2,0
N__Ireland-Premiership,Carrick Rangers,Linfield,0,1
Spain-Copa_del_Rey,Atletico Madrid,Lleida Esportiu,3,0
Spain-Copa_del_Rey,Valencia,Las Palmas,4,0
International-Club_Friendlies,Excelsior,Hibernian,0,0
International-Club_Friendlies,Sparta Rotterdam,PEC Zwolle,
International-Club_Friendlies,Hannover 96,Paderborn,4,1
International-Club_Friendlies,Bayern Munich,Sonnenhof Grossaspach,
International-Club_Friendlies,Jahn Regensburg,LASK,3,3
International-Club_Friendlies,Darmstadt,Waasland-Beveren,3,0
International-Club_Friendlies,Nuernberg,Gent,0,1
International-Club_Friendlies,Bayern Munich,Sonnenhof Grossaspach,5,3
International-Club_Friendlies,Besiktas,ADO Den Haag,2,2
International-Club_Friendlies,Trabzonspor,Luftetari,2,1
International-Club_Friendlies,Fortuna Duesseldorf,Standard Liege,1,3
Egypt-Premier_League,El Geish,Alassiouty,2,1
Egypt-Premier_League,Al Nasr,Ismaily SC,2,3
England-EFL_Trophy_Final_Stage,Yeovil Town,Forest Green Rovers,2,0
England-EFL_Trophy_Final_Stage,Portsmouth,Chelsea Academy,1,2
England-EFL_Trophy_Final_Stage,Charlton Athletic,Oxford United,1,4
England-EFL_Trophy_Final_Stage,Bury,Fleetwood Town,2,3
England-EFL_Trophy_Final_Stage,Rochdale,Lincoln City,0,1
England-EFL_Trophy_Final_Stage,Luton Town,Peterborough United,6,7
France-League_Cup,Nice,Monaco,1,2
Greece-Cup_Final_Stage,AEK Athens,Panetolikos,1,0
Greece-Cup_Final_Stage,PAOK Thessaloniki FC,Trikala,2,1
Greece-Cup_Final_Stage,OFI Crete,Panionios,0,1
Scotland-Championship,Inverness CT,Falkirk,4,1
Wales-Premier_League,Newtown,Cardiff Met University,3,2
International-AFC_U23_Championship_Grp__A,China U23,Oman U23,3,0
International-AFC_U23_Championship_Grp__A,Qatar U23,Uzbekistan U23,1,0
Brazil-Copa_do_Nordeste_Qualification,AO Itabaiana,Nautico,0,0
Brazil-Sao_Paulo_Youth_Cup_Grp__1,Guarani U20,Madureira RJ U20,0,0
Australia-A_League,Western Sydney Wanderers FC,Adelaide United,1,1
Australia-A_League,Wellington Phoenix,Melbourne Victory,2,1
England-EFL_Cup,Chelsea,Arsenal,0,0
Israel-Ligat_HaAl,Hapoel Raanana,Maccabi Haifa,0,3
Spain-Copa_del_Rey,Real Madrid,Numancia,2,2
Spain-Copa_del_Rey,Alaves,SD Formentera,2,0
Spain-Copa_del_Rey,Villarreal,Leganes,2,1
Belgium-First_Division_B_2nd_Stage,Tubize,KFCO Beerschot-Wilrijk,1,2
International-Club_Friendlies,KV Mechelen,Ingolstadt,2,2
International-Club_Friendlies,Trabzonspor,1461 Trabzon,1,1
International-Club_Friendlies,Goztepe,Konyaspor,1,1
International-Club_Friendlies,Bursaspor,Kukesi,1,2
International-Club_Friendlies,Anderlecht,FC Utrecht,3,4
International-Club_Friendlies,Union Berlin,Gent,3,1
International-Club_Friendlies,Istanbul Basaksehir,Yeni Malatyaspor,4,1
International-Club_Friendlies,FC Heidenheim,Royal Antwerp,3,1
International-Club_Friendlies,KV Mechelen,Osnabrueck,2,1
International-Club_Friendlies,Lausanne,Team Vaud U21,1,1
International-Club_Friendlies,Union,Olimpo,
International-Club_Friendlies,Trabzonspor,Eskisehirspor,
International-Club_Friendlies,San Martin San Juan,Union,0,0
International-Club_Friendlies,Sturm Graz,Allerheiligen,4,2
International-Club_Friendlies,Schaffhausen,FC Zuerich,2,0
International-Club_Friendlies,Wohlen,Lausanne,
International-Club_Friendlies,Elche,Lokeren,4,3
International-Club_Friendlies,Sivasspor,Genclerbirligi,1,4
International-Club_Friendlies,San Martin San Juan,Union,1,0
International-Club_Friendlies,Sporting Charleroi,FC Seoul,1,0
International-Club_Friendlies,Erzgebirge Aue,Oostende,0,2
International-Club_Friendlies,Kayserispor,Slovacko,4,1
International-Club_Friendlies,FC Groningen,Club Brugge,1,2
England-EFL_Trophy_Final_Stage,Shrewsbury Town,Blackpool,4,2
France-League_Cup,Rennes,Toulouse,4,2
France-League_Cup,Angers,Montpellier,0,1
France-League_Cup,Amiens,Paris Saint Germain,0,2
Greece-Cup_Final_Stage,Xanthi,AE Larissa,2,0
Greece-Cup_Final_Stage,Panathinaikos,Lamia,1,0
Greece-Cup_Final_Stage,Olympiacos,Platanias,2,0
Greece-Cup_Final_Stage,PAS Giannina,Levadiakos,4,0
Portugal-Cup,Caldas,Farense,3,2
International-Friendlies,Indonesia,Iceland,0,6
International-Friendlies,Sweden,Denmark,1,0
International-Friendlies,Jordan,Finland,1,2
Spain-Copa_del_Rey,Barcelona,Celta Vigo,5,0
Spain-Copa_del_Rey,Sevilla,Cadiz,2,1
Spain-Copa_del_Rey,Levante,Espanyol,0,2
International-Club_Friendlies,Genk,Arminia Bielefeld,0,2
International-Club_Friendlies,Karabukspor,Altinordu,0,3
International-Club_Friendlies,SC Heerenveen,Anderlecht U21,1,2
International-Club_Friendlies,Corinthians,PSV Eindhoven,6,5
International-Club_Friendlies,SKN St. Poelten,Karabakh Wien,1,2
International-Club_Friendlies,Kapfenberger SV,Wolfsberger AC,0,1
International-Club_Friendlies,Sanliurfaspor,Kayserispor,
International-Club_Friendlies,Mattersburg,USV Scheiblingkirchen,6,1
International-Club_Friendlies,Royal Antwerp,FC Torrevieja,4,0
International-Club_Friendlies,SC Heerenveen,Anderlecht,0,0
International-Club_Friendlies,Sparta Rotterdam,Kaiserslautern,3,1
Greece-Cup_Final_Stage,Atromitos,Asteras Tripolis,1,0
Portugal-Cup,Moreirense,FC Porto,1,2
International-AFC_U23_Championship_Grp__D,South Korea U23,Vietnam U23,2,1
International-AFC_U23_Championship_Grp__D,Australia U23,Syria U23,3,1
Bahrain-Premier_League,Malkia,Al-Hidd,2,1
Bahrain-Premier_League,Al-Riffa,Al Ahli,0,2
Bahrain-Premier_League,East Riffa,Muharraq,0,3
Brazil-Cearense_1st_Group_Stage,Horizonte,Guarani de Juazeiro,2,1
Brazil-Cearense_1st_Group_Stage,Floresta,Maranguape,0,0
Brazil-Cearense_1st_Group_Stage,Iguatu,Ferroviario,1,1
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,CA Penapolense U20,Mogi Mirim U20,4,1
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Internacional U20,XV de Jau U20,5,4
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Marilia Atletico U20,Desportiva Paraense U20,5,6
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Guarani U20,Atletico PR U20,5,6
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Cruzeiro U20,Rio Branco SP U20,4,2
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Sao Paulo U20,Chapecoense U20,2,0
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Parana Clube U20,Batatais U20,3,2
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Figueirense SC U20,Novorizontino U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Ponte Preta U20,Botafogo SP U20,0,1
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Votuporanguense U20,Criciuma U20,0,3
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Vila Nova U20,Primavera SP U20,4,5
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Atletico GO U20,Boavista U20,3,5
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Botafogo RJ U20,Desportivo Brasil U20,0,2
France-Ligue_1,Strasbourg,Guingamp,0,2
Germany-1__Bundesliga,Bayer Leverkusen,Bayern Munich,1,3
Portugal-Primeira_Liga,Chaves,Vitoria de Guimaraes,4,3
Spain-Primera_Division,Getafe,Malaga,1,0
Australia-A_League,Newcastle Jets,Brisbane Roar FC,1,0
England-Championship,Sheffield United,Sheffield Wednesday,0,0
Netherlands-Eerste_Divisie,NEC Nijmegen,Go Ahead Eagles,5,1
Netherlands-Eerste_Divisie,RKC Waalwijk,Jong AZ Alkmaar,1,0
Netherlands-Eerste_Divisie,FC Volendam,FC Oss,3,1
Netherlands-Eerste_Divisie,Fortuna Sittard,Jong Ajax,2,1
Netherlands-Eerste_Divisie,Jong PSV,Helmond Sport,1,2
Netherlands-Eerste_Divisie,FC Den Bosch,Almere City FC,1,3
Netherlands-Eerste_Divisie,MVV Maastricht,Telstar,0,0
Netherlands-Eerste_Divisie,Cambuur,De Graafschap,3,2
Netherlands-Eerste_Divisie,Jong FC Utrecht,FC Dordrecht,0,2
Netherlands-Eerste_Divisie,FC Eindhoven,FC Emmen,2,1
Spain-Segunda_Division,Rayo Vallecano,Real Oviedo,2,2
Belgium-First_Division_B_2nd_Stage,Westerlo,Roeselare,0,0
International-Club_Friendlies,Salzburg,SV Wals Grunau,13,1
International-Club_Friendlies,Kortrijk,Roda JC Kerkrade,2,5
International-Club_Friendlies,Partick Thistle,Shanghai Shenhua,2,1
International-Club_Friendlies,Sivasspor,Zhetysu Taldykorgan,1,1
International-Club_Friendlies,Start,Vindbjart,
International-Club_Friendlies,Sporting Charleroi,Yanbian,4,0
International-Club_Friendlies,VfB Stuttgart II,Grasshopper,
International-Club_Friendlies,Thun,FC Rapperswil-Jona,5,2
International-Club_Friendlies,Atletico MG,Rangers,0,1
International-Club_Friendlies,Istanbul Basaksehir,ADO Den Haag,4,0
International-Club_Friendlies,Waasland-Beveren,FC Seoul,
International-Club_Friendlies,Start,Donn,11,0
International-Club_Friendlies,Goztepe,Adanaspor,0,0
International-Club_Friendlies,Lokeren,FC Seoul,1,0
International-Club_Friendlies,Sturm Graz,BW Linz,2,2
International-Club_Friendlies,Kasimpasa,Partizani,1,0
International-Club_Friendlies,Willem II,Hibernian,3,1
International-Club_Friendlies,Heracles,Karlsruher SC,2,3
International-Club_Friendlies,Besiktas,Skenderbeu,3,2
International-Club_Friendlies,Sarpsborg 08,Moss,3,0
International-Club_Friendlies,Vaalerenga,Stroemmen,3,0
International-Club_Friendlies,San Lorenzo,Defensa y Justicia,3,1
England-Premier_League,Tottenham Hotspur,Everton,4,0
England-Premier_League,Chelsea,Leicester City,0,0
England-Premier_League,Newcastle United,Swansea City,1,1
England-Premier_League,West Bromwich Albion,Brighton &amp; Hove Albion,2,0
England-Premier_League,Crystal Palace,Burnley,1,0
England-Premier_League,Watford,Southampton,2,2
England-Premier_League,Huddersfield Town,West Ham United,1,4
France-Ligue_1,Nice,Amiens,1,0
France-Ligue_1,Dijon,Metz,1,1
France-Ligue_1,Caen,Lille,0,1
France-Ligue_1,Montpellier,Monaco,0,0
France-Ligue_1,Troyes,Bordeaux,0,1
France-Ligue_1,Rennes,Marseille,0,3
Germany-1__Bundesliga,Augsburg,Hamburger SV,1,0
Germany-1__Bundesliga,VfB Stuttgart,Hertha Berlin,1,0
Germany-1__Bundesliga,Eintracht Frankfurt,Freiburg,1,1
Germany-1__Bundesliga,Hannover 96,Mainz 05,3,2
Germany-1__Bundesliga,RasenBallsport Leipzig,Schalke 04,3,1
Germany-1__Bundesliga,Werder Bremen,Hoffenheim,1,1
Portugal-Primeira_Liga,Pacos de Ferreira,Maritimo,0,0
Portugal-Primeira_Liga,Braga,Benfica,1,3
Spain-Primera_Division,Real Madrid,Villarreal,0,1
Spain-Primera_Division,Girona,Las Palmas,6,0
Spain-Primera_Division,Deportivo La Coruna,Valencia,1,2
Spain-Primera_Division,Eibar,Atletico Madrid,0,1
International-African_Nations_Championship_Grp__A,Morocco,Mauritania,4,0
Australia-A_League,Melbourne Victory,Perth Glory,3,2
Australia-A_League,Wellington Phoenix,Western Sydney Wanderers FC,1,1
England-Championship,Brentford,Bolton Wanderers,2,0
England-Championship,Cardiff City,Sunderland,4,0
England-Championship,Hull City,Reading,0,0
England-Championship,Middlesbrough,Fulham,0,1
England-Championship,Bristol City,Norwich City,0,1
England-Championship,Millwall,Preston North End,1,1
England-Championship,Burton Albion,Queens Park Rangers,1,3
England-Championship,Ipswich Town,Leeds United,1,0
England-Championship,Nottingham Forest,Aston Villa,0,1
England-Championship,Birmingham City,Derby County,0,3
England-Championship,Barnsley,Wolverhampton Wanderers,0,0
International-Friendlies,Morocco,Mauritania,
England-Premier_League,Liverpool,Manchester City,4,3
England-Premier_League,AFC Bournemouth,Arsenal,2,1
France-Ligue_1,Lyon,Angers,1,1
France-Ligue_1,Saint-Etienne,Toulouse,2,0
France-Ligue_1,Nantes,Paris Saint Germain,0,1
Germany-1__Bundesliga,Borussia Dortmund,Wolfsburg,0,0
Germany-1__Bundesliga,FC Cologne,Borussia Moenchengladbach,2,1
Portugal-Primeira_Liga,Sporting CP,Aves,3,0
Portugal-Primeira_Liga,Tondela,Feirense,3,1
Portugal-Primeira_Liga,Belenenses,Rio Ave,1,2
Portugal-Primeira_Liga,Boavista,Portimonense,2,0
Spain-Primera_Division,Espanyol,Athletic Bilbao,1,1
Spain-Primera_Division,Levante,Celta Vigo,0,1
Spain-Primera_Division,Alaves,Sevilla,1,0
Spain-Primera_Division,Real Sociedad,Barcelona,2,4
International-African_Nations_Championship_Grp__A,Guinea,Sudan,1,2
International-African_Nations_Championship_Grp__B,Ivory Coast,Namibia,0,1
International-African_Nations_Championship_Grp__B,Zambia,Uganda,3,1
Australia-A_League,Central Coast Mariners,Melbourne City FC,2,2
Australia-A_League,Adelaide United,Sydney FC,0,0
International-Friendlies,Indonesia,Iceland,1,4
Greece-Super_League,AOK Kerkyra,PAOK Thessaloniki FC,0,3
Greece-Super_League,AEK Athens,PAS Giannina,3,1
Greece-Super_League,Asteras Tripolis,AE Larissa,3,1
Greece-Super_League,Atromitos,Panetolikos,0,1
Greece-Super_League,Levadiakos,Panathinaikos,3,2
Israel-Ligat_HaAl,Hapoel Beer Sheva,Hapoel Haifa,1,1
Israel-Ligat_HaAl,Hapoel Ashkelon,Hapoel Raanana,0,1
Mexico-Liga_MX_Clausura,Tigres,Santos,2,1
Mexico-Liga_MX_Clausura,Lobos de la BUAP,Queretaro FC,0,2
Mexico-Liga_MX_Clausura,Pumas,Atlas,3,1
Mexico-Liga_MX_Clausura,Leon,Toluca,3,1
Mexico-Liga_MX_Clausura,CF America,Pachuca,2,2
Mexico-Liga_MX_Clausura,CD Guadalajara,Cruz Azul,1,3
Spain-Segunda_Division,Cadiz,Cordoba,2,0
Spain-Segunda_Division,Huesca,Numancia,2,1
Spain-Segunda_Division,Leonesa,Lorca FC,2,1
Spain-Segunda_Division,Albacete,Granada,2,1
Spain-Segunda_Division,Sevilla Atletico,Osasuna,0,1
Belgium-First_Division_B_2nd_Stage,Oud-Heverlee,Union St.-Gilloise,3,1
England-Premier_League,Manchester United,Stoke City,3,0
Portugal-Primeira_Liga,Moreirense,Vitoria de Setubal,2,2
Spain-Primera_Division,Real Betis,Leganes,3,2
International-African_Nations_Championship_Grp__C,Nigeria,Rwanda,0,0
International-African_Nations_Championship_Grp__C,Libya,Equatorial Guinea,3,0
International-Friendlies,Jordan,Denmark,3,2
Greece-Super_League,Olympiacos,Lamia,2,0
Israel-Ligat_HaAl,Maccabi Haifa,Maccabi Tel Aviv,1,3
Mexico-Liga_MX_Clausura,Veracruz,Monterrey,0,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Cambuur,0,1
Netherlands-Eerste_Divisie,FC Oss,NEC Nijmegen,3,0
International-Club_Friendlies,VVV-Venlo,SV Venray,
International-Club_Friendlies,Sivasspor,Tobol Kostanay,1,0
International-Club_Friendlies,Rosario Central,Lanus,9,8
International-Club_Friendlies,Galatasaray,Tuzlaspor,5,0
International-Club_Friendlies,Shanghai SIPG FC,Rubin Kazan,
International-Club_Friendlies,LASK,FC Vaduz,1,0
International-Club_Friendlies,FC Liefering,Wolfsberger AC,3,3
International-Club_Friendlies,Boca Juniors,Godoy Cruz,2,3
International-AFC_U23_Championship_Grp__A,Uzbekistan U23,Oman U23,1,0
International-AFC_U23_Championship_Grp__A,China U23,Qatar U23,1,2
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Internacional U20,Desportiva Paraense U20,4,0
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Atletico PR U20,Santos SP U20,0,2
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Sao Paulo U20,Cruzeiro U20,1,0
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Londrina EC U20,Vitoria BA U20,1,2
Cyprus-1__Division,Alki Oroklinis,Olympiakos Nicosia,1,1
England-Premier_League_2_Division_1,Tottenham U23,Everton U23,1,2
England-Premier_League_2_Division_1,Derby U23,Swansea U23,3,3
England-Premier_League_2_Division_1,Arsenal U23,Manchester United U23,4,0
England-Premier_League_2_Division_2,Southampton U23,Aston Villa U23,1,4
India-I_League,Gokulam FC,Churchill Brothers,2,3
Iraq-Premier_League,Naft Maysan,Karbalaa,3,1
Iraq-Premier_League,Al Quwa Al Jawiya,Alsinaat Alkahrabaiya,2,1
Iraq-Premier_League,Naft Al Wasat,Naft Al Junoob,1,1
Iraq-Premier_League,Al Minaa,Al Shorta,0,0
Iraq-Premier_League,Al Naft,Al Kahrabaa,1,0
Israel-Leumit_League,Hapoel Marmorek,Hapoel Petah Tikva,2,1
Israel-Leumit_League,Hapoel Tel Aviv,Beitar Tel Aviv Ramla,2,0
Israel-Leumit_League,Hapoel Kfar Saba,Hapoel Rishon LeZion,0,1
Israel-Leumit_League,Hapoel Katamon Jerusalem,Hapoel Bnei Lod,1,0
England-FA_Cup,Leicester City,Fleetwood Town,2,0
England-FA_Cup,West Ham United,Shrewsbury Town,1,0
England-FA_Cup,Reading,Stevenage,3,0
England-FA_Cup,Sheffield Wednesday,Carlisle United,2,0
England-FA_Cup,Mansfield Town,Cardiff City,1,4
France-Ligue_1,Marseille,Strasbourg,2,0
France-Ligue_1,Bordeaux,Caen,0,2
France-Ligue_1,Monaco,Nice,2,2
Netherlands-Eredivisie,Sparta Rotterdam,Vitesse,0,1
International-AFC_Champions_League_Qualification,Bali United Pusam,Tampines Rovers FC,3,1
International-AFC_Champions_League_Qualification,Shan United,Ceres-Negros FC,4,5
International-African_Nations_Championship_Grp__D,Cameroon,Congo,0,1
International-African_Nations_Championship_Grp__D,Angola,Burkina Faso,0,0
Belgium-First_Division_A,Oostende,Genk,1,2
Turkey-Cup,Trabzonspor,Konyaspor,1,1
Turkey-Cup,Bursaspor,Genclerbirligi,2,1
Turkey-Cup,Istanbulspor,Fenerbahce,0,1
Belgium-Cup,Club Brugge,Sporting Charleroi,5,1
International-Club_Friendlies,Floridsdorfer AC,Austria Wien,1,1
International-Club_Friendlies,Fortuna Duesseldorf,Borussia Moenchengladbach,2,0
International-Club_Friendlies,Shanghai Shenhua,Luzern,1,1
International-Club_Friendlies,Vaalerenga,Holstein Kiel,
International-Club_Friendlies,Mattersburg,Ulsan Hyundai,2,2
International-Club_Friendlies,Kolding IF,SoenderjyskE,0,3
International-Club_Friendlies,Sturm Graz,St. Gallen,1,1
International-Club_Friendlies,SKN St. Poelten,First Vienna FC,
International-Club_Friendlies,Admira Moedling,ASK Ebreichsdorf,4,0
International-Club_Friendlies,Racing Club,Temperley,0,1
International-Club_Friendlies,FCM Arkadia Traiskirchen,SKN St. Poelten,1,2
Egypt-Premier_League,Wadi Degla FC,Al Masry,0,0
Egypt-Premier_League,El Geish,Al Ahly,0,2
France-Ligue_2,Le Havre,SC Bastia,
France-Ligue_2,Reims,Tours,1,0
France-Ligue_2,Clermont Foot,Valenciennes,3,0
France-Ligue_2,Auxerre,Niort,5,0
France-Ligue_2,AC Ajaccio,Orleans,1,1
France-Ligue_2,Le Havre,Paris FC,1,1
France-Ligue_2,Nancy,Nimes,0,2
France-Ligue_2,Bourg en Bresse Peronnas,Quevilly,3,5
France-Ligue_2,GFC Ajaccio,Brest,1,1
England-FA_Cup,Chelsea,Norwich City,6,4
England-FA_Cup,Swansea City,Wolverhampton Wanderers,2,1
England-FA_Cup,Wigan Athletic,AFC Bournemouth,3,0
France-Ligue_1,Paris Saint Germain,Dijon,8,0
France-Ligue_1,Angers,Troyes,3,1
France-Ligue_1,Lille,Rennes,1,2
France-Ligue_1,Metz,Saint-Etienne,3,0
France-Ligue_1,Toulouse,Nantes,1,1
France-Ligue_1,Guingamp,Lyon,0,2
France-Ligue_1,Amiens,Montpellier,1,1
International-African_Nations_Championship_Grp__A,Morocco,Guinea,3,1
International-African_Nations_Championship_Grp__A,Sudan,Mauritania,1,0
Spain-Copa_del_Rey,Valencia,Alaves,2,1
Spain-Copa_del_Rey,Atletico Madrid,Sevilla,1,2
Spain-Copa_del_Rey,Espanyol,Barcelona,1,0
Turkey-Cup,Istanbul Basaksehir,Giresunspor,2,1
Turkey-Cup,Akhisar Belediye Genclik Ve Spor,Boluspor,1,0
Turkey-Cup,Osmanlispor FK,Besiktas,2,1
International-Club_Friendlies,FK Qabala,FC Zuerich,0,1
International-Club_Friendlies,Basel,Viktoria Plzen,1,2
International-Club_Friendlies,Broendby IF,Fremad Amager,2,1
International-Club_Friendlies,Vaalerenga,Xamax,0,1
International-Club_Friendlies,St. Pauli,Bochum,1,1
International-Club_Friendlies,Gimnasia LP,Atletico Tucuman,1,0
International-Club_Friendlies,Salzburg,Young Boys,0,2
International-Club_Friendlies,Gimnasia LP,Atletico Tucuman,1,3
International-Club_Friendlies,Union Berlin,Ingolstadt,1,1
International-Club_Friendlies,San Martin San Juan,Olimpo,
International-Club_Friendlies,Grasshopper,Altach,2,0
International-Club_Friendlies,Rosenborg,Kolstad,4,1
International-Club_Friendlies,Malaga,Lausanne,1,1
International-Club_Friendlies,AGF,Brabrand,2,0
International-Club_Friendlies,Pescara,Lugano,3,1
International-Club_Friendlies,Kaiserslautern,FC Midtjylland,1,0
International-Club_Friendlies,Darmstadt,Greuther Fuerth,2,2
International-Club_Friendlies,Huracan,San Lorenzo,2,0
International-Club_Friendlies,Vaalerenga,Yanbian,
Egypt-Premier_League,Alassiouty,El Raja Marsa Matruh,3,1
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Al Nasr,3,0
Egypt-Premier_League,Al Mokawloon Al Arab,Ismaily SC,2,0
International-African_Nations_Championship_Grp__B,Uganda,Namibia,0,1
International-African_Nations_Championship_Grp__B,Ivory Coast,Zambia,0,2
Australia-A_League,Brisbane Roar FC,Perth Glory,3,2
Spain-Segunda_Division,Osasuna,Gimnastic,0,2
Spain-Copa_del_Rey,Leganes,Real Madrid,0,1
Turkey-Cup,Bucaspor,Galatasaray,0,3
Turkey-Cup,Antalyaspor,Kayserispor,0,2
International-Club_Friendlies,Talleres,Belgrano,1,1
International-Club_Friendlies,Grasshopper,FC Viitorul Constanta,1,1
International-Club_Friendlies,Wolfsberger AC,Rudar Velenje,1,0
International-Club_Friendlies,CSMS Iasi,FC Rostov,1,1
International-Club_Friendlies,Lokomotiv Moscow,Luzern,0,3
International-Club_Friendlies,Troina,Sion,0,2
International-Club_Friendlies,Rapid Wien,Beijing Renhe,4,2
International-Club_Friendlies,FC Koebenhavn,Vejle Boldklub,4,0
International-Club_Friendlies,Spartak Moscow,Shanghai SIPG FC,0,1
International-Club_Friendlies,Dinamo Moscow,Gaz Metan Medias,1,0
International-Club_Friendlies,Silkeborg,AC Horsens,2,0
International-Club_Friendlies,Botosani,Tosno,2,2
Egypt-Premier_League,El Dakhleya,El Zamalek,1,2
Brazil-Copa_do_Nordeste_Grp__B,Ferroviario,ABC,1,3
Brazil-Copa_do_Nordeste_Grp__D,CS Alagoano,Sampaio Correa,1,1
Brazil-Carioca_Taca_Guanabara_Grp__B,Vasco da Gama,Bangu,0,2
Brazil-Carioca_Taca_Guanabara_Grp__B,Volta Redonda,Flamengo,0,2
Brazil-Catarinense,Figueirense,Criciuma,1,0
Brazil-Cearense_1st_Group_Stage,Uniclinic Atletico Clube,Fortaleza,0,4
Brazil-Gaucho,Sao Luiz,Gremio,1,1
Brazil-Goiano,Aparecidense,Goias,1,2
Brazil-Goiano,Anapolis FC,Esporte Clube Rio Verde,2,3
Brazil-Goiano,Vila Nova,Ipora,1,1
Brazil-Matogrossense,Uniao Rondonopolis,Mixto,2,1
Brazil-Matogrossense,Araguaia,Dom Bosco,1,2
Brazil-Matogrossense,Cuiaba,Sinop,2,1
Brazil-Mineiro,Boa Esporte Clube,Atletico MG,0,0
Brazil-Mineiro,Cruzeiro,Tupi,2,0
Brazil-Paraense,Paysandu,Parauapebas FC,1,0
Brazil-Paraibano,Auto Esporte,Desportiva Guarabira,0,1
Brazil-Paranaense_1st_Group_Stage,CE Uniao,Parana Clube,2,1
Brazil-Paulista_A1,Palmeiras,Santo Andre,3,1
Brazil-Paulista_A1,Corinthians,Ponte Preta,0,1
France-Ligue_1,Caen,Marseille,0,2
Germany-1__Bundesliga,Hertha Berlin,Borussia Dortmund,1,1
Netherlands-Eredivisie,FC Utrecht,AZ Alkmaar,1,1
Portugal-Primeira_Liga,FC Porto,Tondela,1,0
Portugal-Primeira_Liga,Vitoria de Setubal,Sporting CP,1,1
Spain-Primera_Division,Getafe,Athletic Bilbao,2,2
International-African_Nations_Championship_Grp__C,Rwanda,Equatorial Guinea,1,0
International-African_Nations_Championship_Grp__C,Libya,Nigeria,0,1
Australia-A_League,Western Sydney Wanderers FC,Melbourne Victory,0,3
Belgium-First_Division_A,Sporting Charleroi,Royal Excel Mouscron,2,0
England-Championship,Derby County,Bristol City,0,0
Netherlands-Eerste_Divisie,FC Emmen,RKC Waalwijk,2,1
Netherlands-Eerste_Divisie,FC Oss,Jong FC Utrecht,2,0
Netherlands-Eerste_Divisie,De Graafschap,Jong PSV,2,3
Netherlands-Eerste_Divisie,Telstar,FC Eindhoven,4,1
Netherlands-Eerste_Divisie,Go Ahead Eagles,MVV Maastricht,3,1
Netherlands-Eerste_Divisie,Helmond Sport,FC Volendam,1,4
Netherlands-Eerste_Divisie,Almere City FC,NEC Nijmegen,3,2
Netherlands-Eerste_Divisie,FC Dordrecht,Fortuna Sittard,3,0
Spain-Segunda_Division,Granada,Zaragoza,2,1
Turkey-Super_Lig,Kasimpasa,Alanyaspor,3,2
Belgium-First_Division_B_2nd_Stage,Cercle Brugge,Lierse,4,1
International-Club_Friendlies,Notodden,Sandefjord,1,2
International-Club_Friendlies,Bodoe/Glimt,Mjoelner,3,0
International-Club_Friendlies,Arsenal Sarandi,Atletico Tucuman,1,0
International-Club_Friendlies,Estudiantes,Lanus,
International-Club_Friendlies,Start,Flekkeroey,1,2
International-Club_Friendlies,Union,Defensa y Justicia,1,2
International-Club_Friendlies,Nykoebing FC,OB,1,2
International-Club_Friendlies,Mattersburg,Servette,1,1
International-Club_Friendlies,Arsenal Sarandi,Atletico Tucuman,0,0
International-Club_Friendlies,Lillestroem,Stroemmen,4,0
International-Club_Friendlies,Oerebro,FC Linkoeping City,6,2
International-Club_Friendlies,Newells Old Boys,Banfield,5,4
International-Club_Friendlies,Union,Defensa y Justicia,1,0
International-Club_Friendlies,Stabaek,Kongsvinger,7,1
International-Club_Friendlies,SoenderjyskE,Fredericia,2,3
International-Club_Friendlies,Thun,Schaffhausen,4,1
International-Club_Friendlies,FC Midtjylland,Hobro,2,2
International-Club_Friendlies,Dynamo Kyiv,St. Gallen,0,2
England-Premier_League,Manchester City,Newcastle United,3,1
England-Premier_League,Arsenal,Crystal Palace,4,1
England-Premier_League,Leicester City,Watford,2,0
England-Premier_League,Stoke City,Huddersfield Town,2,0
England-Premier_League,West Ham United,AFC Bournemouth,1,1
England-Premier_League,Everton,West Bromwich Albion,1,1
England-Premier_League,Brighton &amp; Hove Albion,Chelsea,0,4
England-Premier_League,Burnley,Manchester United,0,1
France-Ligue_1,Montpellier,Toulouse,2,1
France-Ligue_1,Rennes,Angers,1,0
France-Ligue_1,Strasbourg,Dijon,3,2
France-Ligue_1,Nantes,Bordeaux,0,1
France-Ligue_1,Troyes,Lille,1,0
France-Ligue_1,Amiens,Guingamp,3,1
Germany-1__Bundesliga,Hamburger SV,FC Cologne,0,2
Germany-1__Bundesliga,Borussia Moenchengladbach,Augsburg,2,0
Germany-1__Bundesliga,Wolfsburg,Eintracht Frankfurt,1,3
Germany-1__Bundesliga,Mainz 05,VfB Stuttgart,3,2
Germany-1__Bundesliga,Hoffenheim,Bayer Leverkusen,1,4
Germany-1__Bundesliga,Freiburg,RasenBallsport Leipzig,2,1
Netherlands-Eredivisie,PEC Zwolle,NAC Breda,1,0
Netherlands-Eredivisie,Vitesse,SC Heerenveen,1,1
Netherlands-Eredivisie,ADO Den Haag,VVV-Venlo,1,1
Netherlands-Eredivisie,Roda JC Kerkrade,FC Twente,1,1
Portugal-Primeira_Liga,Benfica,Chaves,3,0
Portugal-Primeira_Liga,Maritimo,Belenenses,0,0
Portugal-Primeira_Liga,Portimonense,Braga,1,2
Spain-Primera_Division,Atletico Madrid,Girona,1,1
Spain-Primera_Division,Villarreal,Levante,2,1
Spain-Primera_Division,Espanyol,Sevilla,0,3
Spain-Primera_Division,Las Palmas,Valencia,2,1
International-African_Nations_Championship_Grp__D,Congo,Burkina Faso,2,0
International-African_Nations_Championship_Grp__D,Angola,Cameroon,1,0
Australia-A_League,Sydney FC,Central Coast Mariners,1,1
Australia-A_League,Newcastle Jets,Wellington Phoenix,2,3
Belgium-First_Division_A,Standard Liege,Eupen,3,2
Belgium-First_Division_A,Oostende,Kortrijk,2,1
Belgium-First_Division_A,Waasland-Beveren,St.Truiden,3,1
Belgium-First_Division_A,KV Mechelen,Zulte-Waregem,0,2
England-Championship,Wolverhampton Wanderers,Nottingham Forest,0,2
England-Premier_League,Southampton,Tottenham Hotspur,1,1
France-Ligue_1,Monaco,Metz,3,1
France-Ligue_1,Nice,Saint-Etienne,1,0
France-Ligue_1,Lyon,Paris Saint Germain,2,1
Germany-1__Bundesliga,Bayern Munich,Werder Bremen,4,2
Germany-1__Bundesliga,Schalke 04,Hannover 96,1,1
Italy-Serie_A,Lazio,ChievoVerona,5,1
Italy-Serie_A,Bologna,Benevento,3,0
Italy-Serie_A,Udinese,SPAL 2013,1,1
Italy-Serie_A,Hellas Verona,Crotone,0,3
Italy-Serie_A,Inter,Roma,1,1
Italy-Serie_A,Sassuolo,Torino,1,1
Italy-Serie_A,Sampdoria,Fiorentina,3,1
Italy-Serie_A,Atalanta,SSC Napoli,0,1
Italy-Serie_A,Cagliari,AC Milan,1,2
Netherlands-Eredivisie,Ajax,Feyenoord,2,0
Netherlands-Eredivisie,Willem II,FC Groningen,1,1
Netherlands-Eredivisie,Sparta Rotterdam,Excelsior,2,3
Netherlands-Eredivisie,Heracles,PSV Eindhoven,1,2
Portugal-Primeira_Liga,Vitoria de Guimaraes,Estoril,3,1
Portugal-Primeira_Liga,Aves,Pacos de Ferreira,0,2
Portugal-Primeira_Liga,Rio Ave,Boavista,2,0
Portugal-Primeira_Liga,Feirense,Moreirense,1,0
Spain-Primera_Division,Real Madrid,Deportivo La Coruna,7,1
Spain-Primera_Division,Real Sociedad,Celta Vigo,1,2
Spain-Primera_Division,Alaves,Leganes,2,2
Spain-Primera_Division,Real Betis,Barcelona,0,5
International-African_Nations_Championship_Grp__A,Sudan,Morocco,0,0
International-African_Nations_Championship_Grp__A,Mauritania,Guinea,0,1
Australia-A_League,Melbourne City FC,Adelaide United,5,0
Belgium-First_Division_A,Gent,Lokeren,3,0
Belgium-First_Division_A,Genk,Anderlecht,0,1
Belgium-First_Division_A,Royal Antwerp,Club Brugge,2,2
Greece-Super_League,PAOK Thessaloniki FC,Apollon Smirnis,3,0
Greece-Super_League,Olympiacos,Xanthi,3,0
Greece-Super_League,PAS Giannina,Atromitos,2,2
Greece-Super_League,Panetolikos,Panionios,1,1
Greece-Super_League,Lamia,Asteras Tripolis,1,0
Israel-Ligat_HaAl,Maccabi Tel Aviv,Hapoel Ashkelon,3,1
Israel-Ligat_HaAl,Maccabi Petach Tikva,Maccabi Netanya,1,1
International-Copa_Libertadores_Qualification,Montevideo Wanderers,Olimpia,0,0
England-Premier_League,Swansea City,Liverpool,1,0
Italy-Serie_A,Juventus,Genoa,1,0
Spain-Primera_Division,Eibar,Malaga,1,1
International-African_Nations_Championship_Grp__B,Uganda,Ivory Coast,0,0
International-African_Nations_Championship_Grp__B,Namibia,Zambia,1,1
Israel-Ligat_HaAl,Beitar Jerusalem,Bnei Sakhnin,4,2
Mexico-Liga_MX_Clausura,Santos,Monarcas Morelia,1,0
Netherlands-Eerste_Divisie,Jong Ajax,Cambuur,3,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,FC Den Bosch,1,1
Turkey-Super_Lig,Kayserispor,Galatasaray,1,3
International-Club_Friendlies,FK Neftchi,SKA-Khabarovsk,1,8
International-Club_Friendlies,FC Viitorul Constanta,FC Rostov,1,1
International-Club_Friendlies,FC Krasnodar,Lokomotiv Tashkent,2,1
International-Club_Friendlies,Spartak Moscow,FC Astana,2,3
International-Club_Friendlies,KF Shkendija,FC Zuerich,1,2
International-Club_Friendlies,Dinamo Bucuresti,Austria Wien,3,2
International-Club_Friendlies,Dunav Ruse,SKN St. Poelten,0,1
International-Club_Friendlies,Alki Oroklinis,FC Ufa,0,7
International-Club_Friendlies,Athletic Bilbao,Rudes,0,0
International-Club_Friendlies,CSKA Moscow,AC Horsens,2,2
International-Club_Friendlies,Broendby IF,Guangzhou Evergrande,3,3
International-Club_Friendlies,Mattersburg,Saarbruecken,1,0
International-Club_Friendlies,Zenit St. Petersburg,FC Koebenhavn,5,0
International-Club_Friendlies,Boca Juniors,River Plate,0,1
International-Club_Friendlies,Rapid Wien,CFR Cluj,1,3
Egypt-Premier_League,Ismaily SC,Alassiouty,1,1
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Al Mokawloon Al Arab,1,1
France-Ligue_2,Paris FC,AC Ajaccio,2,1
Italy-Serie_C_Grp__A,Lucchese,Livorno,1,1
Italy-Serie_C_Grp__B,AlbinoLeffe,Renate,2,0
Turkey-1__Lig,Denizlispor,Adanaspor,3,1
Turkey-1__Lig,Gazisehir Gaziantep FK,Samsunspor,3,0
Brazil-Carioca_2nd_Stage_Relegation_Group,Goytacaz,Bonsucesso FC,2,2
Brazil-Paulista_A1,Santos FC,Bragantino,0,1
Brazil-Potiguar_1st_Group_Stage,Forca e Luz,Globo FC,0,1
Brazil-Sao_Paulo_Youth_Cup_Final_Stage,Flamengo U20,Portuguesa U20,3,2
Cyprus-1__Division,Ermis Aradippou,Olympiakos Nicosia,4,0
DR_Congo-Super_League_Zone_East,Muungano,Mont Bleu,1,1
Germany-3__Liga,RW Erfurt,Magdeburg,3,1
International-Copa_Libertadores_Qualification,CSD Macara,Deportivo Tachira,1,1
International-Copa_Libertadores_Qualification,Oriente Petrolero,Universitario de Deportes,2,0
International-AFC_Champions_League_Qualification,Brisbane Roar FC,Ceres-Negros FC,2,3
International-AFC_Champions_League_Qualification,Muang Thong United,Johor Darul Ta'zim FC,5,2
International-AFC_Champions_League_Qualification,Chiangrai United,Bali United Pusam,2,1
International-AFC_Champions_League_Qualification,Eastern Sports Club,FLC Thanh Hoa,2,4
International-African_Nations_Championship_Grp__C,Rwanda,Libya,0,1
International-African_Nations_Championship_Grp__C,Equatorial Guinea,Nigeria,1,3
Belgium-First_Division_A,St.Truiden,KV Mechelen,2,0
Belgium-First_Division_A,Royal Excel Mouscron,Kortrijk,0,3
Belgium-First_Division_A,Zulte-Waregem,Standard Liege,2,1
England-EFL_Cup,Bristol City,Manchester City,2,3
France-Coupe_de_France,Nantes,Auxerre,3,4
France-Coupe_de_France,Chateauroux,Chambly,4,5
France-Coupe_de_France,US Granvillaise,Concarneau,3,2
France-Coupe_de_France,Bourg en Bresse Peronnas,Toulouse,2,0
France-Coupe_de_France,US Colomiers,Sochaux,1,2
France-Coupe_de_France,Stade Briochin,Lens,0,1
France-Coupe_de_France,Epinal,Marseille,0,2
France-Coupe_de_France,Canet Roussillon,Caen,4,5
Germany-2__Bundesliga,Ingolstadt,Sandhausen,0,0
Germany-2__Bundesliga,Nuernberg,Jahn Regensburg,2,2
Germany-2__Bundesliga,Holstein Kiel,Union Berlin,2,2
Germany-2__Bundesliga,Bochum,Duisburg,0,2
Scotland-Premiership,Partick Thistle,Celtic,1,2
Scotland-FA_Cup,Peterhead,Dumbarton,2,3
Scotland-FA_Cup,Livingston,Falkirk,0,1
Spain-Copa_del_Rey,Sevilla,Atletico Madrid,3,1
International-Club_Friendlies,Spartak Trnava,FC Rostov,
International-Club_Friendlies,Kristiansund BK,Brattvaag,
International-Club_Friendlies,Lokomotiv Moscow,Tianjin Quanjian,1,1
International-Club_Friendlies,Arsenal Tula,FC Viktoria 1889 Berlin,
International-Club_Friendlies,Dinamo Moscow,Stumbras Kaunas,0,0
International-Club_Friendlies,Haecken,Utsiktens BK,5,0
International-Club_Friendlies,SKN St. Poelten,Dinamo Moscow,
International-Club_Friendlies,Sturm Graz,Dynamo Kyiv,2,0
International-Club_Friendlies,Arsenal Tula,Tennis Borussia,2,2
International-Club_Friendlies,Bayer Leverkusen,Oberhausen,3,1
International-Club_Friendlies,Hobro,Skive,2,1
International-Club_Friendlies,Thun,Wil,1,1
Italy-Serie_A,Lazio,Udinese,3,0
Italy-Serie_A,Sampdoria,Roma,1,1
Netherlands-Eredivisie,FC Utrecht,Feyenoord,1,1
International-African_Nations_Championship_Grp__D,Congo,Angola,0,0
International-African_Nations_Championship_Grp__D,Burkina Faso,Cameroon,1,1
Belgium-First_Division_A,Anderlecht,Waasland-Beveren,2,2
Belgium-First_Division_A,Royal Antwerp,Gent,1,1
Belgium-First_Division_A,Eupen,Sporting Charleroi,1,0
Belgium-First_Division_A,Lokeren,Genk,1,2
England-EFL_Cup,Arsenal,Chelsea,2,1
France-Coupe_de_France,ST Lo Manche,Les Herbiers,1,2
France-Coupe_de_France,Paris Saint Germain,Guingamp,4,2
France-Coupe_de_France,Montpellier,Lorient,4,3
France-Coupe_de_France,Tours,Metz,1,2
France-Coupe_de_France,Troyes,Saint-Etienne,5,4
France-Coupe_de_France,Monaco,Lyon,2,3
France-Coupe_de_France,ASC Biesheim,Grenoble,2,5
Germany-2__Bundesliga,Fortuna Duesseldorf,Erzgebirge Aue,2,1
Germany-2__Bundesliga,Arminia Bielefeld,Greuther Fuerth,0,0
Germany-2__Bundesliga,Darmstadt,Kaiserslautern,X
Germany-2__Bundesliga,FC Heidenheim,Eintracht Braunschweig,2,0
Scotland-Premiership,Motherwell,Ross County,2,0
Scotland-Premiership,Rangers,Aberdeen,2,0
Scotland-Premiership,Hamilton Academical,Hearts,0,3
Scotland-Premiership,Dundee FC,Hibernian,0,1
Spain-Copa_del_Rey,Real Madrid,Leganes,1,2
Spain-Copa_del_Rey,Alaves,Valencia,4,4
International-Club_Friendlies,Fremad Amager,FC Helsingoer,3,5
International-Club_Friendlies,GIF Sundsvall,Oestersunds FK,1,0
International-Club_Friendlies,Vaalerenga,FC Seoul,
International-Club_Friendlies,Oerebro,Rynninge,0,1
International-Club_Friendlies,Anorthosis,Austria Wien,
International-Club_Friendlies,Thun,Sion,0,0
International-Club_Friendlies,FK Mladost Doboj Kakanj,Tosno,0,1
International-Club_Friendlies,Basel,Winterthur,1,0
International-Club_Friendlies,Lugano,US Gavorrano,2,1
International-Club_Friendlies,Vaalerenga,Silkeborg,2,1
International-Club_Friendlies,Amkar,Korona Kielce,3,0
Egypt-Premier_League,El Zamalek,Al Masry,0,1
Egypt-Premier_League,El Geish,El Dakhleya,0,2
Argentina-Superliga,Independiente,Rosario Central,1,1
Australia-A_League,Melbourne City FC,Newcastle Jets,2,2
Belgium-First_Division_A,Club Brugge,Oostende,3,2
France-Coupe_de_France,Strasbourg,Lille,2,1
Germany-2__Bundesliga,Dynamo Dresden,St. Pauli,1,3
Spain-Copa_del_Rey,Barcelona,Espanyol,2,0
International-Club_Friendlies,Mjoendalen,Sandefjord,6,1
International-Club_Friendlies,PFC CSKA-Sofia,AaB,
International-Club_Friendlies,Odds Ballklubb,Shanghai Shenxin,3,1
International-Club_Friendlies,FC Ufa,Wisla Plock,1,0
International-Club_Friendlies,FK Akhmat,Alanyaspor,
International-Club_Friendlies,IK Frej Taeby,Dalkurd FF,1,2
International-Club_Friendlies,FK Akhmat,FC Kyzylzhar Petropavlovsk,1,0
International-Club_Friendlies,Lokomotiv Moscow,PFC CSKA-Sofia,
International-Club_Friendlies,OB,Vejle Boldklub,4,0
International-Club_Friendlies,FC Koebenhavn,Guangzhou Evergrande,0,0
International-Club_Friendlies,Zenit St. Petersburg,Slavia Prague,5,1
International-Club_Friendlies,Astra Giurgiu,Ural,0,1
International-Club_Friendlies,Admira Moedling,FC FCSB,3,2
Egypt-Premier_League,El Raja Marsa Matruh,Al Ahly,1,3
Egypt-Premier_League,Misr El-Maqasa,El Entag El Harby,3,1
Greece-Cup_Final_Stage,PAS Giannina,AE Larissa,1,2
Israel-Cup,Beitar Jerusalem,Hapoel Marmorek,2,1
Algeria-Ligue_1,US Biskra,ES Setif,1,0
Argentina-Primera_B_Metropolitana,CA Talleres Remedios de Escalada,Barracas Central,2,0
Brazil-Alagoano,CE Olhodaguense,Clube Sociedade Esportiva,0,1
Brazil-Alagoano,Coruripe,CRB,1,2
Brazil-Alagoano,CS Alagoano,Murici,4,0
Brazil-Baiano,Juazeirense,Jacobina,1,0
Brazil-Baiano,Fluminense de Feira,Atlantico EC,2,1
Brazil-Baiano,Bahia,EC Jacuipense,2,1
Brazil-Baiano,Jequie,Bahia de Feira,2,2
Brazil-Baiano,Vitoria da Conquista,Vitoria,0,2
Brazil-Carioca_Taca_Guanabara_Grp__B,Nova Iguacu,Volta Redonda,2,0
Brazil-Carioca_Taca_Guanabara_Grp__C,Fluminense,Portuguesa RJ,0,0
Brazil-Carioca_Taca_Guanabara_Grp__C,Macae,Botafogo RJ,1,2
Brazil-Catarinense,Criciuma,Chapecoense AF,0,0
Brazil-Cearense_1st_Group_Stage,Floresta,Ceara,3,1
Brazil-Cearense_1st_Group_Stage,Guarani de Juazeiro,Maranguape,2,0
Brazil-Cearense_1st_Group_Stage,Horizonte,AE Tiradentes,2,2
England-FA_Cup,Sheffield Wednesday,Reading,3,1
England-FA_Cup,Yeovil Town,Manchester United,0,4
France-Ligue_1,Dijon,Rennes,2,1
Germany-1__Bundesliga,Eintracht Frankfurt,Borussia Moenchengladbach,2,0
Netherlands-Eredivisie,SC Heerenveen,Sparta Rotterdam,2,1
Spain-Primera_Division,Athletic Bilbao,Eibar,1,1
Argentina-Superliga,Godoy Cruz,Chacarita Juniors,1,0
Argentina-Superliga,Tigre,Banfield,1,2
Australia-A_League,Melbourne Victory,Sydney FC,1,3
Belgium-First_Division_A,KV Mechelen,Royal Excel Mouscron,0,2
Germany-2__Bundesliga,Union Berlin,Nuernberg,0,1
Germany-2__Bundesliga,Jahn Regensburg,Ingolstadt,3,2
Italy-Serie_B,Pescara,Perugia,0,2
Netherlands-Eerste_Divisie,NEC Nijmegen,FC Den Bosch,1,0
Netherlands-Eerste_Divisie,Telstar,Jong AZ Alkmaar,2,1
Netherlands-Eerste_Divisie,FC Dordrecht,FC Oss,2,0
Netherlands-Eerste_Divisie,MVV Maastricht,De Graafschap,1,3
Netherlands-Eerste_Divisie,Fortuna Sittard,FC Emmen,1,2
Netherlands-Eerste_Divisie,Helmond Sport,Almere City FC,1,2
Netherlands-Eerste_Divisie,RKC Waalwijk,Jong Ajax,2,4
Netherlands-Eerste_Divisie,Jong FC Utrecht,Cambuur,1,3
N__Ireland-Premiership,Glenavon,Warrenpoint Town,3,3
N__Ireland-Premiership,Ballinamallard United,Cliftonville,6,4
Spain-Segunda_Division,Zaragoza,Cordoba,1,0
Turkey-Super_Lig,Genclerbirligi,Konyaspor,2,1
Turkey-Super_Lig,Besiktas,Kasimpasa,2,1
Belgium-First_Division_B_2nd_Stage,Oud-Heverlee,Westerlo,0,1
International-Club_Friendlies,SKN St. Poelten,Tromsoe,1,0
International-Club_Friendlies,AaB,Shonan Bellmare,3,2
International-Club_Friendlies,Ull/Kisa,Stabaek,5,1
International-Club_Friendlies,Slovan Liberec,Austria Wien,1,1
International-Club_Friendlies,FC Midtjylland,Vendsyssel FF,0,2
International-Club_Friendlies,FC Krasnodar,FC Astana,1,3
International-Club_Friendlies,Malmundaria,Flora Tallinn,
International-Club_Friendlies,Stroemsgodset,Bodoe/Glimt,2,1
International-Club_Friendlies,Malmoe FF,Flora Tallinn,4,0
International-Club_Friendlies,Lyngby,HB Koege,0,0
Finland-Cup_Grp__B,VPS,FF Jaro,2,0
Finland-Cup_Grp__D,IF Gnistan,HJK,0,8
France-Ligue_2,Auxerre,SC Bastia,
International-Copa_Libertadores_Qualification,Olimpia,Montevideo Wanderers,2,0
International-Copa_Libertadores_Qualification,Universitario de Deportes,Oriente Petrolero,3,1
International-Copa_Libertadores_Qualification,Deportivo Tachira,CSD Macara,0,0
England-FA_Cup,Liverpool,West Bromwich Albion,2,3
England-FA_Cup,Millwall,Rochdale,2,2
England-FA_Cup,Southampton,Watford,1,0
England-FA_Cup,Huddersfield Town,Birmingham City,1,1
England-FA_Cup,Sheffield United,Preston North End,1,0
England-FA_Cup,Middlesbrough,Brighton &amp; Hove Albion,0,1
England-FA_Cup,Hull City,Nottingham Forest,2,1
England-FA_Cup,Wigan Athletic,West Ham United,2,0
England-FA_Cup,Milton Keynes Dons,Coventry City,0,1
England-FA_Cup,Notts County,Swansea City,1,1
England-FA_Cup,Peterborough United,Leicester City,1,5
England-FA_Cup,Newport County,Tottenham Hotspur,1,1
France-Ligue_1,Paris Saint Germain,Montpellier,4,0
France-Ligue_1,Angers,Amiens,1,0
France-Ligue_1,Saint-Etienne,Caen,2,1
France-Ligue_1,Toulouse,Troyes,1,0
France-Ligue_1,Guingamp,Nantes,0,3
France-Ligue_1,Metz,Nice,2,1
Germany-1__Bundesliga,Bayern Munich,Hoffenheim,5,2
Germany-1__Bundesliga,Borussia Dortmund,Freiburg,2,2
Germany-1__Bundesliga,RasenBallsport Leipzig,Hamburger SV,1,1
Germany-1__Bundesliga,Werder Bremen,Hertha Berlin,0,0
Germany-1__Bundesliga,VfB Stuttgart,Schalke 04,0,2
Germany-1__Bundesliga,FC Cologne,Augsburg,1,1
Italy-Serie_A,Sassuolo,Atalanta,0,3
Italy-Serie_A,ChievoVerona,Juventus,0,2
Netherlands-Eredivisie,FC Groningen,Heracles,3,3
Netherlands-Eredivisie,NAC Breda,VVV-Venlo,0,1
Netherlands-Eredivisie,PEC Zwolle,Vitesse,1,2
Netherlands-Eredivisie,FC Twente,PSV Eindhoven,0,2
Spain-Primera_Division,Deportivo La Coruna,Levante,2,2
Spain-Primera_Division,Villarreal,Real Sociedad,4,2
Spain-Primera_Division,Malaga,Girona,0,0
Spain-Primera_Division,Valencia,Real Madrid,1,4
International-African_Nations_Championship_Final_Stage,Morocco,Namibia,2,0
International-African_Nations_Championship_Final_Stage,Zambia,Sudan,0,1
Argentina-Superliga,Lanus,Patronato de Parana,1,1
England-FA_Cup,Chelsea,Newcastle United,3,0
England-FA_Cup,Cardiff City,Manchester City,0,2
France-Ligue_1,Marseille,Monaco,2,2
France-Ligue_1,Lille,Strasbourg,2,1
France-Ligue_1,Bordeaux,Lyon,3,1
Germany-1__Bundesliga,Bayer Leverkusen,Mainz 05,2,0
Germany-1__Bundesliga,Hannover 96,Wolfsburg,0,1
Italy-Serie_A,SSC Napoli,Bologna,3,1
Italy-Serie_A,Fiorentina,Hellas Verona,1,4
Italy-Serie_A,Roma,Sampdoria,0,1
Italy-Serie_A,Torino,Benevento,3,0
Italy-Serie_A,Genoa,Udinese,0,1
Italy-Serie_A,AC Milan,Lazio,2,1
Italy-Serie_A,Crotone,Cagliari,1,1
Italy-Serie_A,SPAL 2013,Inter,1,1
Netherlands-Eredivisie,Feyenoord,ADO Den Haag,3,1
Netherlands-Eredivisie,Roda JC Kerkrade,Excelsior,2,1
Netherlands-Eredivisie,Willem II,AZ Alkmaar,0,2
Netherlands-Eredivisie,FC Utrecht,Ajax,0,0
Spain-Primera_Division,Barcelona,Alaves,2,1
Spain-Primera_Division,Atletico Madrid,Las Palmas,3,0
Spain-Primera_Division,Sevilla,Getafe,1,1
Spain-Primera_Division,Leganes,Espanyol,3,2
International-African_Nations_Championship_Final_Stage,Nigeria,Angola,2,1
International-African_Nations_Championship_Final_Stage,Congo,Libya,4,6
Argentina-Superliga,Boca Juniors,Colon,2,0
Argentina-Superliga,Argentinos Juniors,San Martin San Juan,2,0
Argentina-Superliga,Olimpo,Belgrano,1,2
Australia-A_League,Perth Glory,Western Sydney Wanderers FC,3,1
Belgium-First_Division_A,Oostende,Lokeren,2,3
Belgium-First_Division_A,Standard Liege,Anderlecht,3,3
Belgium-First_Division_A,Gent,Club Brugge,2,0
Germany-2__Bundesliga,St. Pauli,Darmstadt,0,1
Germany-2__Bundesliga,Sandhausen,Dynamo Dresden,1,0
Germany-2__Bundesliga,Erzgebirge Aue,Eintracht Braunschweig,1,3
Greece-Super_League,Atromitos,AE Larissa,1,0
Greece-Super_League,Panionios,PAS Giannina,0,1
Greece-Super_League,Xanthi,Levadiakos,2,1
Greece-Super_League,Asteras Tripolis,Olympiacos,1,1
Greece-Super_League,Panetolikos,PAOK Thessaloniki FC,0,1
Portugal-Primeira_Liga,Pacos de Ferreira,Feirense,2,1
Portugal-Primeira_Liga,Portimonense,Rio Ave,4,1
Portugal-Primeira_Liga,Belenenses,Benfica,1,1
Spain-Primera_Division,Celta Vigo,Real Betis,3,2
Argentina-Superliga,Atletico Tucuman,Temperley,3,0
Argentina-Superliga,Union,Racing Club,2,1
Argentina-Superliga,Gimnasia LP,Rosario Central,2,1
Argentina-Superliga,Huracan,River Plate,1,0
International-Friendlies,USA,Bosnia and Herzegovina,0,0
Germany-2__Bundesliga,Bochum,Arminia Bielefeld,0,1
Israel-Ligat_HaAl,Maccabi Netanya,Beitar Jerusalem,2,1
Italy-Serie_B,Ternana,Salernitana,2,2
Mexico-Liga_MX_Clausura,Veracruz,Santos,1,1
Netherlands-Eerste_Divisie,Jong PSV,FC Eindhoven,4,1
N__Ireland-Premiership,Cliftonville,Glenavon,1,1
Scotland-FA_Cup,Albion Rovers,St.Johnstone,0,4
Turkey-Super_Lig,Istanbul Basaksehir,Karabukspor,5,0
International-Club_Friendlies,Zaglebie Lubin,Hobro,0,0
International-Club_Friendlies,DAC 1904 Dunajska Streda,FC Helsingoer,1,1
International-Club_Friendlies,OB,Videoton FC,
International-Club_Friendlies,Ural,Ararat Moscow,2,1
International-Club_Friendlies,Elfsborg,Brann,2,0
International-Club_Friendlies,Broendby IF,Slavia Prague,2,2
International-Club_Friendlies,Piast Gliwice,CSKA Moscow,0,0
Egypt-Premier_League,El Entag El Harby,El Raja Marsa Matruh,2,1
Egypt-Premier_League,Smouha SC,Wadi Degla FC,2,1
Egypt-Premier_League,Tanta,Petrojet,0,0
France-Ligue_2,Reims,Lorient,0,1
Italy-Serie_C_Grp__C,Catania,Virtus Francavilla,1,0
Portugal-Segunda_Liga,Academica,Uniao da Madeira,4,2
Portugal-Segunda_Liga,Arouca,Cova da Piedade,0,0
Portugal-Segunda_Liga,Sporting CP B,Real SC,2,1
Portugal-Segunda_Liga,Gil Vicente,Varzim,0,1
Portugal-Segunda_Liga,Vitoria de Guimaraes B,Sporting Covilha,3,0
Turkey-1__Lig,Istanbulspor,Denizlispor,2,1
Argentina-Primera_B_Metropolitana,Sacachispas FC,CA Talleres Remedios de Escalada,1,0
Argentina-Primera_C,Sportivo Barracas,Excursionistas,2,0
Bolivia-Primera_Division___Apertura,Blooming,Royal Pari,2,2
Brazil-Carioca_Taca_Guanabara_Grp__B,Volta Redonda,AD Cabofriense,3,2
Brazil-Gaucho,Sao Luiz,Brasil de Pelotas,0,0
International-Copa_Libertadores_Qualification,Carabobo FC,Guarani,1,0
England-Premier_League,West Ham United,Crystal Palace,1,1
England-Premier_League,Swansea City,Arsenal,3,1
England-Premier_League,Huddersfield Town,Liverpool,0,3
Portugal-Primeira_Liga,Braga,Aves,2,0
Portugal-Primeira_Liga,Estoril,Tondela,3,0
Portugal-Primeira_Liga,Moreirense,FC Porto,0,0
International-AFC_Champions_League_Qualification,Tianjin Quanjian,Ceres-Negros FC,2,0
International-AFC_Champions_League_Qualification,Zob Ahan,Aizawl,3,1
International-AFC_Champions_League_Qualification,Shanghai SIPG FC,Chiangrai United,1,0
International-AFC_Champions_League_Qualification,Al-Ain,Malkia,2,0
International-AFC_Champions_League_Qualification,Suwon Bluewings,FLC Thanh Hoa,5,1
International-AFC_Champions_League_Qualification,Kashiwa Reysol,Muang Thong United,3,0
International-AFC_Champions_League_Qualification,Nasaf Qarshi,Al-Faisaly,5,1
International-AFC_Champions_League_Qualification,Al-Garrafa,Pakhtakor Tashkent,2,1
Argentina-Superliga,Independiente,Estudiantes,1,2
England-Championship,Middlesbrough,Sheffield Wednesday,0,0
England-Championship,Birmingham City,Sunderland,3,1
England-Championship,Hull City,Leeds United,0,0
England-Championship,Sheffield United,Aston Villa,0,1
England-Championship,Millwall,Derby County,0,0
England-Championship,Nottingham Forest,Preston North End,0,3
England-Championship,Burton Albion,Reading,1,3
International-Friendlies,South Korea,Jamaica,2,2
International-Friendlies,Azerbaijan,Moldova,0,0
Italy-Coppa_Italia,Atalanta,Juventus,0,1
Netherlands-KNVB_Cup,FC Twente,Cambuur,3,1
N__Ireland-Premiership,Coleraine,Linfield,2,2
N__Ireland-League_Cup,Dungannon Swifts,Crusaders,2,1
Scotland-Premiership,Celtic,Hearts,3,1
Scotland-FA_Cup,Formartine United,Cove Rangers,0,2
Scotland-FA_Cup,Inverness CT,Dundee FC,0,1
Turkey-Cup,Besiktas,Genclerbirligi,3,1
Belgium-Cup,Kortrijk,Genk,3,2
International-Club_Friendlies,SoenderjyskE,Banik Ostrava,0,1
International-Club_Friendlies,Trencin,Dinamo Moscow,1,3
International-Club_Friendlies,Jablonec,Hammarby,
International-Club_Friendlies,FC Nordsjaelland,FC Seoul,3,0
International-Club_Friendlies,Salzburg,USK Anif,4,1
International-Club_Friendlies,FC Rapperswil-Jona,Luzern,0,3
International-Copa_Libertadores_Qualification,Banfield,Independiente del Valle,1,1
International-Copa_Libertadores_Qualification,Santiago Wanderers,FBC Melgar,1,1
England-Premier_League,Manchester City,West Bromwich Albion,3,0
England-Premier_League,Chelsea,AFC Bournemouth,0,3
England-Premier_League,Southampton,Brighton &amp; Hove Albion,1,1
England-Premier_League,Stoke City,Watford,0,0
England-Premier_League,Newcastle United,Burnley,1,1
England-Premier_League,Tottenham Hotspur,Manchester United,2,0
England-Premier_League,Everton,Leicester City,2,1
Portugal-Primeira_Liga,Sporting CP,Vitoria de Guimaraes,1,0
Portugal-Primeira_Liga,Chaves,Vitoria de Setubal,2,2
Portugal-Primeira_Liga,Boavista,Maritimo,2,1
International-African_Nations_Championship_Final_Stage,Morocco,Libya,3,1
International-African_Nations_Championship_Final_Stage,Sudan,Nigeria,0,1
Italy-Coppa_Italia,AC Milan,Lazio,0,0
Netherlands-KNVB_Cup,AZ Alkmaar,PEC Zwolle,4,1
Netherlands-KNVB_Cup,Feyenoord,PSV Eindhoven,2,0
Scotland-Premiership,Hibernian,Motherwell,2,1
Scotland-Premiership,Ross County,Aberdeen,2,4
Scotland-FA_Cup,Fraserburgh,Rangers,0,3
Spain-Copa_del_Rey,Leganes,Sevilla,1,1
Turkey-Cup,Akhisar Belediye Genclik Ve Spor,Kayserispor,1,0
Turkey-Cup,Giresunspor,Fenerbahce,1,2
Belgium-Cup,Standard Liege,Club Brugge,4,1
International-Club_Friendlies,OB,Odds Ballklubb,1,3
International-Club_Friendlies,Anzhi Makhachkala,Sumqayit,1,0
International-Club_Friendlies,Grasshopper,Schaffhausen,2,1
International-Club_Friendlies,Sparta Prague,AaB,2,1
International-Club_Friendlies,Cherno More Varna,Tosno,1,0
International-Club_Friendlies,FK Crvena Zvezda,Amkar,1,1
International-Club_Friendlies,FC Nordsjaelland,Odds Ballklubb,
International-Club_Friendlies,Spartak Moscow,PFC CSKA-Sofia,0,0
International-Club_Friendlies,FC Zuerich,Winterthur,1,1
Egypt-Premier_League,Al Masry,El Geish,0,0
Egypt-Premier_League,ENPPI,El Zamalek,0,0
England-League_2,Exeter City,Forest Green Rovers,2,0
France-League_Cup,Monaco,Montpellier,2,0
Portugal-Segunda_Liga,Penafiel,FC Porto B,1,0
Portugal-Segunda_Liga,Leixoes,Academico Viseu,1,1
Spain-Segunda_B_Grp__I,Gimnastica Segoviana,Atletico Madrid B,0,2
International-Copa_Libertadores_Qualification,Chapecoense AF,Nacional,0,1
International-Copa_Libertadores_Qualification,Universidad de Concepcion,Vasco da Gama,0,4
International-Copa_Libertadores_Qualification,Deportivo Tachira,Santa Fe,2,3
International-Friendlies,Mexico,Bosnia and Herzegovina,1,0
Netherlands-KNVB_Cup,Willem II,Roda JC Kerkrade,7,6
Spain-Copa_del_Rey,Barcelona,Valencia,1,0
Turkey-Cup,Konyaspor,Galatasaray,2,2
International-Club_Friendlies,Dukla Praha,FC Rostov,1,3
International-Club_Friendlies,Stroemmen,Stabaek,2,1
International-Club_Friendlies,Ranheim,Stjoerdals Blink,2,0
International-Club_Friendlies,Oerebro,F91 Dudelange,0,0
International-Club_Friendlies,Malaga,Shonan Bellmare,0,0
International-Club_Friendlies,Tromsoe,Rubin Kazan,1,0
Wales-Premier_League,Connah's Quay,Bala Town,1,1
Andorra-1__Division,Encamp,Sant Julia,0,1
Argentina-Primera_C,Excursionistas,Canuelas,1,1
Australia-National_Youth_League,Adelaide United Youth,Brisbane Roar FC Youth,4,1
Bolivia-Primera_Division___Apertura,Real Potosi,Universitario,4,4
Brazil-Cup,Independente PA,Sampaio Correa,0,1
Brazil-Cup,AO Itabaiana,Joinville,0,1
Brazil-Cup,Madureira RJ,Sao Paulo,0,1
Brazil-Cup,Novoperario FC,Salgueiro,2,3
Brazil-Cup,Floresta,Botafogo PB,0,2
Brazil-Cup,Real Desportivo Ariquemes,Londrina EC,0,1
Brazil-Cup,Uniao Recreativa dos Trabalhadores,Parana Clube,1,1
Brazil-Cup,EC Cordino,Nautico,1,1
Brazil-Cup,Interporto,Juventude,0,0
Brazil-Cup,Treze,Figueirense,0,2
Brazil-Cup,Fluminense de Feira,Santa Cruz,2,0
Brazil-Copa_do_Nordeste_Grp__A,CRB,Confianca,3,1
Brazil-Alagoano,Clube Sociedade Esportiva,ASA,1,2
Brazil-Brasiliense,Gama,Paranoa EC,2,1
Brazil-Cearense_1st_Group_Stage,Ceara,Uniclinic Atletico Clube,2,0
Brazil-Goiano,Ipora,Itumbiara,1,0
Brazil-Goiano,Goias,Gremio Anapolis,2,0
International-Caribbean_Professional_Club_Championship_Grp__A,W Connection FC,Real Hope FA,0,1
Colombia-Primera_A_Championship_Final,Millonarios,Atletico Nacional,0,0
Costa_Rica-Primera_Division_Clausura,Municipal Perez Zeledon,Grecia,1,0
Costa_Rica-Primera_Division_Clausura,AD Municipal Liberia,Deportiva Carmelita,0,1
Costa_Rica-Primera_Division_Clausura,C.S. Cartagines,Santos de Guapiles,0,3
International-Copa_Libertadores_Qualification,Olimpia,Atletico Junior,1,0
International-Copa_Libertadores_Qualification,Oriente Petrolero,Jorge Wilstermann,1,2
France-Ligue_1,Marseille,Metz,6,3
Germany-1__Bundesliga,FC Cologne,Borussia Dortmund,2,3
Netherlands-Eredivisie,Vitesse,FC Groningen,2,0
Spain-Primera_Division,Real Sociedad,Deportivo La Coruna,5,0
Argentina-Superliga,Patronato de Parana,Godoy Cruz,0,0
Argentina-Superliga,Argentinos Juniors,Defensa y Justicia,2,1
Australia-A_League,Sydney FC,Wellington Phoenix,4,0
Belgium-First_Division_A,Royal Antwerp,Waasland-Beveren,1,2
England-Championship,Bolton Wanderers,Bristol City,1,0
International-Friendlies,Azerbaijan,Kosovo,
International-Friendlies,Azerbaijan,Georgia,
Germany-2__Bundesliga,Nuernberg,Erzgebirge Aue,4,1
Germany-2__Bundesliga,Fortuna Duesseldorf,Sandhausen,1,0
Italy-Serie_B,Empoli,Palermo,4,0
Netherlands-Eerste_Divisie,De Graafschap,Jong FC Utrecht,7,0
Netherlands-Eerste_Divisie,Cambuur,Go Ahead Eagles,2,1
Netherlands-Eerste_Divisie,Almere City FC,FC Dordrecht,1,2
Netherlands-Eerste_Divisie,FC Eindhoven,RKC Waalwijk,3,1
Netherlands-Eerste_Divisie,FC Den Bosch,Telstar,3,2
Netherlands-Eerste_Divisie,FC Volendam,Fortuna Sittard,2,0
Netherlands-Eerste_Divisie,FC Emmen,NEC Nijmegen,1,0
Romania-Liga_I,FC Viitorul Constanta,Astra Giurgiu,1,1
Romania-Liga_I,Sepsi OSK,ACS Poli Timisoara,1,0
Spain-Segunda_Division,Osasuna,Rayo Vallecano,1,1
Turkey-Super_Lig,Bursaspor,Besiktas,2,2
Belgium-First_Division_B_2nd_Stage,Oud-Heverlee,Cercle Brugge,2,2
International-Club_Friendlies,Djurgaarden,Syrianska,3,1
International-Club_Friendlies,Silkeborg,Randers FC,2,2
International-Club_Friendlies,Molde,Bodoe/Glimt,1,2
International-Club_Friendlies,Lokomotiv Moscow,Osijek,1,0
International-Club_Friendlies,Stabaek,Sandefjord,1,0
International-Club_Friendlies,FC Nordsjaelland,CSKA Moscow,1,1
International-Club_Friendlies,Vaalerenga,Kristiansund BK,2,1
Egypt-Premier_League,Al Mokawloon Al Arab,Alassiouty,1,1
Egypt-Premier_League,Petrojet,Smouha SC,2,1
Egypt-Premier_League,Al Nasr,Wadi Degla FC,0,1
Finland-Cup_Grp__A,RoPS,PS Kemi,1,2
Finland-Cup_Grp__A,KuPS,AC Kajaani,6,1
England-Premier_League,Manchester United,Huddersfield Town,2,0
England-Premier_League,Arsenal,Everton,5,1
England-Premier_League,Leicester City,Swansea City,1,1
England-Premier_League,AFC Bournemouth,Stoke City,2,1
England-Premier_League,Brighton &amp; Hove Albion,West Ham United,3,1
England-Premier_League,West Bromwich Albion,Southampton,2,3
England-Premier_League,Burnley,Manchester City,1,1
France-Ligue_1,Nice,Toulouse,0,1
France-Ligue_1,Montpellier,Angers,2,1
France-Ligue_1,Amiens,Saint-Etienne,0,2
France-Ligue_1,Strasbourg,Bordeaux,0,2
France-Ligue_1,Lille,Paris Saint Germain,0,3
Germany-1__Bundesliga,Schalke 04,Werder Bremen,1,2
Germany-1__Bundesliga,Wolfsburg,VfB Stuttgart,1,1
Germany-1__Bundesliga,Borussia Moenchengladbach,RasenBallsport Leipzig,0,1
Germany-1__Bundesliga,Hertha Berlin,Hoffenheim,1,1
Germany-1__Bundesliga,Freiburg,Bayer Leverkusen,0,0
Germany-1__Bundesliga,Mainz 05,Bayern Munich,0,2
Italy-Serie_A,Inter,Crotone,1,1
Italy-Serie_A,Sampdoria,Torino,1,1
Netherlands-Eredivisie,PSV Eindhoven,PEC Zwolle,4,0
Netherlands-Eredivisie,SC Heerenveen,FC Twente,1,0
Netherlands-Eredivisie,Heracles,ADO Den Haag,1,1
Portugal-Primeira_Liga,Benfica,Rio Ave,5,1
Portugal-Primeira_Liga,FC Porto,Braga,3,1
Spain-Primera_Division,Alaves,Celta Vigo,2,1
Spain-Primera_Division,Eibar,Sevilla,5,1
Spain-Primera_Division,Real Betis,Villarreal,2,1
Spain-Primera_Division,Levante,Real Madrid,2,2
International-African_Nations_Championship_Final_Stage,Libya,Sudan,3,5
Argentina-Superliga,Belgrano,Lanus,0,0
Argentina-Superliga,Rosario Central,Union,1,0
Argentina-Superliga,Colon,Independiente,0,1
Argentina-Superliga,Banfield,Atletico Tucuman,0,0
Australia-A_League,Adelaide United,Perth Glory,2,1
Australia-A_League,Newcastle Jets,Melbourne Victory,2,0
Austria-Bundesliga,Salzburg,Admira Moedling,2,1
Austria-Bundesliga,LASK,SKN St. Poelten,2,1
Austria-Bundesliga,Wolfsberger AC,Altach,0,0
Austria-Bundesliga,Mattersburg,Sturm Graz,1,0
England-Premier_League,Liverpool,Tottenham Hotspur,2,2
England-Premier_League,Crystal Palace,Newcastle United,1,1
France-Ligue_1,Rennes,Guingamp,0,1
France-Ligue_1,Monaco,Lyon,3,2
France-Ligue_1,Caen,Nantes,3,2
Germany-1__Bundesliga,Hamburger SV,Hannover 96,1,1
Germany-1__Bundesliga,Augsburg,Eintracht Frankfurt,3,0
Italy-Serie_A,Juventus,Sassuolo,7,0
Italy-Serie_A,Atalanta,ChievoVerona,1,0
Italy-Serie_A,Cagliari,SPAL 2013,2,0
Italy-Serie_A,Bologna,Fiorentina,1,2
Italy-Serie_A,Udinese,AC Milan,1,1
Italy-Serie_A,Hellas Verona,Roma,0,1
Italy-Serie_A,Benevento,SSC Napoli,0,2
Netherlands-Eredivisie,Ajax,NAC Breda,3,1
Netherlands-Eredivisie,AZ Alkmaar,Roda JC Kerkrade,2,2
Netherlands-Eredivisie,Sparta Rotterdam,Willem II,1,0
Netherlands-Eredivisie,Excelsior,FC Utrecht,2,2
Netherlands-Eredivisie,VVV-Venlo,Feyenoord,1,0
Portugal-Primeira_Liga,Vitoria de Guimaraes,Pacos de Ferreira,3,2
Portugal-Primeira_Liga,Tondela,Moreirense,1,2
Portugal-Primeira_Liga,Feirense,Chaves,1,2
Portugal-Primeira_Liga,Estoril,Sporting CP,2,0
Spain-Primera_Division,Atletico Madrid,Valencia,1,0
Spain-Primera_Division,Getafe,Leganes,0,0
Spain-Primera_Division,Girona,Athletic Bilbao,2,0
Spain-Primera_Division,Espanyol,Barcelona,1,1
International-African_Nations_Championship_Final_Stage,Morocco,Nigeria,4,0
Argentina-Superliga,River Plate,Olimpo,2,0
Argentina-Superliga,Estudiantes,Newells Old Boys,4,2
Argentina-Superliga,Arsenal Sarandi,Gimnasia LP,0,0
Argentina-Superliga,San Lorenzo,Boca Juniors,1,1
Australia-A_League,Central Coast Mariners,Western Sydney Wanderers FC,1,2
Australia-A_League,Brisbane Roar FC,Melbourne City FC,1,2
Austria-Bundesliga,Rapid Wien,Austria Wien,1,1
Belgium-First_Division_A,Club Brugge,Sporting Charleroi,3,3
Belgium-First_Division_A,Anderlecht,KV Mechelen,2,2
Belgium-First_Division_A,Zulte-Waregem,Oostende,1,1
Germany-2__Bundesliga,Eintracht Braunschweig,Kaiserslautern,1,2
Germany-2__Bundesliga,Dynamo Dresden,Bochum,2,0
England-Premier_League,Watford,Chelsea,4,1
Italy-Serie_A,Lazio,Genoa,1,2
Portugal-Primeira_Liga,Vitoria de Setubal,Belenenses,3,0
Portugal-Primeira_Liga,Maritimo,Portimonense,0,3
Spain-Primera_Division,Las Palmas,Malaga,1,0
Argentina-Superliga,Racing Club,Huracan,4,0
Argentina-Superliga,Chacarita Juniors,Velez Sarsfield,2,0
Argentina-Superliga,Temperley,Talleres,0,1
Germany-2__Bundesliga,Arminia Bielefeld,Union Berlin,1,1
Greece-Super_League,Platanias,Apollon Smirnis,1,1
Israel-Ligat_HaAl,Maccabi Petach Tikva,Hapoel Ashkelon,3,0
Italy-Serie_B,Entella,Spezia,0,1
Netherlands-Eerste_Divisie,Jong Ajax,Helmond Sport,2,0
Netherlands-Eerste_Divisie,Jong PSV,MVV Maastricht,1,0
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,FC Oss,3,1
Romania-Liga_I,CFR Cluj,Concordia Chiajna,2,0
Turkey-Super_Lig,Trabzonspor,Goztepe,0,0
International-Club_Friendlies,Kalmar FF,Lokomotiv Moscow,1,1
International-Club_Friendlies,Oerebro,FC Seoul,0,1
International-Club_Friendlies,Buducnost Podgorica,FC Rostov,0,0
Egypt-Premier_League,Misr El-Maqasa,Al Masry,1,4
France-Ligue_2,Brest,Reims,0,0
Italy-Serie_C_Grp__B,Triestina,Mestre,0,0
Spain-Segunda_B_Grp__IV,Cordoba B,Las Palmas B,2,1
Turkey-1__Lig,Altinordu,Balikesirspor,2,1
Argentina-Federal_A___Promotion___Zona_A,Estudiantes de Rio Cuarto,Deportivo Roca,6,1
Argentina-Federal_A___Promotion___Zona_A,CA Alvarado,Desamparados,0,0
Argentina-Federal_A___Promotion___Zona_A,Villa Mitre,Juventud Unida Universitario,0,1
Argentina-Federal_A___Relegation___1st_Stage_Zona_A,Club Cipolletti,Sansinena BB,0,1
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,San Lorenzo de Alem,Union Aconquija,0,0
Argentina-Primera_C,Sportivo Italiano,Leandro N. Alem,1,5
Argentina-Primera_C,Ituzaingo,Dock Sud,2,1
Australia-NPL_Youth_Queensland,Redlands United U20,Moreton Bay United U20,5,2
Australia-NPL_Youth_Queensland,Brisbane Strikers U20,Western Pride U20,0,1
Bolivia-Primera_Division___Apertura,Jorge Wilstermann,Destroyers,4,0
Bolivia-Primera_Division___Apertura,Oriente Petrolero,Guabira,5,2
Brazil-Brasiliense,Gama,Samambaia,3,0
Brazil-Gaucho,Avenida,Juventude,2,2
Brazil-Gaucho,Novo Hamburgo,Sao Paulo RG,0,0
Brazil-Goiano,Anapolis FC,Ipora,1,1
International-Copa_Libertadores_Qualification,Guarani,Carabobo FC,6,0
England-FA_Cup,Swansea City,Notts County,8,1
England-FA_Cup,Birmingham City,Huddersfield Town,1,4
England-FA_Cup,Rochdale,Millwall,1,0
Netherlands-Eredivisie,PEC Zwolle,SC Heerenveen,3,2
Portugal-Primeira_Liga,Aves,Boavista,3,0
Argentina-Superliga,San Martin San Juan,Tigre,0,0
France-Coupe_de_France,Auxerre,Les Herbiers,0,3
France-Coupe_de_France,Bourg en Bresse Peronnas,Marseille,0,9
France-Coupe_de_France,Sochaux,Paris Saint Germain,1,4
Germany-DFB_Pokal,Bayer Leverkusen,Werder Bremen,4,2
Germany-DFB_Pokal,Paderborn,Bayern Munich,0,6
N__Ireland-Premiership,Glentoran,Ballinamallard United,2,1
N__Ireland-Premiership,Warrenpoint Town,Linfield,1,3
N__Ireland-Premiership,Carrick Rangers,Crusaders,0,3
Scotland-Premiership,Motherwell,St.Johnstone,2,0
Scotland-Premiership,Partick Thistle,Rangers,0,2
Turkey-Cup,Genclerbirligi,Besiktas,0,1
Belgium-Cup,Genk,Kortrijk,1,0
International-Club_Friendlies,Arsenal Tula,Dinamo Tbilisi,0,1
International-Club_Friendlies,CSKA Moscow,Elche,3,0
International-Club_Friendlies,Joenkoepings Soedra,GIF Sundsvall,
International-Club_Friendlies,Rubin Kazan,Diosgyori VTK,2,0
International-Club_Friendlies,Vaalerenga,Kongsvinger,4,0
International-Club_Friendlies,FC Ufa,Nitra,0,0
International-Club_Friendlies,GIF Sundsvall,GAIS,3,5
International-Club_Friendlies,FC Krasnodar,Stroemsgodset,2,1
England-League_1,Bury,AFC Wimbledon,2,1
England-League_2,Accrington Stanley,Swindon Town,2,1
England-EFL_Trophy_Final_Stage,Lincoln City,Chelsea Academy,5,3
England-EFL_Trophy_Final_Stage,Yeovil Town,Fleetwood Town,3,2
Israel-Cup,Hapoel Kfar Saba,Beitar Jerusalem,0,2
Israel-Cup,Maccabi Haifa,Hapoel Haifa,2,2
Scotland-Championship,Falkirk,Brechin City,3,1
Scotland-League_One,Raith Rovers,Albion Rovers,3,1
Algeria-Ligue_1,CR Belouizdad,US Biskra,1,0
Algeria-Ligue_1,JS Saoura,ES Setif,0,0
Algeria-Ligue_1,Olympique de Medea,MC Alger,1,0
Argentina-Primera_B_Nacional,Agropecuario,Quilmes,1,1
Argentina-Primera_B_Metropolitana,CA Fenix,CA Talleres Remedios de Escalada,1,1
International-Copa_Libertadores_Qualification,Independiente del Valle,Banfield,2,2
International-Copa_Libertadores_Qualification,FBC Melgar,Santiago Wanderers,0,1
England-FA_Cup,Tottenham Hotspur,Newport County,2,0
Netherlands-Eredivisie,PSV Eindhoven,Excelsior,1,0
Netherlands-Eredivisie,FC Utrecht,Sparta Rotterdam,1,0
Netherlands-Eredivisie,NAC Breda,Heracles,6,1
Netherlands-Eredivisie,Willem II,VVV-Venlo,3,0
Netherlands-Eredivisie,FC Twente,AZ Alkmaar,0,4
Netherlands-Eredivisie,Roda JC Kerkrade,Ajax,2,4
France-Coupe_de_France,Chambly,US Granvillaise,1,0
France-Coupe_de_France,Lens,Troyes,1,0
France-Coupe_de_France,Metz,Caen,4,5
France-Coupe_de_France,Montpellier,Lyon,1,2
Germany-DFB_Pokal,Schalke 04,Wolfsburg,1,0
Germany-DFB_Pokal,Eintracht Frankfurt,Mainz 05,3,0
Spain-Copa_del_Rey,Sevilla,Leganes,2,0
Turkey-Cup,Fenerbahce,Giresunspor,2,1
Turkey-Cup,Kayserispor,Akhisar Belediye Genclik Ve Spor,2,2
International-Club_Friendlies,Debrecen,Tosno,3,0
International-Club_Friendlies,Rosenborg,Byaasen,2,3
International-Club_Friendlies,SKA-Khabarovsk,Baltika,0,3
International-Club_Friendlies,FK Akhmat,Zalgiris Vilnius,0,0
International-Club_Friendlies,Shakhtar Donetsk,AIK,2,0
International-Club_Friendlies,FC Nordsjaelland,FC Roskilde,1,2
International-Club_Friendlies,Zenit St. Petersburg,FK Crvena Zvezda,1,0
International-Club_Friendlies,FC Torrevieja,CSKA Moscow,0,7
International-Club_Friendlies,Fredericia,Hobro,2,1
International-Club_Friendlies,Dinamo Moscow,Amkar,2,1
International-Club_Friendlies,Spartak Moscow,Sparta Prague,2,1
Greece-Cup_Final_Stage,Lamia,Panionios,1,4
Greece-Cup_Final_Stage,AE Larissa,PAS Giannina,3,2
Greece-Cup_Final_Stage,AEK Athens,Olympiacos,2,1
Israel-Cup,Hapoel Beer Sheva,Hapoel Ironi Kiryat Shmona,1,1
Israel-Cup,FC Ashdod,Hapoel Raanana,1,1
Portugal-Cup,FC Porto,Sporting CP,1,0
Spain-Segunda_B_Grp__I,Guijuelo,Rapido de Bouzas,0,0
Argentina-Primera_B_Metropolitana,Atlanta,Deportivo Espanol,2,0
Argentina-Primera_B_Metropolitana,Villa San Carlos,Tristan Suarez,2,1
Argentina-Primera_B_Metropolitana,Sacachispas FC,Club Atletico Platense,1,2
Argentina-Primera_B_Metropolitana,CD UAI Urquiza,Barracas Central,1,2
International-Copa_Libertadores_Qualification,Vasco da Gama,Universidad de Concepcion,2,0
International-Copa_Libertadores_Qualification,Nacional,Chapecoense AF,1,0
Netherlands-Eredivisie,Feyenoord,FC Groningen,3,0
Netherlands-Eredivisie,ADO Den Haag,Vitesse,1,0
Argentina-Superliga,Godoy Cruz,Lanus,4,1
France-Coupe_de_France,Grenoble,Strasbourg,0,3
Netherlands-Eerste_Divisie,NEC Nijmegen,Jong PSV,2,0
Spain-Copa_del_Rey,Valencia,Barcelona,0,2
Turkey-Cup,Galatasaray,Konyaspor,4,1
Belgium-Cup,Club Brugge,Standard Liege,3,2
International-Club_Friendlies,Anzhi Makhachkala,Dinamo Minsk,2,0
International-Club_Friendlies,Irtysh Pavlodar,Tosno,1,0
International-Club_Friendlies,Videoton FC,FC Krasnodar,1,0
International-Club_Friendlies,Olimpija Ljubljana,FC Rostov,3,3
International-Club_Friendlies,Zenit St. Petersburg,Vejle Boldklub,0,2
International-Club_Friendlies,Ural,Gomel,5,2
International-Club_Friendlies,Sarpsborg 08,Kalmar FF,1,0
International-Club_Friendlies,Brann,Viking,3,2
International-Club_Friendlies,DC United,Malmoe FF,1,2
Egypt-Premier_League,Al Mokawloon Al Arab,Al Ahly,0,3
Greece-Cup_Final_Stage,Atromitos,PAOK Thessaloniki FC,1,3
Wales-Premier_League,Bala Town,Cefn Druids AFC,1,0
Argentina-Primera_B_Nacional,All Boys,Ferro Carril Oeste,3,3
Argentina-Primera_B_Metropolitana,Acassuso,CA Defensores de Belgrano,0,0
Bolivia-Primera_Division___Apertura,Nacional Potosi,The Strongest,0,1
Brazil-Cup,Uniao Rondonopolis,CRB,1,3
Brazil-Cup,Atletico Acreano,Atletico MG,1,1
Brazil-Cup,Manaus FC,CS Alagoano,2,2
Brazil-Cup,Corumbaense,ASA,1,0
Brazil-Cup,Sinop,Goias,0,1
Brazil-Cup,Sao Raimundo RR,Vila Nova,0,1
Brazil-Cup,Ferroviario,Confianca,2,1
Brazil-Cup,Brusque,Ceara,0,1
Brazil-Copa_do_Nordeste_Grp__D,Sampaio Correa,Salgueiro,4,0
Brazil-Baiano,Jacobina,Fluminense de Feira,0,2
Brazil-Baiano,Jequie,Atlantico EC,1,0
Brazil-Brasiliense,Samambaia,Bosque Formosa EC,0,1
Brazil-Carioca_Taca_Guanabara_Playoff,Boavista,Bangu,2,2
Brazil-Cearense_1st_Group_Stage,Guarani de Juazeiro,Uniclinic Atletico Clube,1,2
Brazil-Gaucho,Gremio,Brasil de Pelotas,2,1
International-Copa_Libertadores_Qualification,Santa Fe,Deportivo Tachira,0,0
International-Copa_Libertadores_Qualification,Atletico Junior,Olimpia,3,1
International-Copa_Libertadores_Qualification,Jorge Wilstermann,Oriente Petrolero,2,2
France-Ligue_1,Saint-Etienne,Marseille,2,2
Germany-1__Bundesliga,RasenBallsport Leipzig,Augsburg,2,0
Italy-Serie_A,Fiorentina,Juventus,0,2
Portugal-Primeira_Liga,Pacos de Ferreira,Tondela,0,2
Spain-Primera_Division,Athletic Bilbao,Las Palmas,0,0
Argentina-Superliga,Defensa y Justicia,Chacarita Juniors,4,2
Argentina-Superliga,Union,Arsenal Sarandi,0,0
Australia-A_League,Melbourne Victory,Brisbane Roar FC,1,2
Belgium-First_Division_A,Genk,Zulte-Waregem,3,1
Croatia-1__Division,Inter Zapresic,Slaven,0,0
Denmark-Superligaen,AC Horsens,FC Midtjylland,0,2
England-Championship,Millwall,Cardiff City,1,1
Germany-2__Bundesliga,Bochum,Darmstadt,2,1
Germany-2__Bundesliga,Kaiserslautern,Holstein Kiel,3,1
Netherlands-Eerste_Divisie,De Graafschap,FC Volendam,2,1
Netherlands-Eerste_Divisie,Cambuur,MVV Maastricht,0,2
Netherlands-Eerste_Divisie,FC Den Bosch,FC Eindhoven,4,0
Netherlands-Eerste_Divisie,FC Dordrecht,Helmond Sport,3,2
Netherlands-Eerste_Divisie,Jong FC Utrecht,RKC Waalwijk,5,2
Netherlands-Eerste_Divisie,FC Oss,Almere City FC,5,1
Netherlands-Eerste_Divisie,Telstar,Jong Ajax,3,3
Poland-Ekstraklasa,Wisla Plock,Gornik Zabrze,4,2
Poland-Ekstraklasa,Zaglebie Lubin,Legia Warszawa,2,3
Romania-Liga_I,Astra Giurgiu,Gaz Metan Medias,4,3
Romania-Liga_I,ACS Poli Timisoara,FC Voluntari,2,3
Spain-Segunda_Division,Granada,Valladolid,1,0
Sweden-Cup_Grp__5,Oestersunds FK,Trelleborgs FF,3,0
Turkey-Super_Lig,Yeni Malatyaspor,Kasimpasa,1,1
Belgium-First_Division_B_2nd_Stage,KFCO Beerschot-Wilrijk,Westerlo,0,0
International-Club_Friendlies,FK Haugesund,Odds Ballklubb,0,0
International-Club_Friendlies,FC Ufa,Cukaricki,0,1
International-Club_Friendlies,FC Ufa,FK Liepaja,0,0
International-Club_Friendlies,IFK Gothenburg,1860 Muenchen,
International-Club_Friendlies,Vaalerenga,Stabaek,4,2
International-Club_Friendlies,Lillestroem,Molde,2,1
International-Club_Friendlies,Lokomotiv Moscow,Stroemsgodset,2,2
International-Club_Friendlies,Tromsoe,Tromsdalen,4,0
England-Premier_League,Manchester City,Leicester City,5,1
England-Premier_League,Tottenham Hotspur,Arsenal,1,0
England-Premier_League,Everton,Crystal Palace,3,1
England-Premier_League,West Ham United,Watford,2,0
England-Premier_League,Swansea City,Burnley,1,0
England-Premier_League,Stoke City,Brighton &amp; Hove Albion,1,1
France-Ligue_1,Bordeaux,Amiens,3,2
France-Ligue_1,Guingamp,Caen,0,0
France-Ligue_1,Dijon,Nice,3,2
France-Ligue_1,Angers,Monaco,0,4
France-Ligue_1,Metz,Montpellier,0,1
France-Ligue_1,Toulouse,Paris Saint Germain,0,1
Germany-1__Bundesliga,Bayern Munich,Schalke 04,2,1
Germany-1__Bundesliga,Borussia Dortmund,Hamburger SV,2,0
Germany-1__Bundesliga,Bayer Leverkusen,Hertha Berlin,0,2
Germany-1__Bundesliga,Hoffenheim,Mainz 05,4,2
Germany-1__Bundesliga,Eintracht Frankfurt,FC Cologne,4,2
Germany-1__Bundesliga,Hannover 96,Freiburg,2,1
Italy-Serie_A,SSC Napoli,Lazio,4,1
Italy-Serie_A,Crotone,Atalanta,1,1
Italy-Serie_A,SPAL 2013,AC Milan,0,4
Netherlands-Eredivisie,AZ Alkmaar,VVV-Venlo,0,0
Netherlands-Eredivisie,SC Heerenveen,Roda JC Kerkrade,1,1
Netherlands-Eredivisie,FC Utrecht,PEC Zwolle,2,1
Netherlands-Eredivisie,Heracles,Willem II,1,0
Netherlands-Eredivisie,Sparta Rotterdam,PSV Eindhoven,1,2
Portugal-Primeira_Liga,Braga,Vitoria de Setubal,3,1
Portugal-Primeira_Liga,Rio Ave,Maritimo,3,0
Portugal-Primeira_Liga,Portimonense,Benfica,1,3
Spain-Primera_Division,Real Madrid,Real Sociedad,5,2
Spain-Primera_Division,Villarreal,Alaves,1,2
Spain-Primera_Division,Leganes,Eibar,0,1
Spain-Primera_Division,Malaga,Atletico Madrid,0,1
Argentina-Superliga,Velez Sarsfield,Patronato de Parana,0,2
Argentina-Superliga,Newells Old Boys,Colon,0,1
Argentina-Superliga,Gimnasia LP,Estudiantes,0,0
Argentina-Superliga,Olimpo,Racing Club,1,2
Australia-A_League,Melbourne City FC,Sydney FC,0,4
Austria-Bundesliga,Sturm Graz,Wolfsberger AC,0,1
Austria-Bundesliga,Austria Wien,LASK,1,3
England-Premier_League,Huddersfield Town,AFC Bournemouth,4,1
England-Premier_League,Southampton,Liverpool,0,2
England-Premier_League,Newcastle United,Manchester United,1,0
France-Ligue_1,Lyon,Rennes,0,2
France-Ligue_1,Strasbourg,Troyes,2,1
France-Ligue_1,Nantes,Lille,2,2
Germany-1__Bundesliga,Werder Bremen,Wolfsburg,3,1
Germany-1__Bundesliga,VfB Stuttgart,Borussia Moenchengladbach,1,0
Italy-Serie_A,Roma,Benevento,5,2
Italy-Serie_A,Sampdoria,Hellas Verona,2,0
Italy-Serie_A,Inter,Bologna,2,1
Italy-Serie_A,Torino,Udinese,2,0
Italy-Serie_A,Sassuolo,Cagliari,0,0
Italy-Serie_A,ChievoVerona,Genoa,0,1
Netherlands-Eredivisie,Ajax,FC Twente,2,1
Netherlands-Eredivisie,FC Groningen,ADO Den Haag,0,0
Netherlands-Eredivisie,Excelsior,NAC Breda,0,0
Netherlands-Eredivisie,Vitesse,Feyenoord,3,1
Portugal-Primeira_Liga,Sporting CP,Feirense,2,0
Portugal-Primeira_Liga,Belenenses,Aves,2,5
Portugal-Primeira_Liga,Boavista,Vitoria de Guimaraes,1,0
Portugal-Primeira_Liga,Chaves,FC Porto,0,4
Spain-Primera_Division,Barcelona,Getafe,0,0
Spain-Primera_Division,Valencia,Levante,3,1
Spain-Primera_Division,Sevilla,Girona,1,0
Spain-Primera_Division,Celta Vigo,Espanyol,2,2
Argentina-Superliga,Boca Juniors,Temperley,1,0
Argentina-Superliga,Talleres,Banfield,1,0
Argentina-Superliga,Godoy Cruz,Belgrano,2,1
Australia-A_League,Western Sydney Wanderers FC,Wellington Phoenix,4,0
Austria-Bundesliga,Admira Moedling,Rapid Wien,2,1
Belgium-First_Division_A,Standard Liege,Royal Excel Mouscron,4,3
Belgium-First_Division_A,Sporting Charleroi,Lokeren,1,1
Belgium-First_Division_A,Waasland-Beveren,Club Brugge,1,1
Croatia-1__Division,NK Lokomotiva,Rudes,2,2
Croatia-1__Division,Cibalia,Hajduk Split,0,5
Denmark-Superligaen,OB,FC Helsingoer,6,1
Denmark-Superligaen,SoenderjyskE,FC Nordsjaelland,2,1
Denmark-Superligaen,Lyngby,Broendby IF,1,3
England-Championship,Aston Villa,Birmingham City,2,0
England-Premier_League,Chelsea,West Bromwich Albion,3,0
Portugal-Primeira_Liga,Moreirense,Estoril,1,2
Spain-Primera_Division,Deportivo La Coruna,Real Betis,0,1
International-AFC_Champions_League_Grp__A,Al-Jazira,Al-Garrafa,3,2
International-AFC_Champions_League_Grp__A,Tractor Sazi Tabriz,Al Ahli,0,1
International-AFC_Champions_League_Grp__B,Al-Duhail SC,Zob Ahan,3,1
International-AFC_Champions_League_Grp__B,Lokomotiv Tashkent,Al-Wahda,5,0
Argentina-Superliga,Atletico Tucuman,San Martin San Juan,2,1
Argentina-Superliga,Tigre,Argentinos Juniors,2,0
Argentina-Superliga,Lanus,River Plate,1,0
Denmark-Superligaen,Hobro,AGF,0,1
Germany-2__Bundesliga,St. Pauli,Nuernberg,0,0
Greece-Super_League,PAOK Thessaloniki FC,AE Larissa,3,0
Israel-Ligat_HaAl,Hapoel Beer Sheva,FC Ashdod,2,0
Italy-Serie_B,Palermo,Foggia,1,2
Mexico-Liga_MX_Clausura,Veracruz,Pachuca,0,1
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Fortuna Sittard,2,0
Netherlands-Eerste_Divisie,Go Ahead Eagles,FC Emmen,0,1
International-OFC_Champions_League_Grp__B,Erakor Golden Star,Solomon Warriors FC,2,0
International-OFC_Champions_League_Grp__B,Dragon,AS Lossi,4,0
Poland-Ekstraklasa,Piast Gliwice,Jagiellonia Bialystok,0,2
Romania-Liga_I,CSMS Iasi,Botosani,1,0
Romania-Liga_I,Concordia Chiajna,Dinamo Bucuresti,3,4
Turkey-Super_Lig,Galatasaray,Antalyaspor,3,0
International-AFC_Cup_Grp__A,Al Quwa Al Jawiya,Al-Jazeera,2,2
International-AFC_Cup_Grp__A,Malkia,Al-Suwaiq,4,1
International-AFC_Cup_Grp__B,Manama,Al-Jaish,0,0
International-AFC_Cup_Grp__B,Al-Ahed,Al Zawraa,1,1
International-Club_Friendlies,Budapest Honved,SKA-Khabarovsk,1,2
International-Club_Friendlies,FK Liepaja,Brommapojkarna,1,2
International-Club_Friendlies,Rosenborg,Stjoerdals Blink,3,1
Egypt-Premier_League,Al Ahly,Al Mokawloon Al Arab,5,2
Egypt-Premier_League,Tanta,El Geish,0,1
France-Ligue_2,Auxerre,Nimes,0,0
Gibraltar-Premier_Division,Gibraltar United FC,Manchester 62 FC,2,1
Italy-Serie_C_Grp__A,Robur Siena,Carrarese,0,0
Turkey-1__Lig,Adanaspor,Gazisehir Gaziantep FK,2,5
Argentina-Primera_B_Nacional,Deportivo Riestra,San Martin de Tucuman,3,0
Argentina-Federal_A___Promotion___Zona_A,Ferro Carril Oeste General Pico,Juventud Unida Universitario,1,1
Argentina-Federal_A___Promotion___Zona_A,CA Alvarado,Villa Mitre,1,0
International-Champions_League_Final_Stage,Juventus,Tottenham Hotspur,2,2
International-Champions_League_Final_Stage,Basel,Manchester City,0,4
International-Europa_League_Final_Stage,FK Crvena Zvezda,CSKA Moscow,0,0
International-AFC_Champions_League_Grp__C,Persepolis,Nasaf Qarshi,3,0
International-AFC_Champions_League_Grp__C,Al-Wasl,Al-Sadd,1,2
International-AFC_Champions_League_Grp__D,Al Hilal,Al-Ain,0,0
International-AFC_Champions_League_Grp__D,Al-Rayyan,Esteghlal,2,2
International-AFC_Champions_League_Grp__E,Tianjin Quanjian,Kitchee,3,0
International-AFC_Champions_League_Grp__E,Jeonbuk FC,Kashiwa Reysol,3,2
International-AFC_Champions_League_Grp__F,Kawasaki Frontale,Shanghai SIPG FC,0,1
International-AFC_Champions_League_Grp__F,Melbourne Victory,Ulsan Hyundai,3,3
Argentina-Superliga,Huracan,Rosario Central,2,3
England-Championship,Cardiff City,Bolton Wanderers,2,0
England-Championship,Sheffield Wednesday,Derby County,2,0
N__Ireland-Premiership,Carrick Rangers,Glentoran,1,2
N__Ireland-Premiership,Warrenpoint Town,Cliftonville,1,3
N__Ireland-Premiership,Ards,Glenavon,1,6
International-OFC_Champions_League_Grp__A,Tupapa Maraerenga,Nalkutan FC,0,4
International-OFC_Champions_League_Grp__A,Lae City Dwellers,Ba,1,0
Scotland-Premiership,Kilmarnock,Dundee FC,3,2
International-AFC_Cup_Grp__C,Dhofar,Al-Ansar,0,2
International-AFC_Cup_Grp__C,Al-Faisaly,Al-Wahda,2,2
International-AFC_Cup_Grp__F,Shan United,Home United FC,0,1
International-AFC_Cup_Grp__F,Ceres-Negros FC,Boeung Ket,9,0
International-AFC_Cup_Grp__G,Bali United Pusam,Yangon United,1,3
International-Club_Friendlies,Elfsborg,Skoevde AIK,2,0
International-Club_Friendlies,Arsenal Tula,Torpedo Zhodino,2,3
International-Club_Friendlies,IFK Norrkoeping,Joenkoepings Soedra,1,0
International-Club_Friendlies,Arsenal Tula,Torpedo Zhodino,1,0
International-Club_Friendlies,Brann,Puskas FC Academy,1,0
International-Copa_Sudamericana,Luqueno,Deportivo Cuenca,2,0
International-Copa_Sudamericana,CD UT Cajamarca,Rampla Juniors,2,0
England-League_1,Wigan Athletic,Blackpool,0,2
England-League_1,Rotherham United,Oxford United,3,1
England-League_1,Charlton Athletic,Bradford City,1,1
England-League_1,Oldham Athletic,Milton Keynes Dons,1,0
England-League_1,Northampton Town,Gillingham,1,2
England-League_1,Bury,Southend United,0,0
England-League_1,Peterborough United,Scunthorpe United,2,2
England-League_1,Bristol Rovers,Rochdale,3,2
International-Champions_League_Final_Stage,Real Madrid,Paris Saint Germain,3,1
International-Champions_League_Final_Stage,FC Porto,Liverpool,0,5
International-Copa_Libertadores_Qualification,Banfield,Nacional,2,2
International-Copa_Libertadores_Qualification,Santiago Wanderers,Santa Fe,1,2
International-AFC_Champions_League_Grp__G,Guangzhou Evergrande,Buriram United,1,1
International-AFC_Champions_League_Grp__G,Jeju United,Cerezo Osaka,0,1
International-AFC_Champions_League_Grp__H,Kashima Antlers,Shanghai Shenhua,1,1
International-AFC_Champions_League_Grp__H,Sydney FC,Suwon Bluewings,0,2
Mexico-Liga_MX_Clausura,CF America,Monarcas Morelia,4,1
Mexico-Liga_MX_Clausura,Atlas,Necaxa,1,1
Mexico-Liga_MX_Clausura,Lobos de la BUAP,Tigres,0,0
International-AFC_Cup_Grp__H,Johor Darul Ta'zim FC,Persija Jakarta,3,0
International-Club_Friendlies,Dinamo Moscow,Zeta,1,0
International-Club_Friendlies,Rosenborg,Melhus,4,0
International-Club_Friendlies,Molde,Kristiansund BK,1,0
International-Club_Friendlies,Ural,Spartak Moscow II,3,0
International-Copa_Sudamericana,Zamora FC,Colon,0,2
Egypt-Premier_League,El Zamalek,Wadi Degla FC,1,0
Egypt-Premier_League,Al-Ittihad Al-Sakandary,El Dakhleya,2,1
Gibraltar-Premier_Division,Lynx,Mons Calpe SC,0,5
Italy-Serie_C_Grp__B,Sudtirol,Pordenone Calcio,1,0
Spain-Segunda_B_Grp__I,AD Union Adarve,Valladolid B,1,1
Spain-Segunda_B_Grp__II,Osasuna B,Barakaldo,0,1
Spain-Segunda_B_Grp__III,Ontinyent,SD Formentera,3,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Gutierrez SC,San Lorenzo de Alem,4,1
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Deportivo Maipu,Huracan Las Heras,2,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_C,CD Libertad,Atletico Parana,2,1
Argentina-Primera_C,Defensores de Cambaceres,Central Cordoba de Rosario,3,2
Brazil-Catarinense,Concordia Atletico,Hercilio Luz,2,2
Brazil-Catarinense,Criciuma,Joinville,2,1
Brazil-Gaucho,Sao Luiz,Sao Paulo RG,2,0
Brazil-Gaucho,EC Sao Jose,Avenida,0,0
Brazil-Goiano,Itumbiara,Esporte Clube Rio Verde,2,0
Brazil-Goiano,Aparecidense,Atletico GO,0,0
Brazil-Paulista_A1,Santos FC,Sao Caetano,2,0
Brazil-Paulista_A1,Botafogo SP,Ponte Preta,1,1
Brazil-Paulista_A1,Bragantino,Mirassol,0,0
Brazil-Paulista_A1,Ferroviaria,Santo Andre,2,1
Brazil-Potiguar_1st_Group_Stage,Forca e Luz,ABC,1,4
Brazil-Sergipano_1st_Group_Stage,Amadense EC,AO Itabaiana,0,3
International-Copa_Libertadores_Qualification,Vasco da Gama,Jorge Wilstermann,4,0
International-Copa_Libertadores_Qualification,Atletico Junior,Guarani,1,0
International-Europa_League_Final_Stage,Marseille,Braga,3,0
International-Europa_League_Final_Stage,Borussia Dortmund,Atalanta,3,2
International-Europa_League_Final_Stage,Real Sociedad,Salzburg,2,2
International-Europa_League_Final_Stage,Nice,Lokomotiv Moscow,2,3
International-Europa_League_Final_Stage,Lyon,Villarreal,3,1
International-Europa_League_Final_Stage,SSC Napoli,RasenBallsport Leipzig,1,3
International-Europa_League_Final_Stage,AEK Athens,Dynamo Kyiv,1,1
International-Europa_League_Final_Stage,Spartak Moscow,Athletic Bilbao,1,3
International-Europa_League_Final_Stage,Celtic,Zenit St. Petersburg,1,0
International-Europa_League_Final_Stage,Partizan Beograd,Viktoria Plzen,1,1
International-Europa_League_Final_Stage,Ludogorets Razgrad,AC Milan,0,3
International-Europa_League_Final_Stage,FC Astana,Sporting CP,1,3
International-Europa_League_Final_Stage,FC FCSB,Lazio,1,0
International-Europa_League_Final_Stage,Oestersunds FK,Arsenal,0,3
International-Europa_League_Final_Stage,FC Koebenhavn,Atletico Madrid,1,4
Mexico-Liga_MX_Clausura,Pachuca,Tijuana,2,0
Mexico-Liga_MX_Clausura,Santos,Leon,5,1
Mexico-Liga_MX_Clausura,Pumas,Veracruz,1,2
Mexico-Liga_MX_Clausura,Monterrey,Cruz Azul,2,2
Mexico-Liga_MX_Clausura,Puebla,Toluca,2,0
Mexico-Liga_MX_Clausura,Queretaro FC,CD Guadalajara,2,2
International-OFC_Champions_League_Grp__B,Erakor Golden Star,Dragon,3,4
International-OFC_Champions_League_Grp__B,Solomon Warriors FC,AS Lossi,6,1
International-Club_Friendlies,Amkar,FC Astana,
International-Club_Friendlies,Amkar,Alashkert FC,2,0
International-Club_Friendlies,Sarpsborg 08,Rubin Kazan,1,0
International-Club_Friendlies,Tromsoe,Sandefjord,
International-Club_Friendlies,Vaalerenga,Tromsoe,0,3
International-Club_Friendlies,Stroemsgodset,Sandefjord,6,0
International-Copa_Sudamericana,Nacional,Mineros De Guayana,0,0
Egypt-Premier_League,Al Masry,El Raja Marsa Matruh,0,0
Egypt-Premier_League,Al Nasr,Petrojet,0,1
Gibraltar-Premier_Division,Europa FC,Lincoln Red Imps FC,1,1
International-Recopa_Sudamericana,Independiente,Gremio,1,1
Algeria-Ligue_1,NA Hussein Dey,USM Blida,4,1
Algeria-Ligue_1,ES Setif,CR Belouizdad,2,1
Algeria-Ligue_1,US Biskra,Olympique de Medea,2,0
Argentina-Primera_B_Nacional,Boca Unidos,Guillermo Brown,2,0
England-FA_Cup,Chelsea,Hull City,4,0
England-FA_Cup,Leicester City,Sheffield United,1,0
France-Ligue_1,Monaco,Dijon,4,0
Germany-1__Bundesliga,Hertha Berlin,Mainz 05,0,2
Netherlands-Eredivisie,VVV-Venlo,FC Groningen,1,1
Portugal-Primeira_Liga,Feirense,Portimonense,1,3
Spain-Primera_Division,Girona,Leganes,3,0
Argentina-Superliga,Racing Club,Lanus,3,1
Argentina-Superliga,Estudiantes,Union,2,0
Australia-A_League,Western Sydney Wanderers FC,Newcastle Jets,2,2
Belgium-First_Division_A,St.Truiden,Anderlecht,1,0
Croatia-1__Division,Rudes,Inter Zapresic,2,0
Denmark-Superligaen,FC Nordsjaelland,OB,2,1
Germany-2__Bundesliga,FC Heidenheim,Bochum,1,0
Germany-2__Bundesliga,Kaiserslautern,Sandhausen,0,1
Ireland-Premier_Division,Dundalk,Bray Wanderers,0,0
Ireland-Premier_Division,Waterford FC,Derry City,2,1
Ireland-Premier_Division,Bohemian FC,Shamrock Rovers,3,1
Ireland-Premier_Division,St. Patrick's Athletic,Cork City,2,3
Italy-Serie_B,Cremonese,Bari,0,1
Netherlands-Eerste_Divisie,Helmond Sport,Jong FC Utrecht,2,0
Netherlands-Eerste_Divisie,FC Eindhoven,Jong AZ Alkmaar,1,3
Netherlands-Eerste_Divisie,FC Volendam,FC Dordrecht,4,1
Netherlands-Eerste_Divisie,Almere City FC,Go Ahead Eagles,2,0
Netherlands-Eerste_Divisie,Fortuna Sittard,Telstar,1,1
Netherlands-Eerste_Divisie,FC Emmen,De Graafschap,5,2
Netherlands-Eerste_Divisie,RKC Waalwijk,Cambuur,0,0
Netherlands-Eerste_Divisie,MVV Maastricht,NEC Nijmegen,4,1
N__Ireland-Premiership,Ballinamallard United,Coleraine,2,5
N__Ireland-Premiership,Glentoran,Ards,1,2
International-OFC_Champions_League_Grp__A,Ba,Tupapa Maraerenga,4,1
International-OFC_Champions_League_Grp__A,Lae City Dwellers,Nalkutan FC,1,4
Poland-Ekstraklasa,Legia Warszawa,Slask Wroclaw,4,1
Poland-Ekstraklasa,Sandecja Nowy Sacz,Korona Kielce,3,3
Romania-Liga_I,Gaz Metan Medias,Juventus Bucuresti,0,0
Romania-Liga_I,FC Voluntari,CS Universitatea Craiova,0,1
Spain-Segunda_Division,Valladolid,Huesca,3,2
Turkey-Super_Lig,Konyaspor,Besiktas,1,1
Ukraine-Premier_League,Shakhtar Donetsk,Chernomorets Odessa,5,0
Belgium-First_Division_B_2nd_Stage,Lierse,Roeselare,1,2
England-FA_Cup,Brighton &amp; Hove Albion,Coventry City,3,1
England-FA_Cup,West Bromwich Albion,Southampton,1,2
England-FA_Cup,Sheffield Wednesday,Swansea City,0,0
England-FA_Cup,Huddersfield Town,Manchester United,0,2
France-Ligue_1,Paris Saint Germain,Strasbourg,5,2
France-Ligue_1,Montpellier,Guingamp,1,1
France-Ligue_1,Troyes,Metz,1,0
France-Ligue_1,Caen,Rennes,2,2
France-Ligue_1,Angers,Saint-Etienne,0,1
France-Ligue_1,Amiens,Toulouse,0,0
Germany-1__Bundesliga,FC Cologne,Hannover 96,1,1
Germany-1__Bundesliga,Schalke 04,Hoffenheim,2,1
Germany-1__Bundesliga,Freiburg,Werder Bremen,1,0
Germany-1__Bundesliga,Hamburger SV,Bayer Leverkusen,1,2
Germany-1__Bundesliga,Wolfsburg,Bayern Munich,1,2
Italy-Serie_A,ChievoVerona,Cagliari,2,1
Italy-Serie_A,Genoa,Inter,2,0
Italy-Serie_A,Udinese,Roma,0,2
Netherlands-Eredivisie,PSV Eindhoven,SC Heerenveen,2,2
Netherlands-Eredivisie,Vitesse,Excelsior,1,2
Netherlands-Eredivisie,ADO Den Haag,Willem II,2,1
Netherlands-Eredivisie,NAC Breda,AZ Alkmaar,1,3
Portugal-Primeira_Liga,Benfica,Boavista,4,0
Portugal-Primeira_Liga,Aves,Maritimo,0,0
Portugal-Primeira_Liga,Estoril,Belenenses,0,2
Spain-Primera_Division,Alaves,Deportivo La Coruna,1,0
Spain-Primera_Division,Las Palmas,Sevilla,1,2
Spain-Primera_Division,Malaga,Valencia,1,2
Spain-Primera_Division,Eibar,Barcelona,0,2
Argentina-Superliga,San Lorenzo,Newells Old Boys,1,0
Argentina-Superliga,Argentinos Juniors,Atletico Tucuman,2,2
Argentina-Superliga,Belgrano,Velez Sarsfield,2,2
Argentina-Superliga,Temperley,Independiente,0,0
Australia-A_League,Adelaide United,Central Coast Mariners,2,2
Australia-A_League,Wellington Phoenix,Perth Glory,2,1
Austria-Bundesliga,LASK,Altach,2,0
Austria-Bundesliga,Wolfsberger AC,Admira Moedling,1,3
Austria-Bundesliga,Rapid Wien,Sturm Graz,1,1
Austria-Bundesliga,Mattersburg,Austria Wien,2,1
Belgium-First_Division_A,Zulte-Waregem,Eupen,3,2
England-FA_Cup,Rochdale,Tottenham Hotspur,2,2
France-Ligue_1,Marseille,Bordeaux,1,0
France-Ligue_1,Nice,Nantes,1,1
France-Ligue_1,Lille,Lyon,2,2
Germany-1__Bundesliga,Augsburg,VfB Stuttgart,0,1
Germany-1__Bundesliga,Borussia Moenchengladbach,Borussia Dortmund,0,1
Italy-Serie_A,SSC Napoli,SPAL 2013,1,0
Italy-Serie_A,AC Milan,Sampdoria,1,0
Italy-Serie_A,Atalanta,Fiorentina,1,1
Italy-Serie_A,Benevento,Crotone,3,2
Italy-Serie_A,Bologna,Sassuolo,2,1
Italy-Serie_A,Torino,Juventus,0,1
Netherlands-Eredivisie,Feyenoord,Heracles,1,0
Netherlands-Eredivisie,FC Twente,Sparta Rotterdam,1,1
Netherlands-Eredivisie,Roda JC Kerkrade,FC Utrecht,1,4
Netherlands-Eredivisie,PEC Zwolle,Ajax,0,1
Portugal-Primeira_Liga,FC Porto,Rio Ave,5,0
Portugal-Primeira_Liga,Vitoria de Setubal,Pacos de Ferreira,1,0
Portugal-Primeira_Liga,Moreirense,Chaves,0,1
Portugal-Primeira_Liga,Vitoria de Guimaraes,Braga,0,5
Spain-Primera_Division,Atletico Madrid,Athletic Bilbao,2,0
Spain-Primera_Division,Real Sociedad,Levante,3,0
Spain-Primera_Division,Espanyol,Villarreal,1,1
Spain-Primera_Division,Real Betis,Real Madrid,3,5
Argentina-Superliga,Rosario Central,Olimpo,5,0
Argentina-Superliga,River Plate,Godoy Cruz,2,2
Argentina-Superliga,Arsenal Sarandi,Huracan,1,1
Argentina-Superliga,San Martin San Juan,Talleres,1,1
Austria-Bundesliga,Salzburg,SKN St. Poelten,4,0
Belgium-First_Division_A,Gent,KV Mechelen,2,2
Belgium-First_Division_A,Royal Excel Mouscron,Waasland-Beveren,2,2
Belgium-First_Division_A,Sporting Charleroi,Standard Liege,1,1
Bulgaria-First_Professional_League,Ludogorets Razgrad,Slavia Sofia,4,1
Bulgaria-First_Professional_League,Levski Sofia,Botev Plovdiv,1,0
Bulgaria-First_Professional_League,Lokomotiv Plovdiv,Pirin Blagoevgrad,1,0
Croatia-1__Division,Slaven,Cibalia,2,0
Croatia-1__Division,Dinamo Zagreb,Hajduk Split,0,1
Czech_Republic-1__Division,Sparta Prague,Slovan Liberec,2,0
Czech_Republic-1__Division,Sigma Olomouc,Viktoria Plzen,0,0
Denmark-Superligaen,FC Midtjylland,FC Koebenhavn,3,1
England-FA_Cup,Wigan Athletic,Manchester City,1,0
Germany-1__Bundesliga,Eintracht Frankfurt,RasenBallsport Leipzig,2,1
Italy-Serie_A,Lazio,Hellas Verona,2,0
Portugal-Primeira_Liga,Tondela,Sporting CP,1,2
Spain-Primera_Division,Getafe,Celta Vigo,3,0
International-AFC_Champions_League_Grp__A,Al Ahli,Al-Jazira,2,1
International-AFC_Champions_League_Grp__A,Al-Garrafa,Tractor Sazi Tabriz,3,0
International-AFC_Champions_League_Grp__B,Zob Ahan,Lokomotiv Tashkent,2,0
International-AFC_Champions_League_Grp__B,Al-Wahda,Al-Duhail SC,2,3
Argentina-Superliga,Patronato de Parana,Chacarita Juniors,3,0
Argentina-Superliga,Tigre,Defensa y Justicia,1,1
Argentina-Superliga,Banfield,Boca Juniors,0,1
Bulgaria-First_Professional_League,Vitosha Bistritsa,Dunav Ruse,1,2
Denmark-Superligaen,AGF,SoenderjyskE,0,0
Greece-Super_League,AE Larissa,Panathinaikos,0,1
Israel-Ligat_HaAl,Beitar Jerusalem,Bnei Yehuda Tel Aviv,2,0
Mexico-Liga_MX_Clausura,Veracruz,CF America,1,1
Netherlands-Eerste_Divisie,Jong Ajax,FC Oss,2,0
Netherlands-Eerste_Divisie,Jong PSV,FC Den Bosch,2,1
Poland-Ekstraklasa,Gornik Zabrze,Termalica Nieciecza,3,0
Romania-Liga_I,FC Viitorul Constanta,Botosani,2,1
Sweden-Cup_Grp__3,Djurgaarden,Degerfors,6,0
Sweden-Cup_Grp__8,Elfsborg,GAIS,2,3
Turkey-Super_Lig,Genclerbirligi,Goztepe,3,0
International-Club_Friendlies,Amkar,Dinamo St Petersburg,1,1
International-Club_Friendlies,Anzhi Makhachkala,FK Akhmat,1,1
International-Club_Friendlies,Anzhi Makhachkala,Kolkheti-1913 Poti,4,1
Egypt-Premier_League,Al Ahly,Al Nasr,5,0
Egypt-Premier_League,Petrojet,El Zamalek,1,3
England-League_1,Blackburn Rovers,Bury,2,0
France-Ligue_2,Quevilly,Lens,1,2
Italy-Serie_C_Grp__C,Cosenza,Reggina,1,1
Kosovo-Superliga,KF Flamurtari,Gjilani,0,1
Spain-Segunda_B_Grp__IV,Cordoba B,Cartagena,0,1
Albania-Kategoria_Superiore,Partizani,Kukesi,1,3
Albania-Kategoria_Superiore,Vllaznia,Teuta Durres,2,0
Argentina-Primera_B_Nacional,Nueva Chicago,Santamarina,1,1
Argentina-Federal_A___Promotion___Zona_A,Villa Mitre,Ferro Carril Oeste General Pico,1,1
Argentina-Federal_A___Promotion___Zona_A,Juventud Unida Universitario,Deportivo Roca,2,0
Argentina-Federal_A___Promotion___Zona_A,Estudiantes de Rio Cuarto,CA Alvarado,1,0
International-Champions_League_Final_Stage,Bayern Munich,Besiktas,5,0
International-Champions_League_Final_Stage,Chelsea,Barcelona,1,1
France-Ligue_1,Troyes,Dijon,0,0
International-AFC_Champions_League_Grp__C,Nasaf Qarshi,Al-Wasl,1,0
International-AFC_Champions_League_Grp__C,Al-Sadd,Persepolis,3,1
International-AFC_Champions_League_Grp__D,Al-Ain,Al-Rayyan,1,1
International-AFC_Champions_League_Grp__D,Esteghlal,Al Hilal,1,0
International-AFC_Champions_League_Grp__E,Kashiwa Reysol,Tianjin Quanjian,1,1
International-AFC_Champions_League_Grp__E,Kitchee,Jeonbuk FC,0,6
International-AFC_Champions_League_Grp__F,Shanghai SIPG FC,Melbourne Victory,4,1
International-AFC_Champions_League_Grp__F,Ulsan Hyundai,Kawasaki Frontale,2,1
Argentina-Superliga,Colon,Gimnasia LP,1,0
England-Championship,Brentford,Birmingham City,5,0
England-Championship,Middlesbrough,Hull City,3,1
England-Championship,Millwall,Sheffield Wednesday,2,1
England-Championship,Sheffield United,Queens Park Rangers,2,1
England-Championship,Barnsley,Burton Albion,1,2
England-Championship,Aston Villa,Preston North End,1,1
England-Championship,Nottingham Forest,Reading,1,1
England-Championship,Bolton Wanderers,Sunderland,1,0
Slovenia-Prva_Liga,Ankaran Hrvatini,Aluminij,1,1
International-Club_Friendlies,Shinnik Yaroslavl,Ural,0,2
International-Club_Friendlies,Arsenal Tula,Dinamo Vranje,1,0
International-Club_Friendlies,Arsenal Tula,Kairat Almaty,0,0
International-Club_Friendlies,Tosno,Avangard Kursk,1,0
International-Club_Friendlies,Kristiansund BK,FC Krasnodar,3,0
International-Copa_Sudamericana,Sport Rosario,Cerro,0,0
Egypt-Premier_League,El Dakhleya,Al Mokawloon Al Arab,1,2
Egypt-Premier_League,Tanta,El Raja Marsa Matruh,0,0
Egypt-Premier_League,El Entag El Harby,Alassiouty,1,0
Egypt-Premier_League,Wadi Degla FC,El Geish,1,0
England-League_1,Shrewsbury Town,Gillingham,1,1
England-League_1,Fleetwood Town,Portsmouth,1,2
England-League_2,Crewe Alexandra,Exeter City,1,2
England-League_2,Cambridge United,Notts County,1,0
England-League_2,Barnet,Carlisle United,1,3
Scotland-Championship,Dumbarton,Greenock Morton,0,1
Scotland-League_One,Stranraer,Arbroath,1,4
Turkey-1__Lig,Rizespor,Balikesirspor,3,0
Turkey-1__Lig,Samsunspor,Ankaragucu,1,1
International-Champions_League_Final_Stage,Shakhtar Donetsk,Roma,2,1
International-Champions_League_Final_Stage,Sevilla,Manchester United,0,0
International-Copa_Libertadores_Qualification,Santa Fe,Santiago Wanderers,3,0
Portugal-Primeira_Liga,Estoril,FC Porto,1,3
Spain-Primera_Division,Leganes,Real Madrid,1,3
International-Europa_League_Final_Stage,CSKA Moscow,FK Crvena Zvezda,1,0
International-AFC_Champions_League_Grp__G,Cerezo Osaka,Guangzhou Evergrande,0,0
International-AFC_Champions_League_Grp__G,Buriram United,Jeju United,0,2
International-AFC_Champions_League_Grp__H,Shanghai Shenhua,Sydney FC,2,2
International-AFC_Champions_League_Grp__H,Suwon Bluewings,Kashima Antlers,1,2
England-Championship,Wolverhampton Wanderers,Norwich City,2,2
England-Championship,Derby County,Leeds United,2,2
England-Championship,Bristol City,Fulham,1,1
England-Championship,Ipswich Town,Cardiff City,0,1
Germany-2__Bundesliga,Darmstadt,Kaiserslautern,1,2
Ukraine-Premier_League,Karpaty,Olimpik Donetsk,2,1
International-Club_Friendlies,Bodoe/Glimt,Sandefjord,2,1
International-Club_Friendlies,Sturm Graz,Kalsdorf,4,0
International-Club_Friendlies,Levante,FC Ufa,1,1
International-Club_Friendlies,Odds Ballklubb,Jerv,2,0
International-Club_Friendlies,Rubin Kazan,Lillestroem,1,1
International-Club_Friendlies,Aalesund,Start,0,0
International-CONCACAF_Champions_League,Club Sport Herediano,Tigres,2,2
International-CONCACAF_Champions_League,Colorado Rapids,Toronto FC,0,2
International-Copa_Sudamericana,Barcelona SC,General Diaz,0,0
International-Copa_Sudamericana,Lanus,Sporting Cristal,4,2
England-League_1,Rochdale,Milton Keynes Dons,0,0
Gibraltar-Premier_Division,Gibraltar Phoenix,St Joseph's,0,1
Turkey-1__Lig,Istanbulspor,Manisaspor,1,0
Turkey-1__Lig,Elazigspor,Giresunspor,2,1
Turkey-1__Lig,Eskisehirspor,Gazisehir Gaziantep FK,1,4
Turkey-1__Lig,Denizlispor,Umraniyespor,2,0
Bahrain-Premier_League,Muharraq,Al-Najma,0,0
Bahrain-Premier_League,Malkia,Manama,1,2
Bahrain-Premier_League,Al-Hidd,Al-Riffa,3,3
Brazil-Cup,Atletico PR,Atletico Tubarao,5,4
Brazil-Cup,Londrina EC,Ceara,1,2
Brazil-Cup,Remo,Internacional,1,2
Brazil-Copa_do_Nordeste_Grp__A,Santa Cruz,CRB,2,1
Brazil-Copa_do_Nordeste_Grp__B,Ferroviario,Globo FC,0,0
International-Copa_Libertadores_Qualification,Jorge Wilstermann,Vasco da Gama,6,3
International-Copa_Libertadores_Qualification,Nacional,Banfield,1,0
International-Europa_League_Final_Stage,Atletico Madrid,FC Koebenhavn,1,0
International-Europa_League_Final_Stage,Lazio,FC FCSB,5,1
International-Europa_League_Final_Stage,Arsenal,Oestersunds FK,1,2
International-Europa_League_Final_Stage,Sporting CP,FC Astana,3,3
International-Europa_League_Final_Stage,Zenit St. Petersburg,Celtic,3,0
International-Europa_League_Final_Stage,Viktoria Plzen,Partizan Beograd,2,0
International-Europa_League_Final_Stage,Villarreal,Lyon,0,1
International-Europa_League_Final_Stage,Athletic Bilbao,Spartak Moscow,1,2
International-Europa_League_Final_Stage,AC Milan,Ludogorets Razgrad,1,0
International-Europa_League_Final_Stage,Dynamo Kyiv,AEK Athens,0,0
International-Europa_League_Final_Stage,Atalanta,Borussia Dortmund,1,1
International-Europa_League_Final_Stage,Lokomotiv Moscow,Nice,1,0
International-Europa_League_Final_Stage,Salzburg,Real Sociedad,2,1
International-Europa_League_Final_Stage,RasenBallsport Leipzig,SSC Napoli,0,2
International-Europa_League_Final_Stage,Braga,Marseille,1,0
International-Club_Friendlies,Dinamo Moscow,Baltika,2,0
International-Club_Friendlies,Kristiansund BK,Bodoe/Glimt,
International-Club_Friendlies,Dinamo Moscow,FK Akhmat,3,2
International-Club_Friendlies,Molde,Vaalerenga,1,1
International-Club_Friendlies,Rosenborg,FC Krasnodar,3,2
International-CONCACAF_Champions_League,CD Motagua,Tijuana,0,1
International-CONCACAF_Champions_League,Tauro FC,FC Dallas,1,0
International-CONCACAF_Champions_League,Deportivo Saprissa,CF America,1,5
International-Copa_Sudamericana,El Nacional,San Jose,3,2
Egypt-Premier_League,Al-Ittihad Al-Sakandary,ENPPI,1,1
Egypt-Premier_League,Al Nasr,El Zamalek,1,2
Gibraltar-Premier_Division,Mons Calpe SC,Manchester 62 FC,4,2
International-Recopa_Sudamericana,Gremio,Independiente,5,4
Turkey-1__Lig,Boluspor,Erzurum BB,1,1
Turkey-1__Lig,Adanaspor,Adana Demirspor,1,0
Argentina-Primera_B_Metropolitana,CA Defensores de Belgrano,CA Talleres Remedios de Escalada,1,1
Argentina-Primera_B_Metropolitana,Comunicaciones,Deportivo Espanol,3,0
Argentina-Primera_C,Argentino de Quilmes,Club Lujan,1,1
Argentina-Primera_C,Sportivo Barracas,Deportivo Armenio,0,0
Argentina-Primera_C,Laferrere,Canuelas,2,2
Argentina-Primera_C,CA Ferrocarril Midland,Ituzaingo,0,2
Argentina-Primera_C,Dock Sud,El Porvenir,1,2
Argentina-Primera_C,Justo Jose de Urquiza,Deportivo Merlo,1,2
International-Copa_Libertadores_Qualification,Guarani,Atletico Junior,0,0
France-Ligue_1,Strasbourg,Montpellier,0,0
Germany-1__Bundesliga,Mainz 05,Wolfsburg,1,1
Netherlands-Eredivisie,FC Groningen,NAC Breda,1,1
Portugal-Primeira_Liga,Rio Ave,Aves,0,0
Spain-Primera_Division,Deportivo La Coruna,Espanyol,0,0
Argentina-Superliga,Huracan,Estudiantes,1,0
Argentina-Superliga,Olimpo,Arsenal Sarandi,2,1
Australia-A_League,Central Coast Mariners,Wellington Phoenix,1,0
Belgium-First_Division_A,Genk,Royal Antwerp,4,0
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Cherno More Varna,0,0
Czech_Republic-1__Division,Dukla Praha,Jablonec,0,1
Denmark-Superligaen,AC Horsens,Randers FC,1,1
England-Championship,Hull City,Sheffield United,1,0
Germany-2__Bundesliga,Arminia Bielefeld,Dynamo Dresden,2,3
Germany-2__Bundesliga,Jahn Regensburg,Fortuna Duesseldorf,4,3
Ireland-Premier_Division,Cork City,Waterford FC,2,0
Ireland-Premier_Division,Sligo Rovers,Derry City,2,1
Ireland-Premier_Division,Shamrock Rovers,Dundalk,0,0
Ireland-Premier_Division,Bray Wanderers,St. Patrick's Athletic,1,2
Italy-Serie_B,Spezia,Salernitana,3,0
Italy-Serie_B,Parma Calcio 1913,Venezia,1,1
Netherlands-Eerste_Divisie,NEC Nijmegen,Fortuna Sittard,1,1
Netherlands-Eerste_Divisie,De Graafschap,Helmond Sport,1,0
Netherlands-Eerste_Divisie,Go Ahead Eagles,FC Oss,2,1
Netherlands-Eerste_Divisie,FC Den Bosch,RKC Waalwijk,0,0
Netherlands-Eerste_Divisie,FC Eindhoven,FC Dordrecht,0,1
Netherlands-Eerste_Divisie,MVV Maastricht,Almere City FC,3,0
Netherlands-Eerste_Divisie,Telstar,FC Volendam,5,2
Netherlands-Eerste_Divisie,Cambuur,FC Emmen,1,1
Poland-Ekstraklasa,Jagiellonia Bialystok,Lechia Gdansk,4,1
Poland-Ekstraklasa,Zaglebie Lubin,Arka Gdynia,0,0
Romania-Liga_I,CS Universitatea Craiova,ACS Poli Timisoara,1,1
Spain-Segunda_Division,Sporting Gijon,Osasuna,2,0
Turkey-Super_Lig,Galatasaray,Bursaspor,5,0
Turkey-Super_Lig,Akhisar Belediye Genclik Ve Spor,Konyaspor,3,0
International-Club_Friendlies,Ranheim,Rosenborg,3,1
International-Club_Friendlies,Anzhi Makhachkala,FC Yenisey Krasnoyarsk,2,0
International-Club_Friendlies,Tosno,Akzhaiyk Uralsk,
International-Club_Friendlies,FC Krasnodar,Ranheim,
England-Premier_League,Liverpool,West Ham United,4,1
England-Premier_League,Leicester City,Stoke City,1,1
England-Premier_League,West Bromwich Albion,Huddersfield Town,1,2
England-Premier_League,AFC Bournemouth,Newcastle United,2,2
England-Premier_League,Brighton &amp; Hove Albion,Swansea City,4,1
England-Premier_League,Watford,Everton,1,0
England-Premier_League,Burnley,Southampton,1,1
France-Ligue_1,Nantes,Amiens,0,1
France-Ligue_1,Rennes,Troyes,2,0
France-Ligue_1,Guingamp,Metz,2,2
France-Ligue_1,Dijon,Caen,2,0
France-Ligue_1,Lille,Angers,1,2
France-Ligue_1,Toulouse,Monaco,3,3
Germany-1__Bundesliga,Bayern Munich,Hertha Berlin,0,0
Germany-1__Bundesliga,Hoffenheim,Freiburg,1,1
Germany-1__Bundesliga,Werder Bremen,Hamburger SV,1,0
Germany-1__Bundesliga,VfB Stuttgart,Eintracht Frankfurt,1,0
Germany-1__Bundesliga,Hannover 96,Borussia Moenchengladbach,0,1
Italy-Serie_A,Inter,Benevento,2,0
Italy-Serie_A,Bologna,Genoa,2,0
Netherlands-Eredivisie,AZ Alkmaar,Sparta Rotterdam,2,1
Netherlands-Eredivisie,SC Heerenveen,Excelsior,0,1
Netherlands-Eredivisie,Heracles,PEC Zwolle,2,1
Netherlands-Eredivisie,VVV-Venlo,Vitesse,2,2
Portugal-Primeira_Liga,Belenenses,Feirense,1,0
Portugal-Primeira_Liga,Maritimo,Vitoria de Guimaraes,3,2
Portugal-Primeira_Liga,Pacos de Ferreira,Benfica,1,3
Spain-Primera_Division,Barcelona,Girona,6,1
Spain-Primera_Division,Real Madrid,Alaves,4,0
Spain-Primera_Division,Leganes,Las Palmas,0,0
Spain-Primera_Division,Celta Vigo,Eibar,2,0
Argentina-Superliga,Defensa y Justicia,Patronato de Parana,1,0
Argentina-Superliga,Godoy Cruz,Racing Club,1,2
Argentina-Superliga,Velez Sarsfield,River Plate,1,0
Argentina-Superliga,Lanus,Rosario Central,1,1
Australia-A_League,Melbourne Victory,Adelaide United,3,0
Australia-A_League,Brisbane Roar FC,Newcastle Jets,0,1
Australia-A_League,Perth Glory,Melbourne City FC,2,1
Austria-Bundesliga,Wolfsberger AC,SKN St. Poelten,0,1
Austria-Bundesliga,Rapid Wien,LASK,2,0
England-Premier_League,Manchester United,Chelsea,2,1
England-Premier_League,Crystal Palace,Tottenham Hotspur,0,1
France-Ligue_1,Paris Saint Germain,Marseille,3,0
France-Ligue_1,Lyon,Saint-Etienne,1,1
France-Ligue_1,Bordeaux,Nice,0,0
Germany-1__Bundesliga,RasenBallsport Leipzig,FC Cologne,1,2
Germany-1__Bundesliga,Bayer Leverkusen,Schalke 04,0,2
Italy-Serie_A,Fiorentina,ChievoVerona,1,0
Italy-Serie_A,Sampdoria,Udinese,2,1
Italy-Serie_A,Roma,AC Milan,0,2
Italy-Serie_A,Crotone,SPAL 2013,2,3
Italy-Serie_A,Sassuolo,Lazio,0,3
Italy-Serie_A,Hellas Verona,Torino,2,1
Netherlands-Eredivisie,Ajax,ADO Den Haag,0,0
Netherlands-Eredivisie,FC Utrecht,FC Twente,3,1
Netherlands-Eredivisie,Willem II,Roda JC Kerkrade,1,0
Netherlands-Eredivisie,Feyenoord,PSV Eindhoven,1,3
Portugal-Primeira_Liga,Chaves,Estoril,2,0
Portugal-Primeira_Liga,Boavista,Vitoria de Setubal,4,0
Portugal-Primeira_Liga,Portimonense,FC Porto,1,5
Spain-Primera_Division,Athletic Bilbao,Malaga,2,1
Spain-Primera_Division,Valencia,Real Sociedad,2,1
Spain-Primera_Division,Villarreal,Getafe,1,0
Spain-Primera_Division,Sevilla,Atletico Madrid,2,5
Argentina-Superliga,Boca Juniors,San Martin San Juan,4,2
Argentina-Superliga,Independiente,Banfield,1,0
Argentina-Superliga,Union,Colon,1,1
Argentina-Superliga,Atletico Tucuman,Tigre,0,0
Argentina-Superliga,Chacarita Juniors,Belgrano,0,1
Australia-A_League,Sydney FC,Western Sydney Wanderers FC,3,1
Austria-Bundesliga,Sturm Graz,Salzburg,2,4
Belgium-First_Division_A,Anderlecht,Royal Excel Mouscron,5,3
Belgium-First_Division_A,Kortrijk,Zulte-Waregem,0,1
Belgium-First_Division_A,Standard Liege,Club Brugge,1,1
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Vitosha Bistritsa,1,0
Bulgaria-First_Professional_League,Slavia Sofia,Lokomotiv Plovdiv,1,1
Czech_Republic-1__Division,Slavia Prague,Bohemians 1905,1,0
Czech_Republic-1__Division,Karvina,Zlin,4,0
Denmark-Superligaen,Broendby IF,FC Helsingoer,6,1
Denmark-Superligaen,FC Koebenhavn,OB,1,0
Germany-1__Bundesliga,Borussia Dortmund,Augsburg,1,1
Italy-Serie_A,Cagliari,SSC Napoli,0,5
Portugal-Primeira_Liga,Sporting CP,Moreirense,1,0
Portugal-Primeira_Liga,Braga,Tondela,1,0
Spain-Primera_Division,Levante,Real Betis,0,2
Argentina-Superliga,Newells Old Boys,Temperley,0,0
Argentina-Superliga,Talleres,Argentinos Juniors,2,0
Czech_Republic-1__Division,Viktoria Plzen,Vysocina Jihlava,0,1
Denmark-Superligaen,SoenderjyskE,Silkeborg,0,1
International-Friendlies,Saudi Arabia,Moldova,3,0
Greece-Super_League,Atromitos,AEK Athens,1,1
Ireland-Premier_Division,Shamrock Rovers,Bray Wanderers,6,0
Ireland-Premier_Division,Waterford FC,St. Patrick's Athletic,2,0
Ireland-Premier_Division,Sligo Rovers,Cork City,1,4
Israel-Ligat_HaAl,Maccabi Petach Tikva,Hapoel Ironi Akko,2,1
Italy-Serie_B,Salernitana,Parma Calcio 1913,0,1
Mexico-Liga_MX_Clausura,Santos,Cruz Azul,2,0
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Jong PSV,2,1
Netherlands-Eerste_Divisie,Jong FC Utrecht,Jong Ajax,2,1
Slovakia-Super_Liga,Ruzomberok,Nitra,0,0
Spain-Segunda_Division,Tenerife,Lugo,3,1
Sweden-Cup_Grp__5,Aatvidaberg,Oestersunds FK,0,2
Turkey-Super_Lig,Istanbul Basaksehir,Genclerbirligi,1,1
International-AFC_Cup_Grp__A,Al-Jazeera,Malkia,1,0
International-AFC_Cup_Grp__A,Al-Suwaiq,Al Quwa Al Jawiya,0,1
International-AFC_Cup_Grp__B,Al Zawraa,Al-Jaish,0,0
International-AFC_Cup_Grp__B,Manama,Al-Ahed,0,1
International-Club_Friendlies,Sarpsborg 08,Skeid,0,1
France-Ligue_2,Nancy,Lorient,0,2
Italy-Serie_C_Grp__B,Ravenna,Pordenone Calcio,1,0
Spain-Segunda_B_Grp__IV,Las Palmas B,Granada B,2,1
Turkey-1__Lig,Erzurum BB,Adanaspor,2,1
Turkey-1__Lig,Altinordu,Boluspor,1,5
Turkey-1__Lig,Adana Demirspor,Istanbulspor,2,1
Argentina-Primera_B_Nacional,Club Atletico Mitre,All Boys,1,2
Argentina-Primera_B_Nacional,Deportivo Riestra,Instituto,2,3
Argentina-Federal_A___Promotion___Zona_A,Estudiantes de Rio Cuarto,Villa Mitre,1,0
Argentina-Federal_A___Promotion___Zona_B,Sportivo Belgrano,CA Chaco For Ever,3,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Deportivo Maipu,Union Aconquija,2,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Union Villa Krause,Gutierrez SC,1,2
International-Copa_Libertadores_Grp__1,Defensor Sporting,Gremio,1,1
International-Copa_Libertadores_Grp__1,Monagas SC,Cerro Porteno,0,2
England-FA_Cup,Swansea City,Sheffield Wednesday,2,0
Spain-Primera_Division,Girona,Celta Vigo,1,0
Spain-Primera_Division,Espanyol,Real Madrid,1,0
Argentina-Superliga,Gimnasia LP,San Lorenzo,1,0
Bulgaria-First_Professional_League,Botev Plovdiv,Ludogorets Razgrad,1,3
Denmark-Superligaen,AC Horsens,AGF,1,1
England-Championship,Hull City,Barnsley,1,1
England-Championship,Reading,Sheffield United,1,3
France-Coupe_de_France,Les Herbiers,Lens,4,2
Ireland-Premier_Division,Dundalk,Limerick,8,0
Ireland-Premier_Division,Bohemian FC,Derry City,0,1
Italy-Serie_B,Empoli,Avellino,1,1
Italy-Serie_B,Palermo,Ascoli Picchio FC 1898,4,1
Italy-Serie_B,Venezia,Ternana,2,0
Italy-Serie_B,Novara,Foggia,0,1
Italy-Serie_B,Cremonese,Frosinone,2,2
Italy-Serie_B,Entella,Cittadella,0,1
N__Ireland-Premiership,Glentoran,Warrenpoint Town,5,0
N__Ireland-Premiership,Linfield,Glenavon,0,2
N__Ireland-Premiership,Carrick Rangers,Dungannon Swifts,1,0
N__Ireland-Premiership,Ards,Ballymena United,1,0
International-OFC_Champions_League_Grp__D,Team Wellington,Lupe ole Soaga,7,1
International-OFC_Champions_League_Grp__D,Marist,AS Magenta,1,1
Poland-Ekstraklasa,Lechia Gdansk,Termalica Nieciecza,2,2
Poland-Ekstraklasa,Wisla Plock,Cracovia,0,1
Poland-Ekstraklasa,Legia Warszawa,Jagiellonia Bialystok,0,2
Poland-Ekstraklasa,Sandecja Nowy Sacz,Zaglebie Lubin,0,1
Romania-Liga_I,Concordia Chiajna,FC Voluntari,3,1
Russia-Cup,Amkar,Avangard Kursk,6,7
Russia-Cup,SKA-Khabarovsk,Shinnik Yaroslavl,1,4
Scotland-Premiership,Hearts,Kilmarnock,1,1
Scotland-Premiership,St.Johnstone,Rangers,1,4
Turkey-Cup,Akhisar Belediye Genclik Ve Spor,Galatasaray,1,2
International-AFC_Cup_Grp__C,Al-Wahda,Dhofar,0,0
International-AFC_Cup_Grp__C,Al-Ansar,Al-Faisaly,1,3
International-AFC_Cup_Grp__F,Boeung Ket,Shan United,1,2
International-AFC_Cup_Grp__F,Home United FC,Ceres-Negros FC,1,1
International-AFC_Cup_Grp__G,Global FC,Bali United Pusam,1,1
International-Copa_Libertadores_Grp__2,Colo Colo,Atletico Nacional,0,1
International-Copa_Libertadores_Grp__5,Racing Club,Cruzeiro,4,2
International-Copa_Libertadores_Grp__6,Nacional,Estudiantes,0,0
England-FA_Cup,Tottenham Hotspur,Rochdale,6,1
Spain-Primera_Division,Atletico Madrid,Leganes,4,0
Spain-Primera_Division,Getafe,Deportivo La Coruna,3,0
Spain-Primera_Division,Eibar,Villarreal,1,0
Spain-Primera_Division,Athletic Bilbao,Valencia,1,1
Spain-Primera_Division,Malaga,Sevilla,0,1
Denmark-Superligaen,OB,Lyngby,3,1
Denmark-Superligaen,Randers FC,FC Helsingoer,0,0
Denmark-Superligaen,Hobro,FC Koebenhavn,0,2
France-Coupe_de_France,Paris Saint Germain,Marseille,3,0
France-Coupe_de_France,Chambly,Strasbourg,1,0
International-Friendlies,Iraq,Saudi Arabia,4,1
Italy-Coppa_Italia,Juventus,Atalanta,1,0
Italy-Coppa_Italia,Lazio,AC Milan,4,5
Netherlands-KNVB_Cup,Feyenoord,Willem II,3,0
Netherlands-KNVB_Cup,AZ Alkmaar,FC Twente,4,0
International-OFC_Champions_League_Grp__C,Auckland City FC,Madang,5,0
International-OFC_Champions_League_Grp__C,Venus,Lautoka,1,2
Poland-Ekstraklasa,Lech Poznan,Slask Wroclaw,2,1
Poland-Ekstraklasa,Gornik Zabrze,Pogon Szczecin,0,0
Poland-Ekstraklasa,Arka Gdynia,Piast Gliwice,0,0
Poland-Ekstraklasa,Wisla Krakow,Korona Kielce,1,1
Russia-Cup,Tosno,Luch Energiya Vladivostok,2,1
International-AFC_Cup_Grp__H,Persija Jakarta,Tampines Rovers FC,4,1
International-AFC_Cup_Grp__H,Song Lam Nghe An,Johor Darul Ta'zim FC,2,0
International-Club_Friendlies,Dinamo Brest,Rosenborg,1,3
International-Club_Friendlies,Stabaek,Viking,2,1
International-CONCACAF_Champions_League,Toronto FC,Colorado Rapids,0,0
International-CONCACAF_Champions_League,Tigres,Club Sport Herediano,3,1
International-CONCACAF_Champions_League,Tijuana,CD Motagua,1,1
Egypt-Premier_League,Tanta,Al-Ittihad Al-Sakandary,0,1
Egypt-Premier_League,El Dakhleya,Al Ahly,0,3
Estonia-Meistriliiga,Flora Tallinn,Tammeka,
Gibraltar-Premier_Division,Gibraltar United FC,Mons Calpe SC,3,1
Greece-Cup_Final_Stage,Panionios,PAOK Thessaloniki FC,1,3
Israel-Cup,Beitar Jerusalem,Hapoel Kfar Saba,0,0
Israel-Cup,Hapoel Ironi Kiryat Shmona,Hapoel Beer Sheva,1,0
International-Copa_Libertadores_Grp__2,Delfin,Bolivar,1,1
International-Copa_Libertadores_Grp__4,Santa Fe,Emelec,1,1
International-Copa_Libertadores_Grp__4,Flamengo,River Plate,2,2
International-Copa_Libertadores_Grp__6,Real Garcilaso,Santos FC,2,0
International-Copa_Libertadores_Grp__7,Millonarios,Corinthians,0,0
International-Copa_Libertadores_Grp__7,Deportivo Lara,Independiente,1,0
England-Premier_League,Arsenal,Manchester City,0,3
Spain-Primera_Division,Alaves,Levante,1,0
Spain-Primera_Division,Real Betis,Real Sociedad,0,0
Spain-Primera_Division,Las Palmas,Barcelona,1,1
Denmark-Superligaen,FC Nordsjaelland,Silkeborg,3,1
Denmark-Superligaen,SoenderjyskE,AaB,0,1
Denmark-Superligaen,FC Midtjylland,Broendby IF,0,1
France-Coupe_de_France,Caen,Lyon,1,0
Turkey-Cup,Besiktas,Fenerbahce,2,2
International-Club_Friendlies,FK Haugesund,Vard Haugesund,1,2
International-CONCACAF_Champions_League,CD Guadalajara,Cibao,5,0
International-CONCACAF_Champions_League,CF America,Deportivo Saprissa,1,1
International-CONCACAF_Champions_League,FC Dallas,Tauro FC,3,2
Egypt-Premier_League,El Entag El Harby,Al Nasr,1,1
Egypt-Premier_League,Wadi Degla FC,El Raja Marsa Matruh,2,3
Egypt-Premier_League,ENPPI,Al Mokawloon Al Arab,3,2
Egypt-Premier_League,Smouha SC,Ismaily SC,1,2
Gibraltar-Premier_Division,Lynx,Glacis United,3,1
Greece-Cup_Final_Stage,AE Larissa,AEK Athens,2,1
Israel-Cup,Hapoel Haifa,Maccabi Haifa,1,1
Portugal-Segunda_Liga,Nacional,Oliveirense,2,1
Romania-Cup,Hermannstadt,FC FCSB,3,0
Albania-Kategoria_Superiore,Flamurtari,Luftetari,0,1
Algeria-Ligue_1,CR Belouizdad,Olympique de Medea,0,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Huracan Las Heras,Gutierrez SC,1,1
Argentina-Primera_B_Metropolitana,CA Defensores de Belgrano,Villa San Carlos,0,0
Armenia-Premier_League,Ararat,Gandzasar,1,0
Bahrain-Premier_League,Al-Hidd,Al-Najma,1,0
Brazil-Cup,Internacional,Cianorte,2,0
Brazil-Cup,Ferroviario,Vila Nova,1,1
Brazil-Cup,Fluminense,Avai FC,1,2
Brazil-Cup,Atletico PR,Ceara,0,0
Brazil-Cup,Figueirense,Atletico MG,0,1
Brazil-Brasiliense,Santa Maria,Sobradinho EC,1,2
International-Copa_Libertadores_Grp__8,Atletico Junior,Palmeiras,0,3
International-Copa_Libertadores_Grp__8,Alianza Lima,Boca Juniors,0,0
France-Ligue_1,Monaco,Bordeaux,2,1
France-Ligue_1,Nice,Lille,2,1
Germany-1__Bundesliga,Borussia Moenchengladbach,Werder Bremen,2,2
Netherlands-Eredivisie,Roda JC Kerkrade,Heracles,0,3
Portugal-Primeira_Liga,FC Porto,Sporting CP,2,1
Russia-Premier_League,Anzhi Makhachkala,Rubin Kazan,1,1
Argentina-Superliga,Belgrano,Patronato de Parana,2,2
Argentina-Superliga,Arsenal Sarandi,Lanus,2,1
Australia-A_League,Melbourne City FC,Melbourne Victory,1,2
Croatia-1__Division,NK Istra 1961,Cibalia,0,0
Czech_Republic-1__Division,Bohemians 1905,Dukla Praha,2,0
England-Championship,Middlesbrough,Leeds United,3,0
Germany-2__Bundesliga,Dynamo Dresden,Darmstadt,0,2
Germany-2__Bundesliga,Kaiserslautern,Union Berlin,4,3
Netherlands-Eerste_Divisie,FC Volendam,FC Eindhoven,3,2
Netherlands-Eerste_Divisie,Helmond Sport,Jong AZ Alkmaar,3,0
Netherlands-Eerste_Divisie,FC Dordrecht,Telstar,2,3
Netherlands-Eerste_Divisie,Almere City FC,Jong Ajax,1,2
Netherlands-Eerste_Divisie,FC Oss,Cambuur,2,1
Netherlands-Eerste_Divisie,RKC Waalwijk,NEC Nijmegen,0,2
International-OFC_Champions_League_Grp__D,Lupe ole Soaga,Marist,1,3
International-OFC_Champions_League_Grp__D,Team Wellington,AS Magenta,5,1
Poland-Ekstraklasa,Zaglebie Lubin,Lechia Gdansk,0,0
Poland-Ekstraklasa,Termalica Nieciecza,Wisla Plock,1,2
Spain-Segunda_Division,Real Oviedo,Barcelona B,0,0
Turkey-Super_Lig,Bursaspor,Kayserispor,1,0
International-CONCACAF_Champions_League,Seattle Sounders FC,Santa Tecla FC,4,0
International-CONCACAF_Champions_League,New York Red Bulls,CD Olimpia,2,0
Egypt-Premier_League,Al Masry,Alassiouty,3,1
Egypt-Premier_League,Petrojet,Misr El-Maqasa,0,0
Finland-Cup_Grp__B,SJK,VPS,1,0
Finland-Cup_Grp__E,EIF,IFK Mariehamn,1,0
France-Ligue_2,Nimes,SC Bastia,
France-Ligue_2,Brest,Tours,1,3
France-Ligue_2,Quevilly,Niort,1,2
France-Ligue_2,Clermont Foot,Reims,2,1
France-Ligue_2,Valenciennes,Orleans,0,1
France-Ligue_2,Chateauroux,Nancy,1,0
England-Premier_League,Tottenham Hotspur,Huddersfield Town,2,0
England-Premier_League,Liverpool,Newcastle United,2,0
England-Premier_League,Southampton,Stoke City,0,0
England-Premier_League,Leicester City,AFC Bournemouth,1,1
England-Premier_League,Watford,West Bromwich Albion,1,0
England-Premier_League,Burnley,Everton,2,1
England-Premier_League,Swansea City,West Ham United,4,1
France-Ligue_1,Saint-Etienne,Dijon,2,2
France-Ligue_1,Angers,Guingamp,3,0
France-Ligue_1,Metz,Toulouse,1,1
France-Ligue_1,Amiens,Rennes,0,2
France-Ligue_1,Troyes,Paris Saint Germain,0,2
Germany-1__Bundesliga,Schalke 04,Hertha Berlin,1,0
Germany-1__Bundesliga,Eintracht Frankfurt,Hannover 96,1,0
Germany-1__Bundesliga,Hamburger SV,Mainz 05,0,0
Germany-1__Bundesliga,RasenBallsport Leipzig,Borussia Dortmund,1,1
Germany-1__Bundesliga,Augsburg,Hoffenheim,0,2
Germany-1__Bundesliga,Wolfsburg,Bayer Leverkusen,1,2
Italy-Serie_A,SSC Napoli,Roma,2,4
Italy-Serie_A,SPAL 2013,Bologna,1,0
Italy-Serie_A,Lazio,Juventus,0,1
Netherlands-Eredivisie,PSV Eindhoven,FC Utrecht,3,0
Netherlands-Eredivisie,SC Heerenveen,Willem II,2,0
Netherlands-Eredivisie,NAC Breda,Feyenoord,2,1
Netherlands-Eredivisie,Excelsior,AZ Alkmaar,1,2
Portugal-Primeira_Liga,Benfica,Maritimo,5,0
Portugal-Primeira_Liga,Feirense,Boavista,3,0
Portugal-Primeira_Liga,Estoril,Braga,0,6
Russia-Premier_League,CSKA Moscow,Ural,1,0
Russia-Premier_League,Zenit St. Petersburg,Amkar,0,0
Russia-Premier_League,FC Krasnodar,FC Rostov,3,1
Spain-Primera_Division,Real Madrid,Getafe,3,1
Spain-Primera_Division,Sevilla,Athletic Bilbao,2,0
Spain-Primera_Division,Villarreal,Girona,0,2
Spain-Primera_Division,Leganes,Malaga,2,0
Spain-Primera_Division,Deportivo La Coruna,Eibar,1,1
Argentina-Superliga,Rosario Central,Godoy Cruz,1,2
Argentina-Superliga,Colon,Huracan,0,0
Argentina-Superliga,San Lorenzo,Union,0,0
Argentina-Superliga,Tigre,Talleres,0,0
England-Premier_League,Manchester City,Chelsea,1,0
England-Premier_League,Brighton &amp; Hove Albion,Arsenal,2,1
France-Ligue_1,Marseille,Nantes,1,1
France-Ligue_1,Caen,Strasbourg,2,0
France-Ligue_1,Montpellier,Lyon,1,1
Germany-1__Bundesliga,FC Cologne,VfB Stuttgart,2,3
Germany-1__Bundesliga,Freiburg,Bayern Munich,0,4
Italy-Serie_A,AC Milan,Inter,1X
Netherlands-Eredivisie,FC Twente,FC Groningen,1,1
Netherlands-Eredivisie,PEC Zwolle,VVV-Venlo,1,1
Netherlands-Eredivisie,Sparta Rotterdam,ADO Den Haag,2,1
Netherlands-Eredivisie,Vitesse,Ajax,3,2
Portugal-Primeira_Liga,Vitoria de Guimaraes,Belenenses,0,0
Portugal-Primeira_Liga,Moreirense,Pacos de Ferreira,2,0
Portugal-Primeira_Liga,Vitoria de Setubal,Rio Ave,1,0
Portugal-Primeira_Liga,Tondela,Chaves,2,0
Russia-Premier_League,FC Ufa,Dinamo Moscow,1,1
Russia-Premier_League,Arsenal Tula,FK Akhmat,1,0
Russia-Premier_League,Lokomotiv Moscow,Spartak Moscow,0,0
Russia-Premier_League,SKA-Khabarovsk,Tosno,0,1
Spain-Primera_Division,Valencia,Real Betis,2,0
Spain-Primera_Division,Real Sociedad,Alaves,2,1
Spain-Primera_Division,Barcelona,Atletico Madrid,1,0
Spain-Primera_Division,Levante,Espanyol,1,1
Argentina-Superliga,Temperley,Gimnasia LP,1,1
Argentina-Superliga,River Plate,Chacarita Juniors,1,1
Argentina-Superliga,Banfield,Newells Old Boys,1,0
Argentina-Superliga,Atletico Tucuman,Defensa y Justicia,0,1
Australia-A_League,Western Sydney Wanderers FC,Perth Glory,1,1
Austria-Bundesliga,Salzburg,Rapid Wien,1,0
Bulgaria-First_Professional_League,Lokomotiv Plovdiv,Botev Plovdiv,0,0
Bulgaria-First_Professional_League,Vitosha Bistritsa,Slavia Sofia,1,1
Croatia-1__Division,Dinamo Zagreb,Slaven,1,0
Croatia-1__Division,Rijeka,NK Lokomotiva,3,1
Czech_Republic-1__Division,Sparta Prague,FC Zbrojovka Brno,1,1
Denmark-Superligaen,Broendby IF,OB,2,1
Denmark-Superligaen,Randers FC,FC Nordsjaelland,0,3
Denmark-Superligaen,AGF,FC Koebenhavn,0,1
Denmark-Superligaen,FC Helsingoer,SoenderjyskE,1,2
Germany-2__Bundesliga,Eintracht Braunschweig,Jahn Regensburg,2,1
England-Premier_League,Crystal Palace,Manchester United,2,3
Portugal-Primeira_Liga,Aves,Portimonense,3,0
Spain-Primera_Division,Celta Vigo,Las Palmas,2,1
International-AFC_Champions_League_Grp__A,Al-Jazira,Tractor Sazi Tabriz,0,0
International-AFC_Champions_League_Grp__A,Al-Garrafa,Al Ahli,1,1
International-AFC_Champions_League_Grp__C,Persepolis,Al-Wasl,2,0
International-AFC_Champions_League_Grp__C,Nasaf Qarshi,Al-Sadd,1,0
Argentina-Superliga,Estudiantes,Olimpo,1,0
Argentina-Superliga,Racing Club,Velez Sarsfield,2,1
Argentina-Superliga,San Martin San Juan,Independiente,0,4
Bulgaria-First_Professional_League,Vereya,Pirin Blagoevgrad,0,0
Bulgaria-First_Professional_League,Dunav Ruse,PFC CSKA-Sofia,0,2
Denmark-Superligaen,AaB,AC Horsens,1,1
Denmark-Superligaen,Silkeborg,FC Midtjylland,1,2
Germany-2__Bundesliga,Ingolstadt,Bochum,0,1
Greece-Super_League,Apollon Smirnis,Panetolikos,2,1
Israel-Ligat_HaAl,Maccabi Haifa,Hapoel Haifa,0,3
Mexico-Liga_MX_Clausura,Veracruz,Tigres,0,2
Netherlands-Eerste_Divisie,Fortuna Sittard,MVV Maastricht,3,0
Netherlands-Eerste_Divisie,Jong FC Utrecht,FC Den Bosch,1,1
Netherlands-Eerste_Divisie,Jong PSV,FC Emmen,1,1
Poland-Ekstraklasa,Jagiellonia Bialystok,Wisla Krakow,2,0
Turkey-Super_Lig,Trabzonspor,Besiktas,0,2
USA-Major_League_Soccer,Vancouver Whitecaps,Montreal Impact,2,1
USA-Major_League_Soccer,LA Galaxy,Portland Timbers,2,1
USA-Major_League_Soccer,Sporting Kansas City,New York City FC,0,2
International-AFC_Cup_Grp__A,Al-Suwaiq,Al-Jazeera,2,3
International-AFC_Cup_Grp__A,Malkia,Al Quwa Al Jawiya,3,4
International-AFC_Cup_Grp__C,Al-Faisaly,Dhofar,2,0
International-AFC_Cup_Grp__C,Al-Wahda,Al-Ansar,2,1
International-Club_Friendlies,Lillestroem,Rosenborg,0,0
Egypt-Premier_League,Al Mokawloon Al Arab,Tanta,1,1
Egypt-Premier_League,El Entag El Harby,El Dakhleya,1,1
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Smouha SC,2,0
France-Ligue_2,Lorient,Le Havre,1,0
Gibraltar-Premier_Division,Glacis United,Lynx,1X
Kosovo-Superliga,KF Vllaznia Pozheran,Besa Peje,1,0
Russia-National_Football_League,Spartak Moscow II,Fakel,0,0
Albania-Kategoria_Superiore,Luftetari,KF Kamza,1,0
Albania-Kategoria_Superiore,Vllaznia,Flamurtari,3,0
International-Champions_League_Final_Stage,Liverpool,FC Porto,0,0
International-Champions_League_Final_Stage,Paris Saint Germain,Real Madrid,1,2
International-AFC_Champions_League_Grp__B,Al-Duhail SC,Lokomotiv Tashkent,3,2
International-AFC_Champions_League_Grp__B,Zob Ahan,Al-Wahda,2,0
International-AFC_Champions_League_Grp__D,Al Hilal,Al-Rayyan,1,1
International-AFC_Champions_League_Grp__D,Al-Ain,Esteghlal,2,2
International-AFC_Champions_League_Grp__E,Kashiwa Reysol,Kitchee,1,0
International-AFC_Champions_League_Grp__E,Jeonbuk FC,Tianjin Quanjian,6,3
International-AFC_Champions_League_Grp__G,Guangzhou Evergrande,Jeju United,5,3
International-AFC_Champions_League_Grp__G,Buriram United,Cerezo Osaka,2,0
Argentina-Superliga,Argentinos Juniors,Boca Juniors,2,0
Bulgaria-First_Professional_League,Beroe,Ludogorets Razgrad,0,1
England-Championship,Cardiff City,Barnsley,2,1
England-Championship,Reading,Bolton Wanderers,1,1
England-Championship,Fulham,Sheffield United,3,0
England-Championship,Norwich City,Nottingham Forest,0,0
England-Championship,Hull City,Millwall,1,2
England-Championship,Sheffield Wednesday,Ipswich Town,1,2
England-Championship,Preston North End,Bristol City,2,1
England-Championship,Queens Park Rangers,Derby County,1,1
England-Championship,Sunderland,Aston Villa,0,3
England-Championship,Birmingham City,Middlesbrough,0,1
England-Championship,Burton Albion,Brentford,0,2
Italy-Serie_B,Perugia,Brescia,2,0
Italy-Serie_B,Cesena,Pro Vercelli,2,2
N__Ireland-Premiership,Dungannon Swifts,Ballymena United,2,3
N__Ireland-Premiership,Glenavon,Crusaders,1,6
Slovenia-Prva_Liga,Maribor,Rudar Velenje,2,2
Slovenia-Prva_Liga,Ankaran Hrvatini,Domzale,0,4
Ukraine-Premier_League,Zirka,FC Olexandria,0,0
International-AFC_Cup_Grp__B,Al-Ahed,Al-Jaish,1,1
International-AFC_Cup_Grp__F,Ceres-Negros FC,Shan United,2,0
International-AFC_Cup_Grp__F,Boeung Ket,Home United FC,3,2
International-AFC_Cup_Grp__H,Song Lam Nghe An,Persija Jakarta,0,0
International-AFC_Cup_Grp__H,Tampines Rovers FC,Johor Darul Ta'zim FC,0,0
International-Copa_Sudamericana,San Jose,El Nacional,1,1
Egypt-Premier_League,Ismaily SC,Wadi Degla FC,2,1
Egypt-Premier_League,Alassiouty,ENPPI,1,1
England-League_1,Walsall,Rochdale,0,3
England-League_2,Accrington Stanley,Morecambe,1,0
International-Champions_League_Final_Stage,Manchester City,Basel,1,2
International-Champions_League_Final_Stage,Tottenham Hotspur,Juventus,1,2
International-AFC_Champions_League_Grp__F,Shanghai SIPG FC,Ulsan Hyundai,2,2
International-AFC_Champions_League_Grp__F,Kawasaki Frontale,Melbourne Victory,2,2
International-AFC_Champions_League_Grp__H,Suwon Bluewings,Shanghai Shenhua,1,1
International-AFC_Champions_League_Grp__H,Sydney FC,Kashima Antlers,0,2
Bulgaria-First_Professional_League,Botev Plovdiv,Vitosha Bistritsa,3,0
Bulgaria-First_Professional_League,Septemvri Sofia,Lokomotiv Plovdiv,3,1
Bulgaria-First_Professional_League,Cherno More Varna,Levski Sofia,2,3
Croatia-1__Division,Rijeka,Dinamo Zagreb,4,1
England-Championship,Leeds United,Wolverhampton Wanderers,0,3
Scotland-Premiership,Kilmarnock,St.Johnstone,2,0
Slovenia-Prva_Liga,Olimpija Ljubljana,Aluminij,5,1
Slovenia-Prva_Liga,NK Celje,Gorica,2,0
International-AFC_Cup_Grp__D,FC Istiklol,Ahal,1,0
International-AFC_Cup_Grp__D,FC Alay Osh,Altyn Asyr,3,6
International-AFC_Cup_Grp__E,Abahani Limited,New Radiant SC,0,1
International-AFC_Cup_Grp__G,Yangon United,Global FC,3,0
International-AFC_Cup_Grp__G,Bali United Pusam,FLC Thanh Hoa,3,1
International-AFC_Cup_Grp__I,Benfica Macau,HangYuen/Fujen,3,2
International-AFC_Cup_Grp__I,April 25 SC,Hwaebul SC,1,0
International-Club_Friendlies,Barcelona,Espanyol,4,2
International-CONCACAF_Champions_League,CF America,Tauro FC,4,0
International-CONCACAF_Champions_League,Tijuana,New York Red Bulls,0,2
International-Copa_Sudamericana,General Diaz,Barcelona SC,2,1
International-Copa_Sudamericana,Colon,Zamora FC,1,0
International-Copa_Sudamericana,Cerro,Sport Rosario,2,0
International-Copa_Sudamericana,Caracas,Everton CD,0,1
Czech_Republic-Cup,Jablonec,Slovacko,3,1
Czech_Republic-Cup,Slavia Prague,Slovan Liberec,2,0
Egypt-Premier_League,Al Nasr,El Geish,1,0
Egypt-Premier_League,El Raja Marsa Matruh,Petrojet,1,1
International-EURO_U17_Qualification_Elite_Round_Grp__5,Netherlands U17,Iceland U17,2,1
International-EURO_U17_Qualification_Elite_Round_Grp__5,Italy U17,Turkey U17,2,0
Gibraltar-Premier_Division,Lincoln Red Imps FC,Gibraltar United FC,4,0
Portugal-Segunda_Liga,Nacional,FC Porto B,6,0
Serbia-Super_Liga,Partizan Beograd,Rad Beograd,3,1
Serbia-Super_Liga,Backa Backa Palanka,FK Radnik Surdulica,4,2
Serbia-Super_Liga,FK Spartak Subotica,FK Zemun,1,2
Serbia-Super_Liga,Vozdovac,Mladost Lucani,0,0
International-Europa_League_Final_Stage,Atletico Madrid,Lokomotiv Moscow,3,0
International-Europa_League_Final_Stage,Lazio,Dynamo Kyiv,2,2
International-Europa_League_Final_Stage,Sporting CP,Viktoria Plzen,2,0
International-Europa_League_Final_Stage,RasenBallsport Leipzig,Zenit St. Petersburg,2,1
International-Europa_League_Final_Stage,Borussia Dortmund,Salzburg,1,2
International-Europa_League_Final_Stage,Marseille,Athletic Bilbao,3,1
International-Europa_League_Final_Stage,AC Milan,Arsenal,0,2
International-Europa_League_Final_Stage,CSKA Moscow,Lyon,0,1
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Etar,2,1
Bulgaria-First_Professional_League,Slavia Sofia,Vereya,0,1
Bulgaria-First_Professional_League,Pirin Blagoevgrad,Dunav Ruse,1,0
International-CONCACAF_Champions_League,Seattle Sounders FC,CD Guadalajara,1,0
International-CONCACAF_Champions_League,Toronto FC,Tigres,2,1
International-Copa_Sudamericana,Rampla Juniors,CD UT Cajamarca,4,0
International-Copa_Sudamericana,Deportivo Cuenca,Luqueno,8,5
International-Copa_Sudamericana,Sporting Cristal,Lanus,2,1
International-Copa_Sudamericana,Mineros De Guayana,Nacional,3,4
Gibraltar-Premier_Division,Mons Calpe SC,Lions Gibraltar,3,1
Russia-National_Football_League,Kuban Krasnodar,FC Tambov,0,0
Turkey-1__Lig,Altinordu,Istanbulspor,3,1
Argentina-Federal_A___Promotion___Zona_A,Gimnasia Mendoza,Estudiantes de Rio Cuarto,2,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_A,Club Rivadavia,Sansinena BB,0,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Deportivo Maipu,San Lorenzo de Alem,2,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_B,Union Villa Krause,Huracan Las Heras,1,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_C,Douglas Haig,Sportivo Las Parejas,1,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_C,Defensores de Pronunciamiento,Atletico Parana,0,0
Argentina-Federal_A___Relegation___1st_Stage_Zona_D,Juventud Antoniana,Sportivo Patria,1,2
Argentina-Federal_A___Relegation___1st_Stage_Zona_D,Altos Hornos Zapla,Guarani Antonio Franco,2,3
Armenia-Cup,FC Banants,Alashkert FC,0,1
Bolivia-Primera_Division___Apertura,Jorge Wilstermann,Real Potosi,4,0
Bolivia-Primera_Division___Apertura,Royal Pari,Sport Boys Warnes,1,2
Brazil-Alagoano,ASA,CRB,1,2
Brazil-Alagoano,Dimensao Saude,Clube Sociedade Esportiva,4,1
Brazil-Alagoano,Santa Rita,Murici,1,3
Brazil-Alagoano,CS Alagoano,Coruripe,1,0
Brazil-Baiano,EC Jacuipense,Bahia de Feira,0,1
Brazil-Baiano,Jacobina,Vitoria da Conquista,2,0
Brazil-Baiano,Bahia,Jequie,6,1
Brazil-Baiano,Fluminense de Feira,Vitoria,1,2
Brazil-Baiano,Atlantico EC,Juazeirense,1,3
France-Ligue_1,Strasbourg,Monaco,1,3
Germany-1__Bundesliga,Mainz 05,Schalke 04,0,1
Italy-Serie_A,Roma,Torino,3,0
Netherlands-Eredivisie,Heracles,FC Twente,2,1
Portugal-Primeira_Liga,Braga,Moreirense,3,0
Russia-Premier_League,Amkar,Arsenal Tula,0,2
Spain-Primera_Division,Girona,Deportivo La Coruna,2,0
Argentina-Superliga,Godoy Cruz,Arsenal Sarandi,1,0
Argentina-Superliga,Gimnasia LP,Banfield,0,2
Croatia-1__Division,Slaven,Rudes,2,0
Czech_Republic-1__Division,Dukla Praha,Vysocina Jihlava,1,3
Denmark-Superligaen,OB,AGF,0,1
Germany-2__Bundesliga,Dynamo Dresden,FC Heidenheim,3,2
Germany-2__Bundesliga,Arminia Bielefeld,Nuernberg,1,0
Ireland-Premier_Division,Shamrock Rovers,Derry City,6,1
Ireland-Premier_Division,Dundalk,Cork City,1,0
Ireland-Premier_Division,Limerick,Bray Wanderers,1,0
Ireland-Premier_Division,Bohemian FC,St. Patrick's Athletic,0,1
Ireland-Premier_Division,Sligo Rovers,Waterford FC,1,2
Netherlands-Eerste_Divisie,Telstar,Helmond Sport,2,3
Netherlands-Eerste_Divisie,Jong Ajax,Go Ahead Eagles,0,2
Netherlands-Eerste_Divisie,De Graafschap,FC Dordrecht,0,1
Netherlands-Eerste_Divisie,FC Emmen,Jong AZ Alkmaar,0,2
Netherlands-Eerste_Divisie,NEC Nijmegen,FC Volendam,3,0
Netherlands-Eerste_Divisie,MVV Maastricht,Jong FC Utrecht,3,1
Netherlands-Eerste_Divisie,Cambuur,Almere City FC,2,1
Netherlands-Eerste_Divisie,FC Den Bosch,FC Oss,0,0
Netherlands-Eerste_Divisie,RKC Waalwijk,Jong PSV,3,2
Netherlands-Eerste_Divisie,FC Eindhoven,Fortuna Sittard,1,3
Poland-Ekstraklasa,Wisla Krakow,Slask Wroclaw,3,1
Poland-Ekstraklasa,Gornik Zabrze,Zaglebie Lubin,2,2
Romania-Liga_I_Championship_Group,CFR Cluj,CSMS Iasi,2,1
Romania-Liga_I_Relegation_Group,Botosani,Juventus Bucuresti,0,0
Scotland-Premiership,Hibernian,Hearts,2,0
Spain-Segunda_Division,Tenerife,Real Oviedo,3,1
Turkey-Super_Lig,Alanyaspor,Istanbul Basaksehir,4,1
Ukraine-Premier_League_Championship_Group,Vorskla,Shakhtar Donetsk,0,3
International-Copa_Sudamericana,Sport Huancayo,Union Espanola,3,0
International-Copa_Sudamericana,America de Cali,Defensa y Justicia,0,3
Estonia-Meistriliiga,Flora Tallinn,Paide Linnameeskond,6,0
England-Premier_League,Chelsea,Crystal Palace,2,1
England-Premier_League,West Ham United,Burnley,0,3
England-Premier_League,Everton,Brighton &amp; Hove Albion,2,0
England-Premier_League,Huddersfield Town,Swansea City,0,0
England-Premier_League,Newcastle United,Southampton,3,0
England-Premier_League,Manchester United,Liverpool,2,1
England-Premier_League,West Bromwich Albion,Leicester City,1,4
France-Ligue_1,Paris Saint Germain,Metz,5,0
France-Ligue_1,Nantes,Troyes,1,0
France-Ligue_1,Bordeaux,Angers,0,0
France-Ligue_1,Dijon,Amiens,1,1
France-Ligue_1,Rennes,Saint-Etienne,1,1
France-Ligue_1,Lille,Montpellier,1,1
Germany-1__Bundesliga,Bayern Munich,Hamburger SV,6,0
Germany-1__Bundesliga,Bayer Leverkusen,Borussia Moenchengladbach,2,0
Germany-1__Bundesliga,Hoffenheim,Wolfsburg,3,0
Germany-1__Bundesliga,Hannover 96,Augsburg,1,3
Germany-1__Bundesliga,Hertha Berlin,Freiburg,0,0
Italy-Serie_A,Hellas Verona,ChievoVerona,1,0
Netherlands-Eredivisie,ADO Den Haag,NAC Breda,0,2
Netherlands-Eredivisie,VVV-Venlo,Excelsior,2,3
Netherlands-Eredivisie,Roda JC Kerkrade,Sparta Rotterdam,0,2
Netherlands-Eredivisie,Willem II,PSV Eindhoven,5,0
Portugal-Primeira_Liga,Benfica,Aves,2,0
Portugal-Primeira_Liga,Rio Ave,Feirense,2,1
Portugal-Primeira_Liga,Boavista,Estoril,1,0
Russia-Premier_League,FC Ufa,Anzhi Makhachkala,3,2
Russia-Premier_League,Dinamo Moscow,FC Krasnodar,0,0
Russia-Premier_League,Tosno,Rubin Kazan,0,1
Spain-Primera_Division,Getafe,Levante,0,1
Spain-Primera_Division,Sevilla,Valencia,0,2
Spain-Primera_Division,Eibar,Real Madrid,1,2
Spain-Primera_Division,Malaga,Barcelona,0,2
Argentina-Superliga,Boca Juniors,Tigre,2,1
Argentina-Superliga,Talleres,Atletico Tucuman,3,1
Argentina-Superliga,Olimpo,Colon,0,3
Argentina-Superliga,Chacarita Juniors,Racing Club,1,1
Australia-A_League,Western Sydney Wanderers FC,Wellington Phoenix,4,1
Australia-A_League,Perth Glory,Central Coast Mariners,3,1
Austria-Bundesliga,Austria Wien,SKN St. Poelten,4,0
England-Premier_League,Chelsea,Crystal Palace,2,1
England-Premier_League,West Ham United,Burnley,0,3
England-Premier_League,Everton,Brighton &amp; Hove Albion,2,0
England-Premier_League,Huddersfield Town,Swansea City,0,0
England-Premier_League,Newcastle United,Southampton,3,0
England-Premier_League,Manchester United,Liverpool,2,1
England-Premier_League,West Bromwich Albion,Leicester City,1,4
France-Ligue_1,Paris Saint Germain,Metz,5,0
France-Ligue_1,Nantes,Troyes,1,0
France-Ligue_1,Bordeaux,Angers,0,0
France-Ligue_1,Dijon,Amiens,1,1
France-Ligue_1,Rennes,Saint-Etienne,1,1
France-Ligue_1,Lille,Montpellier,1,1
Germany-1__Bundesliga,Bayern Munich,Hamburger SV,6,0
Germany-1__Bundesliga,Bayer Leverkusen,Borussia Moenchengladbach,2,0
Germany-1__Bundesliga,Hoffenheim,Wolfsburg,3,0
Germany-1__Bundesliga,Hannover 96,Augsburg,1,3
Germany-1__Bundesliga,Hertha Berlin,Freiburg,0,0
Italy-Serie_A,Hellas Verona,ChievoVerona,1,0
Netherlands-Eredivisie,ADO Den Haag,NAC Breda,0,2
Netherlands-Eredivisie,VVV-Venlo,Excelsior,2,3
Netherlands-Eredivisie,Roda JC Kerkrade,Sparta Rotterdam,0,2
Netherlands-Eredivisie,Willem II,PSV Eindhoven,5,0
Portugal-Primeira_Liga,Benfica,Aves,2,0
Portugal-Primeira_Liga,Rio Ave,Feirense,2,1
Portugal-Primeira_Liga,Boavista,Estoril,1,0
Russia-Premier_League,FC Ufa,Anzhi Makhachkala,3,2
Russia-Premier_League,Dinamo Moscow,FC Krasnodar,0,0
Russia-Premier_League,Tosno,Rubin Kazan,0,1
Spain-Primera_Division,Getafe,Levante,0,1
Spain-Primera_Division,Sevilla,Valencia,0,2
Spain-Primera_Division,Eibar,Real Madrid,1,2
Spain-Primera_Division,Malaga,Barcelona,0,2
Argentina-Superliga,Boca Juniors,Tigre,2,1
Argentina-Superliga,Talleres,Atletico Tucuman,3,1
Argentina-Superliga,Olimpo,Colon,0,3
Argentina-Superliga,Chacarita Juniors,Racing Club,1,1
Australia-A_League,Western Sydney Wanderers FC,Wellington Phoenix,4,1
Australia-A_League,Perth Glory,Central Coast Mariners,3,1
Austria-Bundesliga,Austria Wien,SKN St. Poelten,4,0
England-Premier_League,Arsenal,Watford,3,0
England-Premier_League,AFC Bournemouth,Tottenham Hotspur,1,4
France-Ligue_1,Lyon,Caen,1,0
France-Ligue_1,Guingamp,Nice,2,5
France-Ligue_1,Toulouse,Marseille,1,2
Germany-1__Bundesliga,Borussia Dortmund,Eintracht Frankfurt,3,2
Germany-1__Bundesliga,VfB Stuttgart,RasenBallsport Leipzig,0,0
Italy-Serie_A,Juventus,Udinese,2,0
Italy-Serie_A,Fiorentina,Benevento,1,0
Italy-Serie_A,Sassuolo,SPAL 2013,1,1
Italy-Serie_A,Crotone,Sampdoria,4,1
Italy-Serie_A,Genoa,AC Milan,0,1
Italy-Serie_A,Inter,SSC Napoli,0,0
Italy-Serie_A,Bologna,Atalanta,0,1
Italy-Serie_A,Cagliari,Lazio,2,2
Netherlands-Eredivisie,Ajax,SC Heerenveen,4,1
Netherlands-Eredivisie,Feyenoord,AZ Alkmaar,2,1
Netherlands-Eredivisie,FC Utrecht,Vitesse,5,1
Netherlands-Eredivisie,FC Groningen,PEC Zwolle,2,0
Portugal-Primeira_Liga,Belenenses,Tondela,0,0
Portugal-Primeira_Liga,Portimonense,Vitoria de Guimaraes,2,1
Portugal-Primeira_Liga,Maritimo,Vitoria de Setubal,4,2
Portugal-Primeira_Liga,Pacos de Ferreira,FC Porto,1,0
Russia-Premier_League,Spartak Moscow,SKA-Khabarovsk,1,0
Russia-Premier_League,FC Rostov,Zenit St. Petersburg,0,0
Russia-Premier_League,FK Akhmat,CSKA Moscow,0,3
Spain-Primera_Division,Atletico Madrid,Celta Vigo,3,0
Spain-Primera_Division,Athletic Bilbao,Leganes,2,0
Spain-Primera_Division,Espanyol,Real Sociedad,2,1
Spain-Primera_Division,Las Palmas,Villarreal,0,2
Argentina-Superliga,Velez Sarsfield,Rosario Central,2,2
Argentina-Superliga,Huracan,San Lorenzo,1,1
Argentina-Superliga,Lanus,Estudiantes,0,0
Argentina-Superliga,Patronato de Parana,River Plate,0,1
Austria-Bundesliga,Mattersburg,Salzburg,2,2
Belgium-First_Division_A,KV Mechelen,Waasland-Beveren,2,0
Belgium-First_Division_A,Eupen,Royal Excel Mouscron,4,0
Belgium-First_Division_A,Anderlecht,Royal Antwerp,2,1
Belgium-First_Division_A,Kortrijk,Sporting Charleroi,2,0
Belgium-First_Division_A,Genk,Gent,1,2
England-Premier_League,Stoke City,Manchester City,0,2
Germany-1__Bundesliga,Werder Bremen,FC Cologne,3,1
Portugal-Primeira_Liga,Chaves,Sporting CP,1,2
Russia-Premier_League,Ural,Lokomotiv Moscow,0,2
Spain-Primera_Division,Alaves,Real Betis,1,3
International-AFC_Champions_League_Grp__B,Lokomotiv Tashkent,Al-Duhail SC,1,2
International-AFC_Champions_League_Grp__B,Al-Wahda,Zob Ahan,3,0
International-AFC_Champions_League_Grp__D,Esteghlal,Al-Ain,1,1
International-AFC_Champions_League_Grp__D,Al-Rayyan,Al Hilal,2,1
Argentina-Superliga,Independiente,Argentinos Juniors,2,1
Argentina-Superliga,Union,Temperley,3,0
Argentina-Superliga,Defensa y Justicia,Belgrano,1,1
Bulgaria-First_Professional_League,Vereya,Botev Plovdiv,2,4
Denmark-Superligaen,FC Koebenhavn,FC Helsingoer,4,3
Greece-Super_League,PAS Giannina,Apollon Smirnis,1
Ireland-Premier_Division,Derry City,Limerick,5,0
Ireland-Premier_Division,Cork City,Shamrock Rovers,1,0
Ireland-Premier_Division,Waterford FC,Bohemian FC,1,0
Ireland-Premier_Division,Bray Wanderers,Sligo Rovers,1,2
Ireland-Premier_Division,St. Patrick's Athletic,Dundalk,0,0
Israel-Ligat_HaAl,Maccabi Tel Aviv,Maccabi Petach Tikva,2,0
Italy-Serie_B,Novara,Brescia,2,1
Mexico-Liga_MX_Clausura,Santos,Monterrey,3,2
Netherlands-Eerste_Divisie,Jong Ajax,FC Eindhoven,4,0
Netherlands-Eerste_Divisie,FC Dordrecht,RKC Waalwijk,1,0
Netherlands-Eerste_Divisie,Jong PSV,Cambuur,1,1
Netherlands-Eerste_Divisie,Almere City FC,Telstar,2,3
Netherlands-Eerste_Divisie,FC Volendam,MVV Maastricht,2,2
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Go Ahead Eagles,0,0
Netherlands-Eerste_Divisie,Helmond Sport,FC Den Bosch,3,1
Netherlands-Eerste_Divisie,Fortuna Sittard,De Graafschap,1,1
Netherlands-Eerste_Divisie,FC Oss,FC Emmen,2,3
Netherlands-Eerste_Divisie,Jong FC Utrecht,NEC Nijmegen,0,2
Norway-Eliteserien,Kristiansund BK,Vaalerenga,0,1
Poland-Ekstraklasa,Arka Gdynia,Termalica Nieciecza,4,0
Romania-Liga_I_Relegation_Group,Dinamo Bucuresti,Gaz Metan Medias,3,0
Sweden-Cup_Final_Stage,Djurgaarden,Haecken,1,0
Turkey-Super_Lig,Akhisar Belediye Genclik Ve Spor,Trabzonspor,1,3
International-AFC_Cup_Grp__B,Al-Jaish,Al-Ahed,1,4
International-AFC_Cup_Grp__B,Manama,Al Zawraa,1,3
International-Champions_League_Final_Stage,Manchester United,Sevilla,1,2
International-Champions_League_Final_Stage,Roma,Shakhtar Donetsk,1,0
International-Copa_Libertadores_Grp__3,Atletico Tucuman,Libertad,0,2
International-AFC_Champions_League_Grp__A,Al Ahli,Al-Garrafa,1,1
International-AFC_Champions_League_Grp__A,Tractor Sazi Tabriz,Al-Jazira,1,1
International-AFC_Champions_League_Grp__C,Al-Sadd,Nasaf Qarshi,4,0
International-AFC_Champions_League_Grp__C,Al-Wasl,Persepolis,0,1
International-AFC_Champions_League_Grp__F,Melbourne Victory,Kawasaki Frontale,1,0
International-AFC_Champions_League_Grp__F,Ulsan Hyundai,Shanghai SIPG FC,0,1
International-AFC_Champions_League_Grp__H,Kashima Antlers,Sydney FC,1,1
International-AFC_Champions_League_Grp__H,Shanghai Shenhua,Suwon Bluewings,0,2
Argentina-Superliga,Newells Old Boys,San Martin San Juan,2,0
England-Championship,Wolverhampton Wanderers,Reading,3,0
England-Championship,Sheffield United,Burton Albion,2,0
England-Championship,Aston Villa,Queens Park Rangers,1,3
England-Championship,Brentford,Cardiff City,1,3
England-Championship,Ipswich Town,Hull City,0,3
England-Championship,Barnsley,Norwich City,1,1
Italy-Serie_B,Pescara,Carpi,0,1
Italy-Serie_B,Bari,Spezia,1,1
N__Ireland-Premiership,Ballymena United,Ballinamallard United,1
Scotland-FA_Cup,Kilmarnock,Aberdeen,3,4
Slovenia-Prva_Liga,NK Krsko,Ankaran Hrvatini,1,1
Slovenia-Prva_Liga,Maribor,Domzale,1,2
Sweden-Cup_Final_Stage,AIK,Oerebro,2,0
International-AFC_Cup_Grp__A,Al-Jazeera,Al-Suwaiq,4,0
International-AFC_Cup_Grp__C,Al-Ansar,Al-Wahda,1,0
International-AFC_Cup_Grp__C,Dhofar,Al-Faisaly,1,0
International-AFC_Cup_Grp__D,Ahal,FC Alay Osh,5,0
International-AFC_Cup_Grp__G,FLC Thanh Hoa,Bali United Pusam,0,0
International-AFC_Cup_Grp__G,Global FC,Yangon United,2,1
Egypt-Premier_League,El Geish,Misr El-Maqasa,1,0
England-League_1,Rochdale,Southend United,0,0
England-League_1,Blackpool,Charlton Athletic,1,0
England-League_1,Bury,Peterborough United,0,1
England-League_1,Milton Keynes Dons,Rotherham United,3,2
England-League_2,Exeter City,Yeovil Town,0,0
England-League_2,Barnet,Port Vale,1,1
England-League_2,Coventry City,Luton Town,2,2
Estonia-Meistriliiga,Paide Linnameeskond,Parnu JK Vaprus,2,2
International-Champions_League_Final_Stage,Barcelona,Chelsea,3,0
International-Champions_League_Final_Stage,Besiktas,Bayern Munich,1,3
International-Copa_Libertadores_Grp__1,Cerro Porteno,Defensor Sporting,2,1
International-Copa_Libertadores_Grp__2,Bolivar,Colo Colo,1,1
International-Copa_Libertadores_Grp__5,Vasco da Gama,Universidad de Chile,0,1
International-Copa_Libertadores_Grp__6,Estudiantes,Real Garcilaso,3,0
France-Ligue_1,Paris Saint Germain,Angers,2,1
Italy-Serie_A,Juventus,Atalanta,2,0
International-AFC_Champions_League_Grp__E,Tianjin Quanjian,Jeonbuk FC,4,2
International-AFC_Champions_League_Grp__E,Kitchee,Kashiwa Reysol,1,0
International-AFC_Champions_League_Grp__G,Cerezo Osaka,Buriram United,2,2
International-AFC_Champions_League_Grp__G,Jeju United,Guangzhou Evergrande,0,2
Bulgaria-First_Professional_League,Dunav Ruse,Slavia Sofia,0,1
Croatia-1__Division,Osijek,Inter Zapresic,1,1
Croatia-1__Division,Cibalia,Rudes,1,1
International-Friendlies,Iran,Libya,
Slovenia-Prva_Liga,Olimpija Ljubljana,Rudar Velenje,4,0
Slovenia-Prva_Liga,NK Celje,ND Triglav,5,2
Switzerland-Super_League,Lausanne,Basel,1,1
International-AFC_Cup_Grp__D,Altyn Asyr,FC Istiklol,2,2
International-AFC_Cup_Grp__E,Bengaluru FC,Abahani Limited,1,0
International-AFC_Cup_Grp__E,New Radiant SC,Aizawl,3,1
International-AFC_Cup_Grp__F,Home United FC,Boeung Ket,6,0
International-AFC_Cup_Grp__F,Shan United,Ceres-Negros FC,0,1
International-AFC_Cup_Grp__H,Persija Jakarta,Song Lam Nghe An,1,0
International-AFC_Cup_Grp__H,Johor Darul Ta'zim FC,Tampines Rovers FC,2,1
International-AFC_Cup_Grp__I,Hwaebul SC,Benfica Macau,2,3
International-AFC_Cup_Grp__I,HangYuen/Fujen,April 25 SC,1,5
International-CONCACAF_Champions_League,Tigres,Toronto FC,3,2
International-CONCACAF_Champions_League,New York Red Bulls,Tijuana,3,1
Czech_Republic-Cup,Hradec Kralove,Zlin,0,2
Czech_Republic-Cup,Mlada Boleslav,Banik Ostrava,6,5
Egypt-Premier_League,El Zamalek,El Raja Marsa Matruh,4,1
Egypt-Premier_League,Tanta,Alassiouty,1,1
Egypt-Premier_League,Wadi Degla FC,Al-Ittihad Al-Sakandary,1,0
England-League_1,Bradford City,Wigan Athletic,0,1
Estonia-Meistriliiga,Nomme JK Kalju,Flora Tallinn,2,0
Estonia-Meistriliiga,FC Kuressaare,Tulevik Viljandi,3,1
Estonia-Meistriliiga,Tammeka,FCI Levadia,0,3
Gibraltar-Premier_Division,St Joseph's,Mons Calpe SC,0,0
International-Copa_Libertadores_Grp__2,Atletico Nacional,Delfin,4,0
International-Copa_Libertadores_Grp__3,The Strongest,Club Atletico Penarol,1,0
International-Copa_Libertadores_Grp__4,Emelec,Flamengo,1,2
International-Copa_Libertadores_Grp__6,Santos FC,Nacional,3,1
International-Copa_Libertadores_Grp__7,Corinthians,Deportivo Lara,2,0
International-Europa_League_Final_Stage,Lyon,CSKA Moscow,2,3
International-Europa_League_Final_Stage,Arsenal,AC Milan,3,1
International-Europa_League_Final_Stage,Athletic Bilbao,Marseille,1,2
International-Europa_League_Final_Stage,Viktoria Plzen,Sporting CP,2,1
International-Europa_League_Final_Stage,Zenit St. Petersburg,RasenBallsport Leipzig,1,1
International-Europa_League_Final_Stage,Salzburg,Borussia Dortmund,0,0
International-Europa_League_Final_Stage,Dynamo Kyiv,Lazio,0,2
International-Europa_League_Final_Stage,Lokomotiv Moscow,Atletico Madrid,1,5
Slovenia-Prva_Liga,Gorica,Aluminij,1,0
International-CONCACAF_Champions_League,CD Guadalajara,Seattle Sounders FC,3,0
International-CONCACAF_Champions_League,Tauro FC,CF America,1,3
Egypt-Premier_League,El Dakhleya,Al Nasr,1,1
Egypt-Premier_League,Smouha SC,Al Mokawloon Al Arab,3,0
Egypt-Premier_League,Petrojet,Ismaily SC,0,1
International-EURO_U17_Qualification_Elite_Round_Grp__2,Cyprus U17,Sweden U17,0,0
International-EURO_U17_Qualification_Elite_Round_Grp__2,Croatia U17,Belgium U17,1,2
International-EURO_U17_Qualification_Elite_Round_Grp__4,Finland U17,Slovakia U17,2,1
International-EURO_U17_Qualification_Elite_Round_Grp__4,Portugal U17,Switzerland U17,1,1
Gibraltar-Premier_Division,Gibraltar United FC,Glacis United,4,1
Kosovo-Superliga,Gjilani,KF Flamurtari,0,0
Norway-Cup_Qualification,Emblem IL,Rollon,0,1
Norway-Cup_Qualification,Leknes,Melbo,0,2
Algeria-Ligue_1,Paradou AC,USM Bel Abbes,0,1
Argentina-Primera_B_Metropolitana,Deportivo Espanol,Barracas Central,1,0
Argentina-Super_Cup,Boca Juniors,River Plate,0,2
Brazil-Cup,Cuiaba,Nautico,0,1
Brazil-Cup,Vitoria,Bragantino,3,0
Brazil-Cup,Atletico MG,Figueirense,5,4
Brazil-Cup,Sampaio Correa,Ponte Preta,3,5
Brazil-Alagoano_Playoff,ASA,CS Alagoano,1,0
Brazil-Cearense_2nd_Group_Stage,Floresta,Fortaleza,1,0
Brazil-Paraense,Independente PA,Sao Raimundo PA,1,2
Brazil-Paraibano_Playoff,Centro Sportivo Paraibano,Gremio Recreativo Serrano,0,1
Brazil-Paraibano_Relegation_Group,Atletico Cajazeirense,Nacional de Patos,0,1
Brazil-Paraibano_Relegation_Group,Desportiva Guarabira,Auto Esporte,1,0
International-Copa_Libertadores_Grp__7,Independiente,Millonarios,1,0
England-Premier_League,Tottenham Hotspur,Newcastle United,1
France-Ligue_1,Monaco,Lille,2,1
Germany-1__Bundesliga,Freiburg,VfB Stuttgart,1,2
Netherlands-Eredivisie,Excelsior,ADO Den Haag,1,2
Portugal-Primeira_Liga,Vitoria de Setubal,Portimonense,1,1
Spain-Primera_Division,Levante,Eibar,2,1
Argentina-Superliga,Rosario Central,Chacarita Juniors,3,1
Australia-A_League,Adelaide United,Melbourne City FC,1,1
Bulgaria-First_Professional_League,Septemvri Sofia,Vereya,2,0
Croatia-1__Division,NK Istra 1961,Slaven,2,1
Czech_Republic-1__Division,Slovan Liberec,FC Zbrojovka Brno,2,0
Germany-2__Bundesliga,Holstein Kiel,FC Heidenheim,2,1
Germany-2__Bundesliga,Fortuna Duesseldorf,Arminia Bielefeld,4,2
Ireland-Premier_Division,Dundalk,Waterford FC,1,0
Ireland-Premier_Division,Derry City,Bray Wanderers,5,1
Ireland-Premier_Division,Shamrock Rovers,St. Patrick's Athletic,1,0
Ireland-Premier_Division,Bohemian FC,Sligo Rovers,2,2
Ireland-Premier_Division,Limerick,Cork City,1,1
Italy-Serie_B,Foggia,Cesena,2,1
Netherlands-Eerste_Divisie,FC Emmen,Helmond Sport,0,0
Netherlands-Eerste_Divisie,FC Eindhoven,Jong FC Utrecht,5,2
Netherlands-Eerste_Divisie,De Graafschap,Jong Ajax,2,4
Netherlands-Eerste_Divisie,Jong PSV,FC Volendam,2,1
Netherlands-Eerste_Divisie,FC Den Bosch,FC Dordrecht,4,1
Netherlands-Eerste_Divisie,Go Ahead Eagles,Telstar,1,1
Netherlands-Eerste_Divisie,Jong AZ Alkmaar,Almere City FC,4,1
Netherlands-Eerste_Divisie,RKC Waalwijk,MVV Maastricht,1,1
Netherlands-Eerste_Divisie,FC Oss,Fortuna Sittard,1,2
Netherlands-Eerste_Divisie,Cambuur,NEC Nijmegen,1,1
Poland-Ekstraklasa,Lech Poznan,Lechia Gdansk,3,0
Poland-Ekstraklasa,Piast Gliwice,Zaglebie Lubin,0,0
Romania-Liga_I_Championship_Group,FC Viitorul Constanta,CS Universitatea Craiova,0,0
Romania-Liga_I_Relegation_Group,Juventus Bucuresti,ACS Poli Timisoara,1,0
Scotland-Premiership,St.Johnstone,Hibernian,1,1
Slovakia-Super_Liga,Tatran Presov,FK Senica,1,1
Spain-Segunda_Division,Sevilla Atletico,Albacete,1,2
Turkey-Super_Lig,Kasimpasa,Antalyaspor,2,3
Turkey-Super_Lig,Karabukspor,Osmanlispor FK,0,4
International-Club_Friendlies,Elfsborg,Landskrona BoIS,2,0`;