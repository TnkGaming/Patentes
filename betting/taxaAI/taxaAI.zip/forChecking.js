var toCheck=`England-Premier_League,Manchester City,Brighton & Hove Albion,1
1(72%) - NG(50%) - Over(81%)1.5 - Over(53%)2.5 - Under(66%)3.5
England-Premier_League,West Ham United,Manchester United,2
2(49%) - GG(53%) - Over(73%)1.5 - Over(51%)2.5 - Under(70%)3.5
England-FA_Cup,Leicester City,Chelsea,
1(40%)X(31%) - NG(64%) - Over(62%)1.5 - Under(58%)2.5 - Under(75%)3.5
England-FA_Cup,Wigan Athletic,Southampton,
1(47%)2(34%) - NG(54%) - Over(65%)1.5 - Under(51%)2.5 - Under(84%)3.5
France-Ligue_1,Saint-Etienne,Guingamp,1X
1(36%)X(34%) - GG(59%) - Over(79%)1.5 - Over(54%)2.5 - Under(65%)3.5
France-Ligue_1,Marseille,Lyon,1X
1(43%)2(32%) - GG(59%) - Over(84%)1.5 - Over(59%)2.5 - Under(60%)3.5
France-Ligue_1,Metz,Nantes,2
2(48%) - GG(59%) - Over(75%)1.5 - Over(50%)2.5 - Under(79%)3.5
France-Ligue_1,Nice,Paris Saint Germain,2
1(30%)2(55%) - GG(59%) - Over(76%)1.5 - Over(66%)2.5 - Under(60%)3.5
Germany-1__Bundesliga,Borussia Dortmund,Hannover 96,1
1(41%)X(39%) - GG(81%) - Over(86%)1.5 - Over(53%)2.5 - Under(61%)3.5
Germany-1__Bundesliga,FC Cologne,Bayer Leverkusen,2
2(58%) - GG(65%) - Over(76%)1.5 - Over(55%)2.5 - Under(67%)3.5
Germany-1__Bundesliga,RasenBallsport Leipzig,Bayern Munich,2
2(53%) - GG(62%) - Over(83%)1.5 - Over(58%)2.5 - Under(67%)3.5
Italy-Serie_A,SSC Napoli,Genoa,1
1(55%) - NG(60%) - Over(51%)1.5 - Under(59%)2.5 - Under(72%)3.5
Italy-Serie_A,Lazio,Bologna,1
1(60%)2(30%) - GG(66%) - Over(78%)1.5 - Over(68%)2.5 - Under(64%)3.5
Italy-Serie_A,AC Milan,ChievoVerona,1
1(55%) - NG(58%) - Over(61%)1.5 - Under(64%)2.5 - Under(80%)3.5
Italy-Serie_A,Torino,Fiorentina,X2
1(33%)X(35%) - GG(60%) - Over(76%)1.5 - Under(50%)2.5 - Under(78%)3.5
Italy-Serie_A,Benevento,Cagliari,X2
1(32%)2(52%) - GG(52%) - Over(76%)1.5 - Over(59%)2.5 - Under(77%)3.5
Italy-Serie_A,Sampdoria,Inter,1X
1(37%)2(30%) - GG(63%) - Over(77%)1.5 - Under(55%)2.5 - Under(69%)3.5
Italy-Serie_A,Crotone,Roma,2
2(51%) - GG(54%) - Over(70%)1.5 - Under(58%)2.5 - Under(73%)3.5
Italy-Serie_A,Hellas Verona,Atalanta,2
2(49%) - GG(51%) - Over(76%)1.5 - Over(50%)2.5 - Under(79%)3.5
Netherlands-Eredivisie,AZ Alkmaar,FC Groningen,1
1(49%)X(30%) - GG(60%) - Over(92%)1.5 - Over(56%)2.5 - Under(69%)3.5
Netherlands-Eredivisie,NAC Breda,Roda JC Kerkrade,1
1(50%)2(35%) - GG(72%) - Over(86%)1.5 - Over(64%)2.5 - Under(58%)3.5
Netherlands-Eredivisie,PEC Zwolle,Feyenoord,X2
1(39%)2(36%) - GG(62%) - Over(78%)1.5 - Under(55%)2.5 - Under(69%)3.5
Netherlands-Eredivisie,Sparta Rotterdam,Ajax,2
2(60%) - GG(64%) - Over(77%)1.5 - Over(66%)2.5 - Under(55%)3.5
Portugal-Primeira_Liga,Sporting CP,Rio Ave,1
1(62%) - GG(53%) - Over(68%)1.5 - Under(50%)2.5 - Under(70%)3.5
Portugal-Primeira_Liga,Vitoria de Guimaraes,Aves,1X
1(44%)2(34%) - GG(53%) - Over(67%)1.5 - Under(52%)2.5 - Under(69%)3.5
Portugal-Primeira_Liga,Moreirense,Belenenses,X2
1(32%)2(36%) - NG(57%) - Over(65%)1.5 - Under(60%)2.5 - Under(87%)3.5
Portugal-Primeira_Liga,Chaves,Braga,2
1(33%)2(44%) - GG(58%) - Over(83%)1.5 - Over(61%)2.5 - Under(64%)3.5
Spain-Primera_Division,Barcelona,Athletic Bilbao,1
1(63%) - NG(55%) - Over(82%)1.5 - Under(50%)2.5 - Under(68%)3.5
Spain-Primera_Division,Real Madrid,Girona,1
1(48%) - GG(59%) - Over(79%)1.5 - Over(60%)2.5 - Under(60%)3.5
Spain-Primera_Division,Celta Vigo,Malaga,1
1(59%) - GG(53%) - Over(69%)1.5 - Under(56%)2.5 - Under(73%)3.5
Spain-Primera_Division,Leganes,Sevilla,X2
1(39%)2(44%) - NG(57%) - Over(66%)1.5 - Under(50%)2.5 - Under(71%)3.5
Spain-Primera_Division,Villarreal,Atletico Madrid,2
1(31%)2(49%) - NG(57%) - Over(62%)1.5 - Under(56%)2.5 - Under(74%)3.5
Argentina-Superliga,Racing Club,Patronato de Parana,1
1(48%)X(30%) - GG(60%) - Over(71%)1.5 - Under(57%)2.5 - Under(72%)3.5
Argentina-Superliga,Estudiantes,Godoy Cruz,
1(30%)2(43%) - NG(56%) - Over(50%)1.5 - Under(60%)2.5 - Under(75%)3.5
Argentina-Superliga,Talleres,Defensa y Justicia,1
1(52%)2(31%) - NG(53%) - Over(58%)1.5 - Under(61%)2.5 - Under(73%)3.5
Argentina-Superliga,Arsenal Sarandi,Velez Sarsfield,X2
1(36%)2(32%) - NG(66%) - Under(50%)1.5 - Under(65%)2.5 - Under(83%)3.5
Argentina-Superliga,Atletico Tucuman,Boca Juniors,2
1(31%)2(48%) - NG(65%) - Over(58%)1.5 - Under(66%)2.5 - Under(81%)3.5
Australia-A_League,Melbourne Victory,Central Coast Mariners,1X
1(50%) - GG(76%) - Over(83%)1.5 - Over(54%)2.5 - Under(71%)3.5
Austria-Bundesliga,Salzburg,Austria Wien,1
1(59%) - NG(51%) - Over(68%)1.5 - Over(52%)2.5 - Under(67%)3.5
Bulgaria-First_Professional_League,PFC CSKA-Sofia,Levski Sofia,1
1(38%)2(34%) - NG(79%) - Over(69%)1.5 - Over(51%)2.5 - Under(71%)3.5`.replace(/&/g,"&amp;");

var results=`England-Premier_League,Swansea City,Southampton,1X
England-Premier_League,Leicester City,Arsenal,1X
England-Premier_League,Burnley,Chelsea,X2
England-Premier_League,Liverpool,Watford,5,0
England-Premier_League,AFC Bournemouth,West Bromwich Albion,2,1
England-Premier_League,Stoke City,Everton,1,2
England-Premier_League,Huddersfield Town,Crystal Palace,0,2
England-FA_Cup,Manchester United,Brighton &amp; Hove Albion,2,0
England-FA_Cup,Swansea City,Tottenham Hotspur,0,3
France-Ligue_1,Montpellier,Dijon,2,2
France-Ligue_1,Toulouse,Strasbourg,2,2
France-Ligue_1,Angers,Caen,3,0
France-Ligue_1,Bordeaux,Rennes,0,2
France-Ligue_1,Amiens,Troyes,1,1
Germany-1__Bundesliga,Eintracht Frankfurt,Mainz 05,3,0
Germany-1__Bundesliga,Augsburg,Werder Bremen,1,3
Germany-1__Bundesliga,Hamburger SV,Hertha Berlin,1,2
Germany-1__Bundesliga,Borussia Moenchengladbach,Hoffenheim,3,3
Germany-1__Bundesliga,Wolfsburg,Schalke 04,0,1
Italy-Serie_A,Udinese,Sassuolo,1,2
Italy-Serie_A,SPAL 2013,Juventus,0,0
Netherlands-Eredivisie,PSV Eindhoven,VVV-Venlo,3,0
Netherlands-Eredivisie,Vitesse,Heracles,0,0
Netherlands-Eredivisie,FC Twente,Willem II,2,2
Netherlands-Eredivisie,SC Heerenveen,FC Utrecht,2,2
Portugal-Primeira_Liga,FC Porto,Boavista,2,0
Portugal-Primeira_Liga,Estoril,Pacos de Ferreira,1,1
Portugal-Primeira_Liga,Tondela,Maritimo,1,2
Portugal-Primeira_Liga,Feirense,Benfica,0,2
Russia-Premier_League,FC Krasnodar,FC Ufa,0,1
Russia-Premier_League,Anzhi Makhachkala,Tosno,2,0
Russia-Premier_League,Arsenal Tula,FC Rostov,2,2
Russia-Premier_League,Rubin Kazan,Spartak Moscow,1,2
Russia-Premier_League,SKA-Khabarovsk,Ural,0,3
Spain-Primera_Division,Valencia,Alaves,3,1
Spain-Primera_Division,Deportivo La Coruna,Las Palmas,1,1
Spain-Primera_Division,Real Sociedad,Getafe,1,2
Spain-Primera_Division,Real Betis,Espanyol,3,0
Argentina-Superliga,San Lorenzo,Olimpo,2,0
Argentina-Superliga,Colon,Lanus,1,2`;