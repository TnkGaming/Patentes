var todaysMatches = `Argentina-Superliga,River Plate,Belgrano,X2
Argentina-Superliga,Banfield,Union,X2
Bulgaria-First_Professional_League,Slavia Sofia,Pirin Blagoevgrad,1X
Germany-2__Bundesliga,Erzgebirge Aue,Greuther Fuerth,
Greece-Super_League,Asteras Tripolis,Platanias,1
Ireland-Premier_Division,Cork City,Bohemian FC,1
Ireland-Premier_Division,St. Patrick's Athletic,Sligo Rovers,X2
Ireland-Premier_Division,Limerick,Shamrock Rovers,X2
Ireland-Premier_Division,Bray Wanderers,Waterford FC,2
Italy-Serie_B,Carpi,Pro Vercelli,1X
Mexico-Liga_MX_Clausura,Veracruz,Atlas,X
Romania-Liga_I_Relegation_Group,Sepsi OSK,FC Voluntari,
Spain-Segunda_Division,Huesca,Sporting Gijon,1X
International-Club_Friendlies,Odds Ballklubb,Fram Larvik,
International-Club_Friendlies,Stabaek,Skeid,
Egypt-Premier_League,Al Nasr,Misr El-Maqasa,X2
Egypt-Premier_League,Alassiouty,Smouha SC,X2
Egypt-Premier_League,El Entag El Harby,ENPPI,1X
Egypt-Premier_League,Al Mokawloon Al Arab,Wadi Degla FC,1X
Egypt-Premier_League,El Raja Marsa Matruh,El Geish,X2
Egypt-Premier_League,Al-Ittihad Al-Sakandary,Petrojet,X
England-League_1,Doncaster Rovers,Bradford City,
France-Ligue_2,Brest,Nimes,X2
Italy-Serie_C_Grp__C,Cosenza,Lecce,2
Italy-Serie_C_Grp__C,Casertana,Racing Fondi,1
Albania-Kategoria_Superiore,Kukesi,Vllaznia,1
Albania-Kategoria_Superiore,Partizani,Flamurtari,1X
Argentina-Primera_B_Metropolitana,CD UAI Urquiza,Villa San Carlos,1X
Argentina-Primera_B_Metropolitana,CA Talleres Remedios de Escalada,Deportivo Espanol,1
Argentina-Primera_B_Metropolitana,Tristan Suarez,CA San Miguel,1
Argentina-Primera_B_Metropolitana,Barracas Central,Almirante Brown,1
Armenia-1__Division,Erebuni,Pyunik II,X2
Armenia-1__Division,Ararat II,Gandzasar II,1X
Armenia-1__Division,Shirak II,Artsakh,2
Armenia-1__Division,Banants II,Avan Academy,X2
Armenia-1__Division,Lori,Alashkert FC II,1
Australia-Southern,Para Hills Knights,Campbelltown City,2
Australia-Southern_State_League,Adelaide Blue Eagles,The Cove,1X
Australia-NPL_Youth_Queensland,Brisbane Strikers U20,Brisbane Roar U20,2
Australia-NPL_Youth_Queensland,Western Pride U20,Moreton Bay United U20,1`.split("\n");